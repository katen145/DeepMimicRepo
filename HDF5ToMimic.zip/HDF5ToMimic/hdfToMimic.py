# Imports
# ===========================================================================
import math

from loaddatasets.hdf5.helpersMotionDirection import computePrimitvesWalkingStraight, sequentializePrimitives, \
    computePrimitves
from loaddatasets.hdf5.loadHDF5 import SettingReadHDF5, LoadHDF5
# from loaddatasets.visualize.visutilsQt import drawSkelQtWithLabels
from dm_control.mujoco.wrapper import mjbindings
import numpy as np
from six.moves import range
from pyquaternion import Quaternion

mjlib = mjbindings.mjlib
from trafos import euler_from_quaternion, q_conjugate, quaternion_matrix4x4, quaternion_matrix

import json
import os
from os import listdir
from os.path import isfile, join
from HDFJointHandler import HDFJointHandler

_SUBJECT_ID = 1
_SUBJECT_AMC_ID = [1, 2, 3, 4, 5]


# Function declarations
# ===========================================================================

def mj_quatprod(q, r):
    quaternion = np.zeros(4)
    mjlib.mju_mulQuat(quaternion, np.ascontiguousarray(q),
                      np.ascontiguousarray(r))
    return quaternion


def removeAllFilesInDirectory(directory):
    onlyfiles = [f for f in listdir(directory) if isfile(join(directory, f))]
    for i in range(0, len(onlyfiles)):
        os.remove(f"{directory}{onlyfiles[i]}")


# Locks root position and rotation for dev testing
posLocked = True

# sets onlyfiles to a list of files founds in the "mypath" directory
mypath = "./InputHdf/"
onlyfiles = [f for f in listdir(mypath) if isfile(join(mypath, f))]

# Start of main program
# ===========================================================================
id = '5'

# for all files to convert
with open(f"../mimic/DeepMimic/data/motions/P"+id+"_6_min_walking_test.h5.txt", "w") as output:
        # list containing all the frames
    frames = []
        # open file to convert
    with open("./InputHdf/P"+id+"_6_min_walking_test.h5") as f:
            # Convert file read hdf5 file in such a format that HDFJointHandler accepts
        p = SettingReadHDF5('./InputHdf/', id)
        loader = LoadHDF5(p)
        dictLabels, aData, iData, cData = loader.loadForVisualization('P'+id, movement='_6_min_walking_test',
                                                                      load=['a', 'c'],
                                                                      nTimeLimit=1000)
        dict_labels = {'Initial Contact (L(red)/R(green))': dictLabels['ic'],
                       'Turning Segmentation (L(red)/R(green))': dictLabels['seg']}
        idxOrig = cData.segValueByNames["RightFoot"]
        # Motion segmentation for walking straight   (Option 2)
        straightWalkingList = computePrimitvesWalkingStraight(dictLabels['ic'][1], aData, idxOrig, cData,
                                                              dict_labels=dictLabels['seg'])
        aDataSegments = sequentializePrimitives(straightWalkingList, aData)
        mocap = {'data': list()}
        quat_left_upper_leg, quat_right_upper_leg, quat_left_lower_leg, quat_right_lower_leg, \
        quat_left_foot, quat_right_foot, pelvis_list = list(), list(), list(), list(), list(), list(), list()
        pelvis_pos_list = list()
        frames = aDataSegments.seg[0].pos_g.shape[1]
        for t in range(frames):
            quat_270_x_rot=[-0.707, 0.707,  0.0,  0.0] #Quaternion(axis=[1.0, 0.0, 0.0], degrees=270)
            quat_rot=Quaternion([-0.707, 0.707,  0.0,  0.0])
            rotated_pelvis_pos=np.matmul(quat_rot.rotation_matrix,aDataSegments.seg[0].pos_g[:, t])
            pelvis_pos_list.append(rotated_pelvis_pos)
            pelvis = aDataSegments.seg[0].quat_gs[:, t]
            #reorienting the whole body 270 degrees around the x axis
            pelvis = mj_quatprod(quat_270_x_rot,pelvis)
            pelvis_list.append(pelvis)
            euler_index=2
            left_upper = aDataSegments.seg[1].quat_gs[:, t]
            left_upper = mj_quatprod(quat_270_x_rot, left_upper)
            quat_left_upper_leg.append(mj_quatprod(q_conjugate(pelvis), left_upper))
            right_upper = aDataSegments.seg[2].quat_gs[:, t]
            right_upper = mj_quatprod(quat_270_x_rot, right_upper)
            quat_right_upper_leg.append(mj_quatprod(q_conjugate(pelvis), right_upper))
            left_lower = aDataSegments.seg[3].quat_gs[:, t]
            left_lower = mj_quatprod(quat_270_x_rot, left_lower)
            l=euler_from_quaternion(mj_quatprod(q_conjugate(left_upper), left_lower))
            quat_left_lower_leg.append([l[euler_index]])
            right_lower = aDataSegments.seg[4].quat_gs[:, t]
            right_lower = mj_quatprod(quat_270_x_rot, right_lower)
            r=euler_from_quaternion(mj_quatprod(q_conjugate(right_upper), right_lower))
            quat_right_lower_leg.append([r[euler_index]])
            left_foot = aDataSegments.seg[5].quat_gs[:, t]
            left_foot = mj_quatprod(quat_270_x_rot, left_foot)
            quat_left_foot.append(mj_quatprod(q_conjugate(left_lower), left_foot))
            right_foot = aDataSegments.seg[6].quat_gs[:, t]
            right_foot = mj_quatprod(quat_270_x_rot, right_foot)
            quat_right_foot.append(mj_quatprod(q_conjugate(right_lower), right_foot))
        mocap['data'].append(np.array(pelvis_pos_list).T)
        mocap['data'].append(np.array(pelvis_list).T)
        mocap['data'].append(np.array(quat_right_upper_leg).T)
        mocap['data'].append(np.array(quat_right_lower_leg).T)
        mocap['data'].append(np.array(quat_right_foot).T)
        mocap['data'].append(np.array(quat_left_upper_leg).T)
        mocap['data'].append(np.array(quat_left_lower_leg).T)
        mocap['data'].append(np.array(quat_left_foot).T)
        jointHandler = HDFJointHandler(mocap, posLocked=posLocked)
        print("Converting: " + "P" +id+"_6_min_walking_test.h5")
        frames = jointHandler.generateKeyFrames()
        # Output in dictionary format for easy json dump
        outputDict = {
            "Loop": "wrap",  # "none" or "wrap"
            "Frames": frames
        }
        json.dump(outputDict, output, indent=4)


def euler2quat(ax, ay, az):
    """Converts euler angles to a quaternion.

  Note: rotation order is zyx

  Args:
    ax: Roll angle (deg)
    ay: Pitch angle (deg).
    az: Yaw angle (deg).

  Returns:
    A numpy array representing the rotation as a quaternion.
  """
    r1 = az
    r2 = ay
    r3 = ax

    c1 = np.cos(np.deg2rad(r1 / 2))
    s1 = np.sin(np.deg2rad(r1 / 2))
    c2 = np.cos(np.deg2rad(r2 / 2))
    s2 = np.sin(np.deg2rad(r2 / 2))
    c3 = np.cos(np.deg2rad(r3 / 2))
    s3 = np.sin(np.deg2rad(r3 / 2))

    q0 = c1 * c2 * c3 + s1 * s2 * s3
    q1 = c1 * c2 * s3 - s1 * s2 * c3
    q2 = c1 * s2 * c3 + s1 * c2 * s3
    q3 = s1 * c2 * c3 - c1 * s2 * s3

    return np.array([q0, q1, q2, q3])


def mj_quat2vel(q, dt):
    vel = np.zeros(3)
    mjlib.mju_quat2Vel(vel, np.ascontiguousarray(q), dt)
    return vel


def mj_quatneg(q):
    quaternion = np.zeros(4)
    mjlib.mju_negQuat(quaternion, np.ascontiguousarray(q))
    return quaternion


def mj_quatdiff(source, target):
    return mj_quatprod(mj_quatneg(source), np.ascontiguousarray(target))
