import json
import os
import pickle

from scipy import stats
from matplotlib import pyplot as plt
from scipy.signal import find_peaks

from agent import *
import math
import scipy
import statsmodels.api as sm

euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}

body_part_dict = {
    0: 'pelvis',
    1: 'right_hip',
    2: 'right_knee',
    3: 'right_foot',
    4: 'left_hip',
    5: 'left_knee',
    6: 'left_foot'
}


def get_agent_and_expert_data(path):
    expert_file = path + "expert.txt"
    agent_file = path + "agent.txt"
    with open(expert_file) as json_file:
        data = json.load(json_file)
        expert_arr = np.array(data["Frames"])
        expert_data = expert_arr[:, 1:]
    f = open(agent_file, "r")
    lines = [line.rstrip() for line in f if line.rstrip().find('Pose') != -1]
    agent_episode_frames = []
    frame_values = []
    agent_data_episodes = []
    for line in lines:
        line = line.replace('[', '').replace(']', '').replace('"Pose":', '')
        values = line.split(',')
        for val in values:  # val == '['  or
            if val != '':
                frame_values.append(float(val))
        agent_episode_frames.append(np.array(frame_values))
        frame_values = []
    agent_data_episodes.append(np.array(agent_episode_frames))
    return expert_data, agent_data_episodes


def align_and_resample_agent_distributions_SGAIL(agent_data, expert_data, gc, result_path, SAMPLE_SIZE=50):
    """
        Extract an aligned version of the agent and expert trajectories, based on a gait cycle
        Compute the max distance in the saggital plane of the foot to the pelvis
        2 times the right/left foot reaches max
    :param agent_expert:
    :return:
    """
    plt.show()
    fig = plt.figure()
    peaks, _ = find_peaks(agent_data[3, :][gc[0]:gc[1]], distance=40)
    plt.plot(agent_data[3, :][gc[0]:gc[1]], 'r', label='agent')
    plt.plot(peaks, agent_data[3, :][gc[0]:gc[1]][peaks], "x")
    if len(peaks) >= 1:
        for peak_ind, p in enumerate(peaks):
            plt.text(p, agent_data[3, :][gc[0]:gc[1]][p], '%d' % (int(p)))
    plt.ylabel('Joint angle (degrees)')
    plt.title('right hip agent movement')
    plt.savefig(result_path + '_right hip movement_agent' + '.png')
    plt.close(fig)

    resampled_agent = []
    resampled_expert = []

    fig = plt.figure()
    peaks, _ = find_peaks(expert_data[3, :], distance=10)
    plt.plot(expert_data[3, :], 'r', label='expert')
    plt.plot(peaks, expert_data[3, :][peaks], "x")
    if len(peaks) >= 1:
        for peak_ind, p in enumerate(peaks):
            plt.text(p, expert_data[3, :][p], '%d' % (int(p)))

    plt.ylabel('Joint angle (degrees)')
    plt.title('right hip expert movement')
    plt.savefig(result_path + '_right hip movemen_expert_before_resampling' + '.png')
    plt.close(fig)

    for i in range(9):
        data_agent = agent_data[i, :][gc[0]:gc[1]]  # local extremums
        data_expert = expert_data[i][:]  # local extremums
        data_agent = scipy.signal.resample(data_agent, data_expert.shape[0])
        resampled_expert.append(scipy.signal.resample(data_expert, SAMPLE_SIZE))
        resampled_agent.append(scipy.signal.resample(data_agent, SAMPLE_SIZE))

    right_hip_data_agent = resampled_agent[3]
    right_hip_data_expert = resampled_expert[3]

    fig = plt.figure()
    peaks, _ = find_peaks(right_hip_data_expert, distance=10)
    plt.plot(right_hip_data_expert, 'r', label='expert')
    plt.ylabel('Joint angle (degrees)')
    plt.title('right hip expert movement')
    plt.savefig(result_path + '_right hip movemen_expert_after_resampling' + '.png')
    plt.close(fig)

    fig = plt.figure()
    plt.plot(right_hip_data_agent, 'r', label='agent')
    plt.ylabel('Joint angle (degrees)')
    plt.title('right hip agent movement')
    plt.savefig(result_path + '_right hip movement_agent_after_resampling' + '.png')
    plt.close(fig)
    plt.close('all')
    return np.array(resampled_agent), np.array(resampled_expert)


def align_and_resample_agent_distributions(agent_expert, gc, result_path, expert_count, SAMPLE_SIZE=50):
    """
        Extract an aligned version of the agent and expert trajectories, based on a gait cycle
        Compute the max distance in the saggital plane of the foot to the pelvis
        2 times the right/left foot reaches max
    :param agent_expert:
    :return:
    """
    plt.show()
    fig = plt.figure()
    peaks, _ = find_peaks(agent_expert.body_parts_agent[1][gc[0]:gc[1], 2], distance=150)

    plt.plot(agent_expert.body_parts_agent[1][gc[0]:gc[1], 2], 'r', label='agent')
    plt.plot(peaks, agent_expert.body_parts_agent[1][gc[0]:gc[1], 2][peaks], "x")
    if len(peaks) >= 1:
        for peak_ind, p in enumerate(peaks):
            plt.text(p, agent_expert.body_parts_agent[1][gc[0]:gc[1], 2][p], '%d' % (int(p)))
    plt.ylabel('Joint angle (degrees)')
    plt.legend(loc="upper left")

    plt.title('right hip agent movement')
    plt.savefig(result_path + '_right hip movement_agent' + '.png')
    plt.close(fig)

    fig = plt.figure()
    peaks, _ = find_peaks(agent_expert.body_parts_expert[1][:expert_count, 2])
    plt.plot(agent_expert.body_parts_expert[1][:expert_count, 2], 'r', label='expert')
    plt.plot(peaks, agent_expert.body_parts_expert[1][:expert_count, 2][peaks], "x")
    if len(peaks) >= 1:
        for peak_ind, p in enumerate(peaks):
            plt.text(p, agent_expert.body_parts_expert[1][:expert_count, 2][p], '%d' % (int(p)))
    # plt.plot(agent_expert.body_parts_expert[1][:expert_count, 2], 'r', label='expert')
    plt.ylabel('Joint angle (degrees)')
    plt.title('right hip expert movement')
    plt.savefig(result_path + '_right hip movemen_expert_before_resampling' + '.png')
    plt.close(fig)

    for i in range(7):
        data_agent = agent_expert.body_parts_agent[i][gc[0]:gc[1]]  # local extremums
        data_expert = agent_expert.body_parts_expert[i][:expert_count]  # local extremums
        data_agent = scipy.signal.resample(data_agent, data_expert.shape[0])
        agent_expert.body_parts_expert[i] = scipy.signal.resample(data_expert, SAMPLE_SIZE)
        agent_expert.body_parts_agent[i] = scipy.signal.resample(data_agent, SAMPLE_SIZE)

    right_hip_data_agent = agent_expert.body_parts_agent[1][:, 2]
    right_hip_data_expert = agent_expert.body_parts_expert[1][:, 2]

    fig = plt.figure()
    plt.plot(right_hip_data_expert, 'r', label='expert')
    plt.ylabel('Joint angle (degrees)')
    plt.title('right hip expert movement')
    plt.savefig(result_path + '_right hip movemen_expert_after_resampling' + '.png')
    plt.close(fig)

    fig = plt.figure()
    plt.plot(right_hip_data_agent, 'r', label='agent')
    plt.ylabel('Joint angle (degrees)')
    plt.title('right hip agent movement')
    plt.savefig(result_path + '_right hip movement_agent_after_resampling' + '.png')
    plt.close(fig)
    plt.close('all')


def compute_ks_sample_size(samples_pk, samples_qk, indexes_expert, indexes_agent):
    supremum_of_cdfs_d = scipy.spatial.distance.minkowski(n1, n2, p=float('inf'))
    alpha = supremum_of_cdfs_d / 1.358
    sample_size = int(2 / (alpha * alpha))
    samples_pk_indexes = np.random.choice(indexes_expert, sample_size)
    samples_qk_indexes = np.random.choice(indexes_agent, sample_size)
    if sample_size > len(indexes_expert):
        tiler = math.ceil(sample_size / len(indexes_expert))
        samples_pk = np.tile(samples_pk, tiler)
    samples_pk = samples_pk[samples_pk_indexes]
    samples_qk = samples_qk[samples_qk_indexes]
    return samples_pk, samples_qk


def plot_boxplot_results(samples_pk, samples_qk, counter, euler_idx, result_path, body_part_dict):
    fig = plt.figure()
    euler_str = str(euler_dict[euler_idx])
    if counter == 2 or counter == 5:
        euler_str = str(euler_dict[2])
    bplot1 = plt.boxplot([samples_qk, samples_pk],
                         vert=True,  # vertical box alignment
                         patch_artist=True,  # fill with color
                         labels=['agent', 'expert'])  # will be used to label x-ticks
    colors = ['pink', 'lightblue']
    for patch, color in zip(bplot1['boxes'], colors):
        patch.set_facecolor(color)
    plt.ylabel('Joint angle values (degrees)')
    plt.title('Box plots of ' + body_part_dict[counter] + ' euler ' + euler_str)
    plt.savefig(
        result_path + '/box_plot_' + body_part_dict[counter] + 'euler ' + euler_str + '.png')
    plt.close(fig)


def plot_ks_results(samples_pk, samples_qk, res, counter, euler_idx, result_path, body_part_dict):
    euler_str = str(euler_dict[euler_idx])
    if counter == 2 or counter == 5:
        euler_str = str(euler_dict[2])
    if res.pvalue < 0.05:
        # print("significant difference, null hypothesis rejected ", res.pvalue)
        fig = plt.figure()
        bplot1 = plt.boxplot([samples_qk, samples_pk],
                             vert=True,  # vertical box alignment
                             patch_artist=True,  # fill with color
                             labels=['agent', 'expert'])  # will be used to label x-ticks
        colors = ['pink', 'lightblue']
        for patch, color in zip(bplot1['boxes'], colors):
            patch.set_facecolor(color)
        plt.ylabel('Joint angle values (degrees)')
        plt.title('Box plots of ' + body_part_dict[counter] + ' euler ' + euler_str)
        plt.savefig(
            result_path + '/box_plot_REJECTED_' + str(res.pvalue) + body_part_dict[
                counter] + 'euler ' + euler_str + '.png')
        plt.close(fig)
    else:
        # print("hypothesis accepted, similar enough distributions ", res.pvalue)
        fig = plt.figure()
        bplot1 = plt.boxplot([samples_qk, samples_pk],
                             vert=True,  # vertical box alignment
                             patch_artist=True,  # fill with color
                             labels=['agent', 'expert'])  # will be used to label x-ticks
        colors = ['pink', 'lightblue']
        for patch, color in zip(bplot1['boxes'], colors):
            patch.set_facecolor(color)
        plt.ylabel('Joint angle values (degrees)')
        plt.title('Box plots of ' + body_part_dict[counter] + ' euler ' + euler_str)
        plt.savefig(
            result_path + '/box_plot_ACCEPTED_' + str(res.pvalue) + body_part_dict[
                counter] + 'euler ' + euler_str + '.png')
        plt.close(fig)


def plot_cdf(samples_pk, samples_qk, counter, euler_idx, result_path, body_part_dict):
    global n1, n2
    fig = plt.figure()
    euler_str = str(euler_dict[euler_idx])
    if counter == 2 or counter == 5:
        euler_str = str(euler_dict[2])
    n_bins = 50
    n1, bins1, patches1 = plt.hist(samples_qk, n_bins, density=True, histtype='step', cumulative=True,
                                   label='agent')
    n2, bins2, patches2 = plt.hist(samples_pk, n_bins, density=True, histtype='step', cumulative=True,
                                   label='expert')
    plt.grid(True)
    plt.legend(loc="upper left")
    plt.title('Cumulative step histograms')
    plt.xlabel(
        'joint angle (degrees) for: ' + str(body_part_dict[counter]) + " euler angle : " + euler_str)
    plt.ylabel('Likelihood occurence')
    plt.savefig(
        result_path + '_CDF_' + body_part_dict[counter] + 'euler ' + euler_str + '.png')
    plt.close(fig)


def plot_pdf(samples_pk, samples_qk, counter, euler_idx, result_path, body_part_dict):
    fig = plt.figure()
    euler_str = str(euler_dict[euler_idx])
    if counter == 2 or counter == 5:
        euler_str = str(euler_dict[2])
    bins = np.histogram(np.hstack((samples_pk, samples_qk)), bins=50)[1]  # get the bin edges
    plt.hist(samples_pk, bins, alpha=0.5, density=True, label='expert')
    plt.hist(samples_qk, bins, alpha=0.5, density=True, label='agent')
    plt.grid(True)
    plt.legend(loc="upper left")
    plt.title('Histogram')
    plt.xlabel(
        'joint angle (degrees) for: ' + str(body_part_dict[counter]) + " euler angle : " + euler_str)
    plt.ylabel('Likelihood occurence')
    plt.savefig(
        result_path + '_PDF_agent_expert_' + body_part_dict[counter] + 'euler ' + euler_str + '.png')
    plt.close(fig)


def plot_movement(samples_pk, samples_qk, counter, euler_idx, result_path, body_part_dict):
    fig = plt.figure()
    euler_str = str(euler_dict[euler_idx])
    if counter == 2 or counter == 5:
        euler_str = str(euler_dict[2])

    plt.plot(samples_pk[:], 'r', label='expert')
    plt.plot(samples_qk[:], 'b', label='agent')
    plt.legend(loc="upper left")
    plt.ylabel('Joint angle (degrees)')
    plt.title(str(body_part_dict[counter]) + ' motion ' + euler_str)
    plt.savefig(result_path + '_movement' + body_part_dict[counter] + 'euler ' + euler_str + '.png')
    plt.close(fig)


def plot_RomError_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path, FB=False, full_rom=True):
    for i, episode in enumerate(agent_data_episodes):
        episode_path = result_path + '/compare_distributions/'
        if not os.path.exists(episode_path):
            os.makedirs(episode_path)
        saggital_rom_errors = {
            'pelvis_rom_errors':[],
            'hip_rom_errors': [],
            'knee_rom_errors': [],
            'feet_rom_errors': []}
        frontal_rom_errors = {
            'pelvis_rom_errors':[],
            'hip_rom_errors': [],
            'knee_rom_errors': [],
            'feet_rom_errors': []}
        transversal_rom_errors = {
            'pelvis_rom_errors':[],
            'hip_rom_errors': [],
            'knee_rom_errors': [],
            'feet_rom_errors': []}

        for c in range(7):
            samples_gc = []
            for gc_count, gc in enumerate(gcs):
                if FB:
                    agent_expert = AgentExpertFB(episode, expert_data)
                    align_and_resample_agent_distributions(agent_expert, gc, episode_path, 39)
                else:
                    agent_expert = AgentExpert(episode, expert_data)
                    align_and_resample_agent_distributions(agent_expert, gc, episode_path, 56)
                samples_gc.append(agent_expert.body_parts_agent[c])

            for euler_idx in [0, 1, 2]:
                if c == 2 or c == 5:
                    expert_rom = max(agent_expert.body_parts_expert[c]) - min(agent_expert.body_parts_expert[c])
                    expected_value = expert_rom
                    if expected_value < 1: expected_value = 1
                    gc_roms = [ abs(expert_rom - (max(samples_gc[0]) - min(samples_gc[0])))/expected_value,
                                abs(expert_rom - (max(samples_gc[1]) - min(samples_gc[1])))/expected_value,
                                abs(expert_rom - (max(samples_gc[2]) - min(samples_gc[2])))/expected_value,
                                abs(expert_rom - (max(samples_gc[3]) - min(samples_gc[3])))/expected_value,
                                abs(expert_rom - (max(samples_gc[4]) - min(samples_gc[4])))/expected_value]

                else:
                    expert_rom = max(agent_expert.body_parts_expert[c][:, euler_idx]) - min(
                        agent_expert.body_parts_expert[c][:, euler_idx])
                    expected_value = expert_rom
                    if expected_value < 1: expected_value = 1
                    gc_roms = [
                        abs((expert_rom - (max(samples_gc[0][:, euler_idx]) - min(samples_gc[0][:, euler_idx])))) / (
                                    expected_value),
                        abs((expert_rom - (max(samples_gc[1][:, euler_idx]) - min(samples_gc[1][:, euler_idx])))) / (
                            expected_value),
                        abs((expert_rom - (max(samples_gc[2][:, euler_idx]) - min(samples_gc[2][:, euler_idx])))) / (
                                    expected_value),
                        abs((expert_rom - (max(samples_gc[3][:, euler_idx]) - min(samples_gc[3][:, euler_idx])))) / (
                                    expected_value),
                        abs((expert_rom - (max(samples_gc[4][:, euler_idx]) - min(samples_gc[4][:, euler_idx])))) / (
                                    expected_value)]

                if euler_idx != 0 and c == 2 or euler_idx != 0 and c == 5:
                    continue

                if c == 0:
                    if euler_idx == 0:
                        frontal_rom_errors['pelvis_rom_errors'].append(np.array(gc_roms))
                    elif euler_idx == 1:
                        transversal_rom_errors['pelvis_rom_errors'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_rom_errors['pelvis_rom_errors'].append(np.array(gc_roms))
                if c == 1:
                    if euler_idx == 0:
                        frontal_rom_errors['hip_rom_errors'].append(np.array(gc_roms))
                    elif euler_idx == 1:
                        transversal_rom_errors['hip_rom_errors'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_rom_errors['hip_rom_errors'].append(np.array(gc_roms))
                elif c == 4:
                    if euler_idx == 0:
                        frontal_rom_errors['hip_rom_errors'].append(np.array(gc_roms))
                    elif euler_idx == 1:
                        transversal_rom_errors['hip_rom_errors'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_rom_errors['hip_rom_errors'].append(np.array(gc_roms))
                elif c == 2:
                    if euler_idx == 0:
                        frontal_rom_errors['knee_rom_errors'].append(np.array(gc_roms))
                elif c == 5:
                    if euler_idx == 0:
                        frontal_rom_errors['knee_rom_errors'].append(np.array(gc_roms))
                elif c == 3:
                    if euler_idx == 0:
                        frontal_rom_errors['feet_rom_errors'].append(np.array(gc_roms))
                    if euler_idx == 1:
                        transversal_rom_errors['feet_rom_errors'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_rom_errors['feet_rom_errors'].append(np.array(gc_roms))
                elif c == 6:
                    if euler_idx == 0:
                        frontal_rom_errors['feet_rom_errors'].append(np.array(gc_roms))
                    if euler_idx == 1:
                        transversal_rom_errors['feet_rom_errors'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_rom_errors['feet_rom_errors'].append(np.array(gc_roms))

        width = 0.35
        # Plotting the GCs of ROM error
        saggital_rom_errors['knee_rom_errors'] = frontal_rom_errors['knee_rom_errors']
        frontal_rom_errors['knee_rom_errors'] = []
        with open(result_path + '/avg_rom_error' + '.pickle', 'wb') as f:
            pickle.dump([saggital_rom_errors, frontal_rom_errors, transversal_rom_errors], f)
        error_bar_chart(result_path, saggital_rom_errors, width, 'Saggital')
        error_bar_chart(result_path, frontal_rom_errors, width, 'Frontal')
        error_bar_chart(result_path, transversal_rom_errors, width, 'Transversal')


def plot_symmetryRom_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path, FB=False, full_rom=True):
    for i, episode in enumerate(agent_data_episodes):
        episode_path = result_path + '/compare_distributions/'
        if not os.path.exists(episode_path):
            os.makedirs(episode_path)
        saggital_symmetry = {
            'hip_symmetry': [],
            'knee_symmetry': [],
            'feet_symmetry': []}
        frontal_symmetry = {
            'hip_symmetry': [],
            'knee_symmetry': [],
            'feet_symmetry': []}
        transversal_symmetry = {
            'hip_symmetry': [],
            'knee_symmetry': [],
            'feet_symmetry': []}
        for c in range(7):
            samples_gc = []
            for gc_count, gc in enumerate(gcs):
                if FB:
                    agent_expert = AgentExpertFB(episode, expert_data)
                    align_and_resample_agent_distributions(agent_expert, gc, episode_path, 39)
                else:
                    agent_expert = AgentExpert(episode, expert_data)
                    align_and_resample_agent_distributions(agent_expert, gc, episode_path, 56)
                samples_gc.append(agent_expert.body_parts_agent[c])

            for euler_idx in [0, 1, 2]:
                if c == 2 or c == 5:
                    gc_roms = [max(samples_gc[0]) - min(samples_gc[0]),
                               max(samples_gc[1]) - min(samples_gc[1]),
                               max(samples_gc[2]) - min(samples_gc[2]),
                               max(samples_gc[3]) - min(samples_gc[3]),
                               max(samples_gc[4]) - min(samples_gc[4]),
                               max(agent_expert.body_parts_expert[c]) - min(agent_expert.body_parts_expert[c])]
                else:
                    gc_roms = [max(samples_gc[0][:, euler_idx]) - min(samples_gc[0][:, euler_idx]),
                               max(samples_gc[1][:, euler_idx]) - min(samples_gc[1][:, euler_idx]),
                               max(samples_gc[2][:, euler_idx]) - min(samples_gc[2][:, euler_idx]),
                               max(samples_gc[3][:, euler_idx]) - min(samples_gc[3][:, euler_idx]),
                               max(samples_gc[4][:, euler_idx]) - min(samples_gc[4][:, euler_idx]),
                               max(agent_expert.body_parts_expert[c][:, euler_idx]) - min(
                                   agent_expert.body_parts_expert[c][:, euler_idx])]
                if euler_idx != 0 and c == 2 or euler_idx != 0 and c == 5:
                    continue
                if c == 1:
                    if euler_idx == 0:
                        frontal_symmetry['hip_symmetry'].append(np.array(gc_roms))
                    elif euler_idx == 1:
                        transversal_symmetry['hip_symmetry'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_symmetry['hip_symmetry'].append(np.array(gc_roms))
                elif c == 4:
                    if euler_idx == 0:
                        frontal_symmetry['hip_symmetry'].append(np.array(gc_roms))
                    elif euler_idx == 1:
                        transversal_symmetry['hip_symmetry'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_symmetry['hip_symmetry'].append(np.array(gc_roms))
                elif c == 2:
                    if euler_idx == 0:
                        frontal_symmetry['knee_symmetry'].append(np.array(gc_roms))
                elif c == 5:
                    if euler_idx == 0:
                        frontal_symmetry['knee_symmetry'].append(np.array(gc_roms))
                elif c == 3:
                    if euler_idx == 0:
                        frontal_symmetry['feet_symmetry'].append(np.array(gc_roms))
                    if euler_idx == 1:
                        transversal_symmetry['feet_symmetry'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_symmetry['feet_symmetry'].append(np.array(gc_roms))
                elif c == 6:
                    if euler_idx == 0:
                        frontal_symmetry['feet_symmetry'].append(np.array(gc_roms))
                    if euler_idx == 1:
                        transversal_symmetry['feet_symmetry'].append(np.array(gc_roms))
                    if euler_idx == 2:
                        saggital_symmetry['feet_symmetry'].append(np.array(gc_roms))

        fig = plt.figure()
        width = 0.35
        sym_sag_knees_GCs = abs(frontal_symmetry['knee_symmetry'][0] - frontal_symmetry['knee_symmetry'][1])
        sym_sag_hips_GCs = abs(saggital_symmetry['hip_symmetry'][0] - saggital_symmetry['hip_symmetry'][1])
        sym_fr_hips_GCs = abs(frontal_symmetry['hip_symmetry'][0] - frontal_symmetry['hip_symmetry'][1])
        sym_tran_hips_GCs = abs(transversal_symmetry['hip_symmetry'][0] - transversal_symmetry['hip_symmetry'][1])
        sym_sag_feet_GCs = abs(saggital_symmetry['feet_symmetry'][0] - saggital_symmetry['feet_symmetry'][1])
        sym_fr_feet_GCs = abs(frontal_symmetry['feet_symmetry'][0] - frontal_symmetry['feet_symmetry'][1])
        sym_tran_feet_GCs = abs(transversal_symmetry['feet_symmetry'][0] - transversal_symmetry['feet_symmetry'][1])

        if not full_rom:
            expert_rom_sym = sym_sag_knees_GCs[-1]
            expected_value = expert_rom_sym
            if expert_rom_sym < 1: expected_value = 1
            sym_sag_knees_GCs = [abs((agent - expert_rom_sym) / expected_value) for agent in sym_sag_knees_GCs[:-1]]

            expert_rom_sym = sym_sag_hips_GCs[-1]
            expected_value = expert_rom_sym
            if expert_rom_sym < 1: expected_value = 1
            sym_sag_hips_GCs = [abs((agent - expert_rom_sym) / expected_value) for agent in sym_sag_hips_GCs[:-1]]

            expert_rom_sym = sym_fr_hips_GCs[-1]
            expected_value = expert_rom_sym
            if expert_rom_sym < 1: expected_value = 1
            sym_fr_hips_GCs = [abs((agent - expert_rom_sym) / expected_value) for agent in sym_fr_hips_GCs[:-1]]

            expert_rom_sym = sym_tran_hips_GCs[-1]
            expected_value = expert_rom_sym
            if expert_rom_sym < 1: expected_value = 1
            sym_tran_hips_GCs = [abs((agent - expert_rom_sym) / expected_value) for agent in sym_tran_hips_GCs[:-1]]

            expert_rom_sym = sym_sag_feet_GCs[-1]
            expected_value = expert_rom_sym
            if expert_rom_sym < 1: expected_value = 1
            sym_sag_feet_GCs = [abs((agent - expert_rom_sym) / expected_value) for agent in sym_sag_feet_GCs[:-1]]

            expert_rom_sym = sym_fr_feet_GCs[-1]
            expected_value = expert_rom_sym
            if expert_rom_sym < 1: expected_value = 1
            sym_fr_feet_GCs = [abs((agent - expert_rom_sym) / expected_value) for agent in sym_fr_feet_GCs[:-1]]

            expert_rom_sym = sym_tran_feet_GCs[-1]
            expected_value= expert_rom_sym
            if expert_rom_sym<1:expected_value=1
            sym_tran_feet_GCs = [abs((agent - expert_rom_sym) / expected_value) for agent in sym_tran_feet_GCs[:-1]]

        # Plotting the GCs of saggital hips ROM sym
        with open(result_path+'/symmetry_rom_error' + '.pickle', 'wb') as f:
            pickle.dump([(np.mean(sym_sag_feet_GCs), np.mean(sym_sag_hips_GCs),np.mean(sym_sag_knees_GCs)),
                         (np.mean(sym_fr_feet_GCs), np.mean(sym_fr_hips_GCs)),
                         (np.mean(sym_tran_feet_GCs), np.mean(sym_tran_hips_GCs))], f)

        plot_sagittal_bar_chart(fig, result_path, sym_sag_feet_GCs, sym_sag_hips_GCs, sym_sag_knees_GCs, width,
                                full_rom)
        plot_frontal_transversal_bar_chart(fig, result_path, sym_fr_feet_GCs, sym_fr_hips_GCs, width, 'Frontal',
                                           full_rom)
        plot_frontal_transversal_bar_chart(fig, result_path, sym_tran_feet_GCs, sym_tran_hips_GCs, width, 'Transversal',
                                           full_rom)


def plot_frontal_transversal_bar_chart(fig, result_path, sym_fr_feet_GCs, sym_fr_hips_GCs, width, text, full_rom=True):
    plt.bar(0, sym_fr_hips_GCs[0], width, label='GC 1')
    plt.bar(width, sym_fr_hips_GCs[1], width, label='GC 2')
    plt.bar(2 * width, sym_fr_hips_GCs[2], width, label='GC 3')
    plt.bar(3 * width, sym_fr_hips_GCs[3], width, label='GC 4')
    plt.bar(4 * width, sym_fr_hips_GCs[4], width, label='GC 5')
    if full_rom:
        plt.bar(5 * width, sym_fr_hips_GCs[5], width, label='Expert')
    # Plotting the GCs of frontsl feet ROM sym
    plt.bar(7 * width, sym_fr_feet_GCs[0], width, label='GC 1')
    plt.bar(8 * width, sym_fr_feet_GCs[1], width, label='GC 2')
    plt.bar(9 * width, sym_fr_feet_GCs[2], width, label='GC 3')
    plt.bar(10 * width, sym_fr_feet_GCs[3], width, label='GC 4')
    plt.bar(11 * width, sym_fr_feet_GCs[4], width, label='GC 5')
    if full_rom:
        plt.bar(12 * width, sym_fr_feet_GCs[5], width, label='Expert')

    plt.ylabel("Error (%)")
    plt.tick_params(axis='both', which='major', labelsize=8)
    plt.tick_params(axis='both', which='minor', labelsize=8)

    if full_rom:
        plt.xticks([2 * width, 9 * width], ('Hip GCs (1-5) & Expert', 'Feet GCs (1-5) & Expert'))
        plt.title('ROM Symmetry Bar charts in ' + text + ' Plane ')
        plt.savefig(
            result_path + '/bar_chart_symmetry' + text + '_' + 'fullROM' + '.png')
    else:
        plt.xticks([2 * width, 9 * width], ('Hip GCs (1-5)', 'Feet GCs (1-5)'))
        plt.title('ROM Symmetry Errors for Generated Gait Cycles 1-5 in ' + text + ' Plane ')
        plt.savefig(
            result_path + '/bar_chart_symmetry' + text + '_' + 'error' + '.png')

    plt.close(fig)
    plt.close('all')


def error_bar_chart(result_path, error_array, width, plane):
    fig = plt.figure()

    plt.bar(0 * width, error_array['pelvis_rom_errors'][0][0], width, label='GC 1')
    plt.bar(1 * width, error_array['pelvis_rom_errors'][0][1], width, label='GC 2')
    plt.bar(2 * width, error_array['pelvis_rom_errors'][0][2], width, label='GC 3')
    plt.bar(3 * width, error_array['pelvis_rom_errors'][0][3], width, label='GC 4')
    plt.bar(4 * width, error_array['pelvis_rom_errors'][0][4], width, label='GC 5')

    # HIPS
    plt.bar(6* width, error_array['hip_rom_errors'][0][0], width, label='GC 1')
    plt.bar(7 * width, error_array['hip_rom_errors'][0][1], width, label='GC 2')
    plt.bar(8 * width, error_array['hip_rom_errors'][0][2], width, label='GC 3')
    plt.bar(9 * width, error_array['hip_rom_errors'][0][3], width, label='GC 4')
    plt.bar(10 * width, error_array['hip_rom_errors'][0][4], width, label='GC 5')

    plt.bar(12* width, error_array['hip_rom_errors'][1][0], width, label='GC 1')
    plt.bar(13* width, error_array['hip_rom_errors'][1][1], width, label='GC 2')
    plt.bar(14* width, error_array['hip_rom_errors'][1][2], width, label='GC 3')
    plt.bar(15* width, error_array['hip_rom_errors'][1][3], width, label='GC 4')
    plt.bar(16 * width, error_array['hip_rom_errors'][1][4], width, label='GC 5')

    #FEET
    plt.bar(18* width, error_array['feet_rom_errors'][0][0], width, label='GC 1')
    plt.bar(19* width, error_array['feet_rom_errors'][0][1], width, label='GC 2')
    plt.bar(20* width, error_array['feet_rom_errors'][0][2], width, label='GC 3')
    plt.bar(21 * width, error_array['feet_rom_errors'][0][3], width, label='GC 4')
    plt.bar(22 * width, error_array['feet_rom_errors'][0][4], width, label='GC 5')

    plt.bar(24* width, error_array['feet_rom_errors'][1][0], width, label='GC 1')
    plt.bar(25* width, error_array['feet_rom_errors'][1][1], width, label='GC 2')
    plt.bar(26* width, error_array['feet_rom_errors'][1][2], width, label='GC 3')
    plt.bar(27 * width, error_array['feet_rom_errors'][1][3], width, label='GC 4')
    plt.bar(28 * width, error_array['feet_rom_errors'][1][4], width, label='GC 5')

    if plane == 'Saggital':
        plt.bar(30 * width, error_array['knee_rom_errors'][0][0], width, label='GC 1')
        plt.bar(31 * width, error_array['knee_rom_errors'][0][1], width, label='GC 2')
        plt.bar(32 * width, error_array['knee_rom_errors'][0][2], width, label='GC 3')
        plt.bar(33 * width, error_array['knee_rom_errors'][0][3], width, label='GC 4')
        plt.bar(34 * width, error_array['knee_rom_errors'][0][4], width, label='GC 5')

        plt.bar(36 * width, error_array['knee_rom_errors'][1][0], width, label='GC 1')
        plt.bar(37 * width, error_array['knee_rom_errors'][1][1], width, label='GC 2')
        plt.bar(38 * width, error_array['knee_rom_errors'][1][2], width, label='GC 3')
        plt.bar(39 * width, error_array['knee_rom_errors'][1][3], width, label='GC 4')
        plt.bar(40 * width, error_array['knee_rom_errors'][1][4], width, label='GC 5')

    plt.ylabel("Error (%)")


    if plane == 'Saggital':
        plt.tick_params(axis='both', which='major', labelsize=8)
        plt.tick_params(axis='both', which='minor', labelsize=8)
        plt.xticks([2* width, 11 * width, 23 * width, 35 * width], ('Pelvis GCs (1-5)','Hip GCs (1-5) R & L', 'Feet GCs (1-5) R & L', 'Knees GCs (1-5) R & L'))
    else:
        plt.tick_params(axis='both', which='major', labelsize=10)
        plt.tick_params(axis='both', which='minor', labelsize=10)
        plt.xticks([2 * width,11 * width, 23 * width], ('Pelvis GCs (1-5)', 'Hip GCs (1-5) R & L', 'Feet GCs (1-5) R & L'))
    plt.title('ROM Errors for Generated Gait Cycles 1-5 in ' + plane + ' Plane ')
    plt.savefig(
        result_path + '/ErrorROM_bar_chart_' + plane + '.png')
    plt.close(fig)


def plot_sagittal_bar_chart(fig, result_path, sym_sag_feet_GCs, sym_sag_hips_GCs, sym_sag_knees_GCs, width,
                            full_rom=True):
    plt.bar(0, sym_sag_hips_GCs[0], width, label='GC 1')
    plt.bar(width, sym_sag_hips_GCs[1], width, label='GC 2')
    plt.bar(2 * width, sym_sag_hips_GCs[2], width, label='GC 3')
    plt.bar(3 * width, sym_sag_hips_GCs[3], width, label='GC 4')
    plt.bar(4 * width, sym_sag_hips_GCs[4], width, label='GC 5')
    if full_rom:
        plt.bar(5 * width, sym_sag_hips_GCs[5], width, label='Expert')
    # Plotting the GCs of saggital feet ROM sym
    plt.bar(7 * width, sym_sag_feet_GCs[0], width, label='GC 1')
    plt.bar(8 * width, sym_sag_feet_GCs[1], width, label='GC 2')
    plt.bar(9 * width, sym_sag_feet_GCs[2], width, label='GC 3')
    plt.bar(10 * width, sym_sag_feet_GCs[3], width, label='GC 4')
    plt.bar(11 * width, sym_sag_feet_GCs[4], width, label='GC 5')
    if full_rom:
        plt.bar(12 * width, sym_sag_feet_GCs[5], width, label='Expert')
    # Plotting the GCs of saggital knees ROM sym
    plt.bar(14 * width, sym_sag_knees_GCs[0], width, label='GC 1')
    plt.bar(15 * width, sym_sag_knees_GCs[1], width, label='GC 2')
    plt.bar(16 * width, sym_sag_knees_GCs[2], width, label='GC 3')
    plt.bar(17 * width, sym_sag_knees_GCs[3], width, label='GC 4')
    plt.bar(18 * width, sym_sag_knees_GCs[4], width, label='GC 5')
    if full_rom:
        plt.bar(19 * width, sym_sag_knees_GCs[5], width, label='Expert')
    plt.ylabel("Error (%)")

    if full_rom:
        plt.tick_params(axis='both', which='major', labelsize=8)
        plt.tick_params(axis='both', which='minor', labelsize=8)
        plt.xticks([2 * width, 9 * width, 15 * width],
                   ('Hip GCs (1-5) & Expert', 'Knees GCs (1-5) & Expert', 'Feet GCs (1-5) & Expert'))
        plt.title('ROM Symmetry Bar charts in Saggital Plane ')
        plt.savefig(
            result_path + '/bar_chart_saggital_symmetry' + 'fullROM' + '.png')
    else:
        plt.tick_params(axis='both', which='major', labelsize=10)
        plt.tick_params(axis='both', which='minor', labelsize=10)
        plt.xticks([2 * width, 9 * width, 15 * width], ('Hip GCs (1-5)', 'Knees GCs (1-5)', 'Feet GCs (1-5)'))
        plt.title('ROM Symmetry Errors for Generated Gait Cycles 1-5 in Saggital Plane ')
        plt.savefig(
            result_path + '/bar_chart_saggital_symmetry' + 'error' + '.png')

    plt.close(fig)
    plt.close('all')


def plot_boxPlots_FB_for_GCs(agent_data_episodes, expert_data, gcs, result_path):
    for i, episode in enumerate(agent_data_episodes):
        episode_path = result_path + '/compare_distributions/'

        if not os.path.exists(episode_path):
            os.makedirs(episode_path)
        euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}

        for c in range(7):
            samples_gc = []
            for gc_count, gc in enumerate(gcs):
                agent_expert = AgentExpertFB(episode, expert_data)
                align_and_resample_agent_distributions(agent_expert, gc, episode_path, 39)
                samples_gc.append(agent_expert.body_parts_agent[c])

            for euler_idx in [0, 1, 2]:
                euler_str = str(euler_dict[euler_idx])
                if c == 2 or c == 5:
                    euler_str = (euler_dict[2])
                    gc_roms = [max(samples_gc[0]) - min(samples_gc[0]),
                               max(samples_gc[1]) - min(samples_gc[1]),
                               max(samples_gc[2]) - min(samples_gc[2]),
                               max(samples_gc[3]) - min(samples_gc[3]),
                               max(samples_gc[4]) - min(samples_gc[4]),
                               max(agent_expert.body_parts_expert[c]) - min(agent_expert.body_parts_expert[c])]

                    boxes = [samples_gc[0], samples_gc[1], samples_gc[2], samples_gc[3],
                             samples_gc[4], agent_expert.body_parts_expert[c]]


                else:
                    gc_roms = [max(samples_gc[0][:, euler_idx]) - min(samples_gc[0][:, euler_idx]),
                               max(samples_gc[1][:, euler_idx]) - min(samples_gc[1][:, euler_idx]),
                               max(samples_gc[2][:, euler_idx]) - min(samples_gc[2][:, euler_idx]),
                               max(samples_gc[3][:, euler_idx]) - min(samples_gc[3][:, euler_idx]),
                               max(samples_gc[4][:, euler_idx]) - min(samples_gc[4][:, euler_idx]),
                               max(agent_expert.body_parts_expert[c][:, euler_idx]) - min(
                                   agent_expert.body_parts_expert[c][:, euler_idx])]

                    boxes = [samples_gc[0][:, euler_idx], samples_gc[1][:, euler_idx], samples_gc[2][:, euler_idx],
                             samples_gc[3][:, euler_idx],
                             samples_gc[4][:, euler_idx], agent_expert.body_parts_expert[c][:, euler_idx]]
                if euler_idx != 0 and c == 2 or euler_idx != 0 and c == 5:
                    continue

                # align_and_resample_agent_distributions(agent_expert, gc, episode_path, 39)
                # colors = ['salmon', 'tomato', 'darksalmon', 'coral', 'orangered', 'chocolate']
                colors = ['cadetblue', 'powderblue',
                          'skyblue', 'lightskyblue',
                          'steelblue', 'teal']
                fig = plt.figure()
                bplot1 = plt.boxplot(
                    boxes,
                    vert=True,  # vertical box alignment
                    patch_artist=True,  # fill with color
                    labels=['GC 1', 'GC 2', 'GC 3', 'GC 4', 'GC 5', 'Expert'])  # will be used to label x-ticks
                plt.tick_params(axis='both', which='major', labelsize=6)
                plt.tick_params(axis='both', which='minor', labelsize=6)
                rom_index = 0
                for patch, color in zip(bplot1['boxes'], colors):
                    rom = gc_roms[rom_index]
                    y_coord = bplot1['medians'][rom_index].get_ydata()[0]
                    rom_index = rom_index + 1
                    patch.set_facecolor(color)
                    plt.text(rom_index - 0.22, y_coord, str(round(rom, 2)), fontsize=8, verticalalignment='bottom')

                plt.ylabel('Joint angle values (degrees)')
                plt.title('Box plots of ' + body_part_dict[c] + ' euler ' + euler_str)
                plt.savefig(
                    result_path + '/box_plot_' + body_part_dict[c] + 'euler ' + euler_str + '.png')
                plt.close(fig)
                plt.close('all')


def plot_boxPlots_for_GCs(agent_data_episodes, expert_data, gcs, result_path, expert_count):
    for i, episode in enumerate(agent_data_episodes):
        episode_path = result_path + '/compare_distributions/'

        if not os.path.exists(episode_path):
            os.makedirs(episode_path)
        euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}

        for c in range(7):
            samples_gc = []
            for gc_count, gc in enumerate(gcs):
                agent_expert = AgentExpert(episode, expert_data)
                align_and_resample_agent_distributions(agent_expert, gc, episode_path, expert_count)
                samples_gc.append(agent_expert.body_parts_agent[c])

            for euler_idx in [0, 1, 2]:
                euler_str = str(euler_dict[euler_idx])
                if c == 2 or c == 5:
                    euler_str = (euler_dict[2])
                    gc_roms = [max(samples_gc[0]) - min(samples_gc[0]),
                               max(samples_gc[1]) - min(samples_gc[1]),
                               max(samples_gc[2]) - min(samples_gc[2]),
                               max(samples_gc[3]) - min(samples_gc[3]),
                               max(samples_gc[4]) - min(samples_gc[4]),
                               max(agent_expert.body_parts_expert[c]) - min(agent_expert.body_parts_expert[c])]

                    boxes = [samples_gc[0], samples_gc[1], samples_gc[2], samples_gc[3],
                             samples_gc[4], agent_expert.body_parts_expert[c]]


                else:
                    gc_roms = [max(samples_gc[0][:, euler_idx]) - min(samples_gc[0][:, euler_idx]),
                               max(samples_gc[1][:, euler_idx]) - min(samples_gc[1][:, euler_idx]),
                               max(samples_gc[2][:, euler_idx]) - min(samples_gc[2][:, euler_idx]),
                               max(samples_gc[3][:, euler_idx]) - min(samples_gc[3][:, euler_idx]),
                               max(samples_gc[4][:, euler_idx]) - min(samples_gc[4][:, euler_idx]),
                               max(agent_expert.body_parts_expert[c][:, euler_idx]) - min(
                                   agent_expert.body_parts_expert[c][:, euler_idx])]

                    boxes = [samples_gc[0][:, euler_idx], samples_gc[1][:, euler_idx], samples_gc[2][:, euler_idx],
                             samples_gc[3][:, euler_idx],
                             samples_gc[4][:, euler_idx], agent_expert.body_parts_expert[c][:, euler_idx]]
                if euler_idx != 0 and c == 2 or euler_idx != 0 and c == 5:
                    continue

                # align_and_resample_agent_distributions(agent_expert, gc, episode_path, 39)
                # colors = ['salmon', 'tomato', 'darksalmon', 'coral', 'orangered', 'chocolate']
                colors = ['cadetblue', 'powderblue',
                          'skyblue', 'lightskyblue',
                          'steelblue', 'teal']
                fig = plt.figure()
                bplot1 = plt.boxplot(
                    boxes,
                    vert=True,  # vertical box alignment
                    patch_artist=True,  # fill with color
                    labels=['GC 1', 'GC 2', 'GC 3', 'GC 4', 'GC 5', 'Expert'])  # will be used to label x-ticks

                plt.tick_params(axis='both', which='major', labelsize=6)
                plt.tick_params(axis='both', which='minor', labelsize=6)
                rom_index = 0
                for patch, color in zip(bplot1['boxes'], colors):
                    rom = gc_roms[rom_index]
                    y_coord = bplot1['medians'][rom_index].get_ydata()[0]
                    rom_index = rom_index + 1
                    patch.set_facecolor(color)
                    plt.text(rom_index - 0.22, y_coord, str(round(rom, 2)), fontsize=8, verticalalignment='bottom')

                plt.ylabel('Joint angle values (degrees)')
                plt.title('Box plots of ' + body_part_dict[c] + ' euler ' + euler_str)
                plt.savefig(
                    result_path + '/box_plot_' + body_part_dict[c] + 'euler ' + euler_str + '.png')
                plt.close(fig)
                plt.close('all')


def calculate_pelvis_ROM(body_parts):
    # calc pelvis ROM frontal
    min_agent_degrees = min(body_parts[0][:, 0])
    max_agent_degrees = max(body_parts[0][:, 0])
    ROM_frontal = max_agent_degrees - min_agent_degrees
    # calc pelvis ROM tr
    min_agent_degrees = min(body_parts[0][:, 1])
    max_agent_degrees = max(body_parts[0][:, 1])
    ROM_transversal = max_agent_degrees - min_agent_degrees
    # calc pelvis ROM sagg
    min_agent_degrees = min(body_parts[0][:, 2])
    max_agent_degrees = max(body_parts[0][:, 2])
    ROM_saggital = max_agent_degrees - min_agent_degrees
    return ROM_frontal, ROM_saggital, ROM_transversal


def calculate_ROM_hip_symmetry(body_parts):
    # calc ROM hip symmetry frontal
    min_agent_degrees = min(body_parts[1][:, 0])
    max_agent_degrees = max(body_parts[1][:, 0])
    ROM_frontal_right = max_agent_degrees - min_agent_degrees
    min_agent_degrees = min(body_parts[4][:, 0])
    max_agent_degrees = max(body_parts[4][:, 0])
    ROM_frontal_left = max_agent_degrees - min_agent_degrees
    hip_ROM_symmetry_frontal = abs(ROM_frontal_right - ROM_frontal_left)
    # calc ROM hip symmetry tr
    min_agent_degrees = min(body_parts[1][:, 1])
    max_agent_degrees = max(body_parts[1][:, 1])
    ROM_transversal_right = max_agent_degrees - min_agent_degrees
    min_agent_degrees = min(body_parts[4][:, 1])
    max_agent_degrees = max(body_parts[4][:, 1])
    ROM_transversal_left = max_agent_degrees - min_agent_degrees
    hip_ROM_symmetry_transversal = abs(ROM_transversal_right - ROM_transversal_left)
    # calc ROM hip symmetry sagg
    min_agent_degrees = min(body_parts[1][:, 2])
    max_agent_degrees = max(body_parts[1][:, 2])
    ROM_saggital_right = max_agent_degrees - min_agent_degrees
    min_agent_degrees = min(body_parts[4][:, 2])
    max_agent_degrees = max(body_parts[4][:, 2])
    ROM_saggital_left = max_agent_degrees - min_agent_degrees
    hip_ROM_symmetry_saggital = abs(ROM_saggital_right - ROM_saggital_left)
    return hip_ROM_symmetry_frontal, hip_ROM_symmetry_saggital, hip_ROM_symmetry_transversal
