import pickle

from DeepMimic_plotter_util import *


gc1 = [893, 1852]
gc2 = [1852, 2871]
gc3 = [3560,4471]
gc4 = [4471,5431]
gc5 = [5431,6593]
gc8 = [11500, 12400]#approx
gc10 = [0, 7500]

gcs = [gc1, gc3, gc4,gc5,gc8,gc10]

id = '5'
expert_data_path = "C:/Users/kt199/Documents/Output_(trainedonH5_not_fitted_body)/H" + id + "/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_LB"
expert_data, agent_data_episodes = get_agent_and_expert_data(expert_data_path)

# Plot ROM for each "episode"
counter = 0
SAMPLE_SIZE = 50

plot_symmetryRom_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=False,full_rom=True)
#plot_RomError_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=False,full_rom=False)
