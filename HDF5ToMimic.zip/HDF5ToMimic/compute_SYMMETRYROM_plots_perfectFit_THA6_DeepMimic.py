import pickle

from DeepMimic_plotter_util import *


gc1 = [984, 3065]
gc2 = [3065, 5065]
gc3 = [5065,7268]
gc4 = [7268,9348]
gc5 = [9348,11428]

gcs = [gc1, gc2, gc3, gc4,gc5]

expert_data_path = "C:/Users/kt199/Documents/Results_TEP6/rolled_out_traj_policyH5_GT_THA6_perfect_fit/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA"
expert_data, agent_data_episodes = get_agent_and_expert_data(expert_data_path)
expert_data = expert_data[12:78]

# Plot ROM for each "episode"
counter = 0
SAMPLE_SIZE = 50

plot_symmetryRom_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=False,full_rom=True)
#plot_RomError_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=False,full_rom=False)
