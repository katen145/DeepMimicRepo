from utils.loadHDF5 import SettingReadHDF5, LoadHDF5
from utils.visutilsQt import drawSkelQtWithLabels
from utils.helpersMotionDirection import computePrimitvesWalkingStraight
from utils.helpersMotionDirection import sequentializePrimitives

if (__name__ == '__main__'):
    p = SettingReadHDF5("/home/taetz/Desktop/Shared_Projects/Data/data/HDF5/")
    loader = LoadHDF5(p)
    p.labels = 'initial_contact_right'

    dictLabels, aData, iData, cData = loader.loadForVisualization('P1', '_6_min_walking_test', load=['a', 'c'], nTimeLimit=2000)

    dict_labels = {}
    dict_labels['Initial Contact (L(red)/R(green))'] = dictLabels['ic']
    dict_labels['Turning Segmentation (L(red)/R(green))'] = dictLabels['seg']

    idxOrig = cData.segValueByNames["RightFoot"]

    # Motion primitive segmentation (from ic-to-ic) (Option 1)
    #primitiveList = computePrimitves(dictLabels['ic'][1], aData, idxOrig, cData)
    #aDataSegments = sequentializePrimitives(primitiveList, aData)

    # Motion segmentation for walking straight   (Option 2)
    straightWalkingList = computePrimitvesWalkingStraight(dictLabels['ic'][1], aData, idxOrig, cData, dict_labels=dictLabels['seg'])
    aDataSegments = sequentializePrimitives(straightWalkingList, aData)

    drawSkelQtWithLabels(aDataSegments, cData, "Lower Body", [0, 1, 1, 0.5], dict_labels=dict_labels)
