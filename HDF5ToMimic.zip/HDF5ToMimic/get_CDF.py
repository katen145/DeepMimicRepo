import json
import matplotlib.pyplot as plt
import numpy as np
import os
from scipy.stats import entropy
from scipy import stats
from scipy import special
from scipy.stats import norm
from matplotlib import pyplot as plt
import seaborn as sns
from scipy.stats.kde import gaussian_kde
from scipy.stats import norm
from agent import *

import scipy

body_part_dict = {
    0: 'right_hip',
    1: 'right_knee',
    2: 'right_foot',
    3: 'left_hip',
    4: 'left_knee',
    5: 'left_foot'
}

import math

id='5'
path = "/home/novikova/thesis/mimic/DeepMimic/Output_(trainedonH5_not_fitted_body)/H"+id+"/"
sample_size = 50


expert_file = path + "expert.txt"
agent_file = path + "agent.txt"

with open(expert_file) as json_file:
    data = json.load(json_file)
    expert_arr = np.array(data["Frames"])
    expert_data = expert_arr[:, 1:]

# import re
right_hip = expert_data[:, 7:11]
right_knee = expert_data[:, 11:12]
right_ankle = expert_data[:, 12:16]
left_hip = expert_data[:, 16:20]
left_knee = expert_data[:, 20:21]
left_ankle = expert_data[:, 21:]

f = open(agent_file, "r")
lines = [line.rstrip() for line in f if line.rstrip().find('Pose') != -1]

agent_episode_frames = []
frame_values = []
episodes = []
for line in lines:
    line = line.replace('[', '').replace(']', '').replace('"Pose":', '')
    values = line.split(',')
    for val in values:  # val == '['  or
        if val != '':
            frame_values.append(float(val))
    agent_episode_frames.append(np.array(frame_values))
    frame_values = []

episodes.append(np.array(agent_episode_frames))

# Plot ROM for each episode
counter = 0
for i, episode in enumerate(episodes):
    episode_path = '/home/novikova/thesis/mimic/DeepMimic/Output_(trainedonH5_not_fitted_body)/H'+id+'/compare_distributions/'
    if not os.path.exists(episode_path):
        os.makedirs(episode_path)
    agent_expert = AgentExpert(episode, expert_data)
    euler_dict = {0: 'x', 1: 'y', 2: 'z'}

    counter = 0
    indexes_expert = [f for f in range(expert_data.shape[0])]
    indexes_agent = [f for f in range(episode.shape[0])]
    for body_part_euler_rot_agent, body_part_euler_rot_expert in agent_expert:
        for euler_idx in [0, 1, 2]:
            print(" BODY PART " + str(body_part_dict[counter]) + " euler angle index:" + str(euler_idx))
            if euler_idx != 0 and counter == 1 or euler_idx != 0 and counter == 4:
                continue
            elif counter == 1 or counter == 4:
                samples_pk = body_part_euler_rot_expert[:]
                samples_qk = body_part_euler_rot_agent[:]
            else:
                samples_pk = body_part_euler_rot_expert[:, euler_idx]
                samples_qk = body_part_euler_rot_agent[:, euler_idx]
           #plot cdf for agent and expert
            plt.figure()
            n_bins= 50
            n1,bins1,patches1 = plt.hist(samples_qk,n_bins,density = True, histtype= 'step',cumulative = True)
            n2,bins2,patches2 = plt.hist(samples_pk,n_bins,density = True, histtype= 'step',cumulative = True)
            plt.grid(True)
            plt.title('Cumulative step histograms')
            plt.xlabel('joint movement '+str(body_part_dict[counter])+ " euler angle index:" + str(euler_idx))
            plt.ylabel('Likelihood occurence')
            plt.savefig(episode_path + body_part_dict[counter] + 'euler # ' + str(euler_idx) + '_cdf.png')
            d1=scipy.spatial.distance.minkowski(n1, n2 ,p=float('inf'))
            x=d1/1.358
            sample_size= int(2/(x*x))
            print(sample_size)
            samples_pk_indexes = np.random.choice(indexes_expert, sample_size)
            samples_qk_indexes = np.random.choice(indexes_agent, sample_size)
            if sample_size> len(indexes_expert):
                tiler=math.ceil(sample_size/len(indexes_expert))
                samples_pk=np.tile(samples_pk,tiler)
            samples_pk = samples_pk[samples_pk_indexes]
            samples_qk = samples_qk[samples_qk_indexes]
            print(euler_dict[euler_idx])
            res = stats.ks_2samp(samples_pk, samples_qk)

            if res.pvalue < 0.05:
                print("significant difference, null hypothesis rejected ",res.pvalue)
                plt.figure()
                bplot1 = plt.boxplot([samples_qk, samples_pk],
                                     vert=True,  # vertical box alignment
                                     patch_artist=True,  # fill with color
                                     labels=['agent', 'expert'])  # will be used to label x-ticks
                colors = ['pink', 'lightblue']
                for patch, color in zip(bplot1['boxes'], colors):
                    patch.set_facecolor(color)
                plt.ylabel('values')
                plt.title('Box plots of ' + body_part_dict[counter])
                plt.savefig(episode_path + '/REJECTED_' +str(res.pvalue)+ body_part_dict[counter] + 'euler # ' + str(euler_idx) + '.png')
            else:
                print("hypothesis accepted, similar enough distributions ",res.pvalue)
                plt.figure()
                bplot1 = plt.boxplot([samples_qk, samples_pk],
                                     vert=True,  # vertical box alignment
                                     patch_artist=True,  # fill with color
                                     labels=['agent', 'expert'])  # will be used to label x-ticks
                colors = ['pink', 'lightblue']
                for patch, color in zip(bplot1['boxes'], colors):
                    patch.set_facecolor(color)
                plt.ylabel('values')
                plt.title('Box plots of ' + body_part_dict[counter])
                plt.savefig(episode_path + '/ACCEPTED_' +str(res.pvalue)+ body_part_dict[counter] + 'euler # ' + str(euler_idx) + '.png')
        counter += 1

