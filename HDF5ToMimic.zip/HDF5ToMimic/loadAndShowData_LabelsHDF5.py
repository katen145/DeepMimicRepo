from utils.loaddatasets.hdf5.loadHDF5 import SettingReadHDF5,LoadHDF5
from utils.loaddatasets.visualize.visutilsQt import drawSkelQtWithLabels

p = SettingReadHDF5("data/")
loader = LoadHDF5(p)

dictLabels, aData, iData, cData = loader.loadForVisualization('P1', '_6_min_walking_test', load=['a', 'c'], nTimeLimit=10000)
#dictSkel = loader.loadHDF5ToDict('P1', '_6_min_walking_test', ['listSegNames', 'nSegs', 'nIMUs', 'mrp_si', 'i_s', 'pSeg_s'], 1000,'skel') #.loadForVisualization('P1', '_6_min_walking_test', load=['a', 'c'], nTimeLimit=1000)
#dictSkel = self.loadHDF5ToDict(subj, movement, listsk, nTime, 'skel')
#dictData = self.loadHDF5ToDict(subj, movement, listdata, int(nTimeLimit), 'data')
#dictLabels = self.loadHDF5ToDict(subj, movement, list, nTime, 'labels')

#print(dictSkel)
dict_labels = {}
dict_labels['Initial Contact (L(red)/R(green))'] = dictLabels['ic']
dict_labels['Turning Segmentation (L(red)/R(green))'] = dictLabels['seg']

drawSkelQtWithLabels(aData, cData, "Lower Body", [0, 1, 1, 0.5], dict_labels)

