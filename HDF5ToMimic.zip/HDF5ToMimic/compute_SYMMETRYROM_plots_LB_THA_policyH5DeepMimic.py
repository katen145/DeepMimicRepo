import pickle

from DeepMimic_plotter_util import *


gc1 = [6275, 7074]
gc3 = [8100,8874]
gc4 =[5254, 6275]
gc5 = [7074, 8100]
gc6 =[8874, 9895]


gcs = [gc1, gc3, gc4,gc5,gc6]


expert_data_path = "C:/Users/kt199/Documents/Results_TEP6/rolled_out_traj_policyH5_GT_THA6/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5"
expert_data, agent_data_episodes = get_agent_and_expert_data(expert_data_path)
expert_data=expert_data[12:78]
# Plot ROM for each "episode"
counter = 0
SAMPLE_SIZE = 50

plot_symmetryRom_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=False,full_rom=True)
#plot_RomError_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=False,full_rom=False)
