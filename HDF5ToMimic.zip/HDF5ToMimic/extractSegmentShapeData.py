import sys

sys.path.append('..')

from loaddatasets.hdf5.helpersMotionDirection import computePrimitvesWalkingStraight, sequentializePrimitives, \
    computePrimitves
from loaddatasets.hdf5.loadHDF5 import SettingReadHDF5, LoadHDF5
# from loaddatasets.visualize.visutilsQt import drawSkelQtWithLabels
from dm_control.mujoco.wrapper import mjbindings
import numpy as np
from six.moves import range
import numpy as np


def computeHeight(pt):
    p1 = np.array([pt[0], pt[1]])
    pAux = np.array([0.0, pt[0]])
    p1Norm = np.linalg.norm(p1)
    pAuxNorm = np.linalg.norm(pAux)
    alpha = np.arcsin(pAuxNorm / p1Norm)
    return np.cos(alpha) * p1Norm

id='5'
if __name__ == "__main__":
    p = SettingReadHDF5('./InputHdf/', id)
    loader = LoadHDF5(p)

    # Load config data 'c'
    dictLabels, aData, iData, cData = loader.loadForVisualization('P'+id, '_6_min_walking_test', load=['a', 'c'],
                                                                          nTimeLimit=1000)

    # Fill dictionary with measures
    dictSegs = {}
    p1 = np.asarray(cData.segCalib[0].points[1])
    p2 = np.asarray(cData.segCalib[0].points[2])
    p3 = np.asarray(cData.segCalib[0].points[3])
    p5 = np.asarray(cData.segCalib[0].points[5])
    inner_to_outer_1 = np.linalg.norm(p3 - p1)
    inner_to_outer_2 = np.linalg.norm(p5 - p2)
    avg_tracker_distance = (inner_to_outer_1 + inner_to_outer_2) / 2
    #dictSegs['Pelvis_length'] = np.linalg.norm(p2 - p1)
    dictSegs['Pelvis_length'] = np.linalg.norm(p5 - p3)
    p1 = np.asarray(cData.segCalib[1].points[0])
    p2 = np.asarray(cData.segCalib[1].points[1])
    dictSegs['LeftUpperLeg_length'] = np.linalg.norm(p2 - p1)
    p1 = np.asarray(cData.segCalib[2].points[0])
    p2 = np.asarray(cData.segCalib[2].points[1])
    dictSegs['RightUpperLeg_length'] = np.linalg.norm(p2 - p1)
    p1 = np.asarray(cData.segCalib[3].points[0])
    p2 = np.asarray(cData.segCalib[3].points[2])
    dictSegs['LeftLowerLeg_length'] = np.linalg.norm(p2 - p1)
    p1 = np.asarray(cData.segCalib[4].points[0])
    p2 = np.asarray(cData.segCalib[4].points[2])
    dictSegs['RightLowerLeg_length'] = np.linalg.norm(p2 - p1)

    # Feet with length, width, and height
    p1 = np.asarray(cData.segCalib[5].points[7])
    p2 = np.asarray(cData.segCalib[5].points[8])
    dictSegs['LeftFoot_length'] = np.linalg.norm(p2 - p1)
    p1 = np.asarray(cData.segCalib[5].points[6])
    p2 = np.asarray(cData.segCalib[5].points[9])
    dictSegs['LeftFoot_width'] = np.linalg.norm(p2 - p1)
    dictSegs['LeftFoot_height'] = computeHeight(np.asarray(cData.segCalib[5].points[7]))

    p1 = np.asarray(cData.segCalib[6].points[7])
    p2 = np.asarray(cData.segCalib[6].points[8])
    dictSegs['RightFoot_length'] = np.linalg.norm(p2 - p1)
    p1 = np.asarray(cData.segCalib[6].points[6])
    p2 = np.asarray(cData.segCalib[6].points[9])
    dictSegs['RightFoot_width'] = np.linalg.norm(p2 - p1)
    dictSegs['RightFoot_height'] = computeHeight(np.asarray(cData.segCalib[6].points[7]))

    print(dictSegs)
    print('Done!')
