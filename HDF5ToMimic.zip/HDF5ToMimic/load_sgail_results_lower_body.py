from DeepMimic_plotter_util import *
from numpy import load

body_part_dict = {
    0: 'root0',
    1: 'root1',
    2: 'root2',
    3: 'right_hip',
    4: 'right_knee',
    5: 'right_foot',
    6: 'left_hip',
    7: 'left_knee',
    8: 'left_foot'
}


def print_out_ROM(result_path, text, gc_count,qpos_ind):
    # Program to show various ways to read and
    # write data in a file.
    file1 = open(result_path + "/_rom_gait_cycle_" + str(gc_count) + ".txt", "a")
    file1.write("======================================================= \n")
    file1.write(text + " \n")
    #file1.write('agent \n')
    min_agent_degrees = min(samples_qk[qpos_ind,:])
    max_agent_degrees = max(samples_qk[qpos_ind,:])
    #file1.write('agent min ' + str(min_agent_degrees) + "\n")
    #file1.write('agent max ' + str(max_agent_degrees) + "\n")
    ROM = max_agent_degrees - min_agent_degrees
    file1.write('agent rom ' + str(ROM) + "\n")
    #file1.write('expert \n')
    min_expert_degrees = min(samples_pk[qpos_ind,:])
    max_expert_degrees = max(samples_pk[qpos_ind,:])
    #file1.write('expert min ' + str(min_expert_degrees) + "\n")
    #file1.write('expert max ' + str(max_expert_degrees) + "\n")
    ROM = max_expert_degrees - min_expert_degrees
    file1.write('expert rom ' + str(ROM) + "\n")
    file1.close()  # to change file access modes

if (__name__ == '__main__'):
    data_comparison = list()
    #samples = 120
    episode_path = '/home/novikova/thesis/'
    result_path = '/home/novikova/thesis/SeptemberResults/SGAIL_LB/'
    if not os.path.exists(result_path):
        os.makedirs(result_path)
    expert_file = "/home/novikova/thesis/yhealthy_zx_P05.npz"
    traj_data = np.load(expert_file, allow_pickle=True)
    qpos_list = traj_data['qpos']
    qpos_list = qpos_list[0][:, :]
    qpos_list_expert = qpos_list[6:63, :9]
    expert_data=[]
    expert_data.append(np.array(qpos_list_expert[:, 0]))
    expert_data.append(np.array(qpos_list_expert[:, 1]))
    expert_data.append(np.array(qpos_list_expert[:, 2]))
    for i in range(3,qpos_list_expert.shape[1]):
        expert_data.append(np.array(rad_to_degree(qpos_list_expert[:, i])))

    ep_1 = []
    gc1 = [286, 392]
    gc2 = [392, 511]
    ep_2 = []
    gc3 = [524, 625]
    ep_8=[]
    gc4 = [587, 703]
    ep_9=[]
    gc5 = [699, 844]

    for episode in [1,2,8,9]:# going through body part segments
        agent_file = "/home/novikova/thesis/vid_walker_3step_473k" + str(episode) + ".npz"
        agent_data = load(agent_file, allow_pickle=True)
        ep = "ep_" + str(episode)
        eps = "_ep" + str(episode) + "_"
        result_path = '/home/novikova/thesis/SeptemberResults/SGAIL_LB/compare_distributions/ep_' +eps + '/'
        if not os.path.exists(result_path):
            os.makedirs(result_path)
        agent = agent_data['qpos']
        m = min(len(agent), len(expert_data))
        agent_episode_poses = agent[:, :]

        agent_data=[]
        agent_data.append(np.array(agent_episode_poses[:, 0]))
        agent_data.append(np.array(agent_episode_poses[:, 1]))
        agent_data.append(np.array(agent_episode_poses[:, 2]))

        for i in range(3,agent_episode_poses.shape[1]):
            agent_data.append(np.array(rad_to_degree(agent_episode_poses[:, i])))

        gc10 = [0, len(agent_episode_poses)]
        gcs = [gc1, gc2, gc3, gc4,gc5, gc10]
        for gc_count, gc in enumerate(gcs):
            result_path = '/home/novikova/thesis/SeptemberResults/SGAIL_LB/compare_distributions/ep_' +eps + '/' + 'gc_'+ str(gc_count+1) + '/'
            if not os.path.exists(result_path):
                os.makedirs(result_path)
            samples_qk = np.array(agent_data)
            samples_pk = np.array(expert_data)

            samples_qk, samples_pk = align_and_resample_agent_distributions_SGAIL(samples_qk, samples_pk, gc,
                                                                                  result_path)
            for qpos_ind in range(9):# going through body part segments
                print(qpos_ind)

                print_out_ROM(result_path," BODY PART " + str(body_part_dict[qpos_ind]),gc_count + 1,qpos_ind)

                plot_movement(samples_pk[qpos_ind,:], samples_qk[qpos_ind,:], qpos_ind, 2, result_path, body_part_dict)
                plot_pdf(samples_pk[qpos_ind,:], samples_qk[qpos_ind,:], qpos_ind, 2, result_path, body_part_dict)
                plot_cdf(samples_pk[qpos_ind,:], samples_qk[qpos_ind,:], qpos_ind, 2, result_path, body_part_dict)

                # plot BA plot for agent and expert
                fig = plt.figure()
                sm.graphics.mean_diff_plot(samples_qk[qpos_ind], samples_pk[qpos_ind])
                plt.savefig(
                    result_path + '_BA_' + body_part_dict[qpos_ind] + '.png')
                plt.close(fig)
                indexes_expert = [f for f in range(len(samples_pk))]
                indexes_agent = [f for f in range(len(samples_qk))]
                # computing the perfect sample size for the k-s test, plotting ks test results
                samples_pk_sample, samples_qk_sample = compute_ks_sample_size(samples_pk[qpos_ind,:], samples_qk[qpos_ind,:], indexes_expert, indexes_agent)
                res = stats.ks_2samp(samples_pk_sample, samples_qk_sample)
                plot_ks_results(samples_pk_sample, samples_qk_sample, res, qpos_ind, 2, result_path, body_part_dict)
                plt.close('all')


