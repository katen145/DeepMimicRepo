import pickle
from DeepMimic_plotter_util import *
import matplotlib.lines as mlines
import matplotlib.pyplot as plt


def plot_rom_error(plane_to_plot='Saggital'):
    fig = plt.figure()
    width = 0.2
    with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB/avg_rom_error.pickle', 'rb') as f:
        sag_rom_err, fro_rom_err, tr_rom_err = pickle.load(f)
        sag_right_hip_romERR_avg = np.mean(sag_rom_err['hip_rom_errors'][0])
        sag_left_hip_romERR_avg = np.mean(sag_rom_err['hip_rom_errors'][1])
        sag_pelvis_romERR_avg = np.mean(sag_rom_err['pelvis_rom_errors'][0])

        fro_right_hip_romERR_avg = np.mean(fro_rom_err['hip_rom_errors'][0])
        fro_left_hip_romERR_avg = np.mean(fro_rom_err['hip_rom_errors'][1])
        fro_pelvis_romERR_avg = np.mean(fro_rom_err['pelvis_rom_errors'][0])

        tr_right_hip_romERR_avg = np.mean(tr_rom_err['hip_rom_errors'][0])
        tr_left_hip_romERR_avg = np.mean(tr_rom_err['hip_rom_errors'][1])
        tr_pelvis_romERR_avg = np.mean(tr_rom_err['pelvis_rom_errors'][0])

    if plane_to_plot=='Saggital':
        plt.bar(0 * width, sag_pelvis_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')
        plt.bar(5 * width, sag_right_hip_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')
        plt.bar(10 * width, sag_left_hip_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')

    elif plane_to_plot=='Frontal':
        plt.bar(0 * width, fro_pelvis_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')
        plt.bar(5 * width, fro_right_hip_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')
        plt.bar(10 * width, fro_left_hip_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')

    elif plane_to_plot=='Transversal':
        plt.bar(0 * width, tr_pelvis_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')
        plt.bar(5 * width, tr_right_hip_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')
        plt.bar(10 * width, tr_left_hip_romERR_avg, width, alpha=0.5, color='#F78F1E', label='H_retargeted')

    with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit/avg_rom_error.pickle', 'rb') as f:
        sag_rom_err, fro_rom_err, tr_rom_err = pickle.load(f)
        sag_right_hip_romERR_avg = np.mean(sag_rom_err['hip_rom_errors'][0])
        sag_left_hip_romERR_avg = np.mean(sag_rom_err['hip_rom_errors'][1])
        sag_pelvis_romERR_avg = np.mean(sag_rom_err['pelvis_rom_errors'][0])

        fro_right_hip_romERR_avg = np.mean(fro_rom_err['hip_rom_errors'][0])
        fro_left_hip_romERR_avg = np.mean(fro_rom_err['hip_rom_errors'][1])
        fro_pelvis_romERR_avg = np.mean(fro_rom_err['pelvis_rom_errors'][0])

        tr_right_hip_romERR_avg = np.mean(tr_rom_err['hip_rom_errors'][0])
        tr_left_hip_romERR_avg = np.mean(tr_rom_err['hip_rom_errors'][1])
        tr_pelvis_romERR_avg = np.mean(tr_rom_err['pelvis_rom_errors'][0])


    if plane_to_plot == 'Saggital':
        plt.bar(1 * width, sag_pelvis_romERR_avg, width, color='#EE3224', alpha=0.5, label='H_perfect_fit')
        plt.bar(6 * width, sag_right_hip_romERR_avg, width, color='#EE3224', alpha=0.5, label='H_perfect_fit')
        plt.bar(11 * width, sag_left_hip_romERR_avg, width, color='#EE3224', alpha=0.5, label='H_perfect_fit')

    elif plane_to_plot == 'Frontal':
        plt.bar(1 * width, fro_pelvis_romERR_avg, width, alpha=0.5, color='#EE3224', label='H_perfect_fit')
        plt.bar(6 * width, fro_right_hip_romERR_avg, width, alpha=0.5, color='#EE3224', label='H_perfect_fit')
        plt.bar(11 * width, fro_left_hip_romERR_avg, width, alpha=0.5, color='#EE3224', label='H_perfect_fit')

    elif plane_to_plot == 'Transversal':
        plt.bar(1 * width, tr_pelvis_romERR_avg, width, alpha=0.5, color='#EE3224', label='H_perfect_fit')
        plt.bar(6 * width, tr_right_hip_romERR_avg, width, alpha=0.5, color='#EE3224', label='H_perfect_fit')
        plt.bar(11 * width, tr_left_hip_romERR_avg, width, alpha=0.5, color='#EE3224', label='H_perfect_fit')




    with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/avg_rom_error.pickle', 'rb') as f:
        sag_rom_err, fro_rom_err, tr_rom_err = pickle.load(f)
        sag_right_hip_romERR_avg = np.mean(sag_rom_err['hip_rom_errors'][0])
        sag_left_hip_romERR_avg = np.mean(sag_rom_err['hip_rom_errors'][1])
        sag_pelvis_romERR_avg = np.mean(sag_rom_err['pelvis_rom_errors'][0])

        fro_right_hip_romERR_avg = np.mean(fro_rom_err['hip_rom_errors'][0])
        fro_left_hip_romERR_avg = np.mean(fro_rom_err['hip_rom_errors'][1])
        fro_pelvis_romERR_avg = np.mean(fro_rom_err['pelvis_rom_errors'][0])

        tr_right_hip_romERR_avg = np.mean(tr_rom_err['hip_rom_errors'][0])
        tr_left_hip_romERR_avg = np.mean(tr_rom_err['hip_rom_errors'][1])
        tr_pelvis_romERR_avg = np.mean(tr_rom_err['pelvis_rom_errors'][0])

    if plane_to_plot == 'Saggital':
        plt.bar(2 * width, sag_pelvis_romERR_avg, width, color='#FFC222', alpha=0.5, label='THA_retargeted')
        plt.bar(7 * width, sag_right_hip_romERR_avg, width, color='#FFC222', alpha=0.5, label='THA_retargeted')
        plt.bar(12 * width, sag_left_hip_romERR_avg, width, color='#FFC222', alpha=0.5, label='THA_retargeted')

    elif plane_to_plot == 'Frontal':
        plt.bar(2 * width, fro_pelvis_romERR_avg, width, alpha=0.5, color='#FFC222', label='THA_retargeted')
        plt.bar(7 * width, fro_right_hip_romERR_avg, width, alpha=0.5, color='#FFC222', label='THA_retargeted')
        plt.bar(12 * width, fro_left_hip_romERR_avg, width, alpha=0.5, color='#FFC222', label='THA_retargeted')

    elif plane_to_plot == 'Transversal':
        plt.bar(2 * width, tr_pelvis_romERR_avg, width, alpha=0.5, color='#FFC222', label='THA_retargeted')
        plt.bar(7 * width, tr_right_hip_romERR_avg, width, alpha=0.5, color='#FFC222', label='THA_retargeted')
        plt.bar(12 * width, tr_left_hip_romERR_avg, width, alpha=0.5, color='#FFC222', label='THA_retargeted')

    with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA/avg_rom_error.pickle', 'rb') as f:
        sag_rom_err, fro_rom_err, tr_rom_err = pickle.load(f)
        sag_right_hip_romERR_avg = np.mean(sag_rom_err['hip_rom_errors'][0])
        sag_left_hip_romERR_avg = np.mean(sag_rom_err['hip_rom_errors'][1])
        sag_pelvis_romERR_avg = np.mean(sag_rom_err['pelvis_rom_errors'][0])

        fro_right_hip_romERR_avg = np.mean(fro_rom_err['hip_rom_errors'][0])
        fro_left_hip_romERR_avg = np.mean(fro_rom_err['hip_rom_errors'][1])
        fro_pelvis_romERR_avg = np.mean(fro_rom_err['pelvis_rom_errors'][0])

        tr_right_hip_romERR_avg = np.mean(tr_rom_err['hip_rom_errors'][0])
        tr_left_hip_romERR_avg = np.mean(tr_rom_err['hip_rom_errors'][1])
        tr_pelvis_romERR_avg = np.mean(tr_rom_err['pelvis_rom_errors'][0])

    if plane_to_plot == 'Saggital':
        plt.bar(3 * width, sag_pelvis_romERR_avg, width, color='darkred', alpha=0.5, label='THA_perfect_fit')
        plt.bar(8 * width, sag_right_hip_romERR_avg, width, color='darkred', alpha=0.5, label='THA_perfect_fit')
        plt.bar(13 * width, sag_left_hip_romERR_avg, width, color='darkred', alpha=0.5, label='THA_perfect_fit')

    elif plane_to_plot == 'Frontal':
        plt.bar(3 * width, fro_pelvis_romERR_avg, width, alpha=0.5, color='darkred', label='THA_perfect_fit')
        plt.bar(8 * width, fro_right_hip_romERR_avg, width, alpha=0.5, color='darkred', label='THA_perfect_fit')
        plt.bar(13 * width, fro_left_hip_romERR_avg, width, alpha=0.5, color='darkred', label='THA_perfect_fit')

    elif plane_to_plot == 'Transversal':
        plt.bar(3 * width, tr_pelvis_romERR_avg, width, alpha=0.5, color='darkred', label='THA_perfect_fit')
        plt.bar(8 * width, tr_right_hip_romERR_avg, width, alpha=0.5, color='darkred', label='THA_perfect_fit')
        plt.bar(13 * width, tr_left_hip_romERR_avg, width, alpha=0.5, color='darkred', label='THA_perfect_fit')

    custom_lines = [mlines.Line2D([0], [0], color='#F78F1E', lw=4),
                    mlines.Line2D([0], [0], color='#EE3224', lw=4),
                    mlines.Line2D([0], [0], color='#FFC222', lw=4),
                    mlines.Line2D([0], [0], color='darkred', lw=4)]
    plt.legend(custom_lines, ['re-targeted H', 'perfectly fitted H', 're-targeted THA', 'perfectly fitted THA'],
               loc='best')
    plt.ylabel("Error (%)")

    plt.tick_params(axis='both', which='major', labelsize=8)
    plt.tick_params(axis='both', which='minor', labelsize=8)

    plt.xticks([2 * width, 7 * width, 12 * width],
               ('Pelvis ROM', 'Right Hip ROM', 'Left Hip ROM'))
    plt.title(plane_to_plot+' ROM Error (%) for 4 experimental settings')

    plt.savefig('C:/Users/kt199/Documents/SeptemberResults/'+plane_to_plot+'_ROM_ERR.png')
    plt.close(fig)


def plot_symmetry_error(plane_to_plot='Saggital'):
    fig = plt.figure()
    width = 0.2
    with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB/symmetry_rom_error.pickle', 'rb') as f:
        sag_sym, fr_sym, tran_sym = pickle.load(f)

    if plane_to_plot == 'Saggital':
        plt.bar(0 * width, sag_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        plt.bar(1 * width, sag_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(2 * width, sag_sym[0], width, color='#F78F1E', alpha=0.5, label='FEET')
    elif plane_to_plot == 'Frontal':
        plt.bar(0 * width, fr_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        #plt.bar(1 * width, fr_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(1 * width, fr_sym[0], width, color='#F78F1E',alpha=0.5, label='FEET')
    elif plane_to_plot == 'Transversal':
        plt.bar(0 * width, tran_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        #plt.bar(1 * width, tran_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(1 * width, tran_sym[0], width, color='#F78F1E',alpha=0.5, label='FEET')


    with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit/symmetry_rom_error.pickle', 'rb') as f:
        sag_sym, fr_sym, tran_sym = pickle.load(f)

    if plane_to_plot == 'Saggital':
        plt.bar(4 * width, sag_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        plt.bar(5 * width, sag_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(6 * width, sag_sym[0], width, color='#F78F1E', alpha=0.5, label='FEET')
    elif plane_to_plot == 'Frontal':
        plt.bar(3 * width, fr_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        #plt.bar(5 * width, fr_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(4 * width, fr_sym[0], width, color='#F78F1E',alpha=0.5, label='FEET')
    elif plane_to_plot == 'Transversal':
        plt.bar(3 * width, tran_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        #plt.bar(5 * width, tran_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(4 * width, tran_sym[0], width, color='#F78F1E',alpha=0.5, label='FEET')

    with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/symmetry_rom_error.pickle', 'rb') as f:
        sag_sym, fr_sym, tran_sym = pickle.load(f)

    if plane_to_plot == 'Saggital':
        plt.bar(8  * width, sag_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        plt.bar(9  * width, sag_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(10 * width, sag_sym[0], width, color='#F78F1E', alpha=0.5, label='FEET')
    elif plane_to_plot == 'Frontal':
        plt.bar(6 * width, fr_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        #plt.bar(9 * width, fr_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(7 *width, fr_sym[0], width, color='#F78F1E', alpha=0.5, label='FEET')
    elif plane_to_plot == 'Transversal':
        plt.bar(6 * width, tran_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        #plt.bar(9 * width, tran_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(7* width, tran_sym[0], width, color='#F78F1E', alpha=0.5, label='FEET')


    with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA/symmetry_rom_error.pickle', 'rb') as f:
        sag_sym, fr_sym, tran_sym = pickle.load(f)

    if plane_to_plot == 'Saggital':
        plt.bar(12  * width, sag_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        plt.bar(13  * width, sag_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(14 * width, sag_sym[0], width, color='#F78F1E', alpha=0.5, label='FEET')
        plt.legend(['Hips', 'Knees', 'Feet'], loc='best')
        plt.xticks([1 * width, 5 * width, 9 * width, 13 * width],
               ('re-targeted H', 'perfectly fitted H', 're-targeted THA', 'perfectly fitted THA'))
    elif plane_to_plot == 'Frontal':
        plt.bar(9* width, fr_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        #plt.bar(13* width, fr_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(10 *width, fr_sym[0], width, color='#F78F1E', alpha=0.5, label='FEET')
        plt.legend(['Hips', 'Feet'], loc='best')
        plt.xticks([1 * width, 4* width, 7 * width, 10 * width],
                   ('re-targeted H', 'perfectly fitted H', 're-targeted THA', 'perfectly fitted THA'))

    elif plane_to_plot == 'Transversal':
        plt.bar(9* width, tran_sym[1], width, color='#EE3334', alpha=0.5, label='HIPS')
        #plt.bar(13* width, tran_sym[2], width, color='#FFC222', alpha=0.5, label='KNEES')
        plt.bar(10* width, tran_sym[0], width, color='#F78F1E', alpha=0.5, label='FEET')
        plt.legend(['Hips', 'Feet'], loc='best')
        plt.xticks([1 * width , 4 * width, 7 * width, 10 * width],
                   ('re-targeted H', 'perfectly fitted H', 're-targeted THA', 'perfectly fitted THA'))

    plt.ylabel("Error (%)")
    plt.tick_params(axis='both', which='major', labelsize=8)
    plt.tick_params(axis='both', which='minor', labelsize=8)


    plt.title(plane_to_plot+' ROM symmetry Error (%) for 4 experimental settings')
    plt.savefig('C:/Users/kt199/Documents/SeptemberResults/'+plane_to_plot+'_ROM_symmetry_ERROR.png')
    plt.close(fig)

plane_to_plot='Frontal'#  'Frontal'  'Saggital', 'Transversal'
plot_rom_error(plane_to_plot)
plot_symmetry_error(plane_to_plot)
