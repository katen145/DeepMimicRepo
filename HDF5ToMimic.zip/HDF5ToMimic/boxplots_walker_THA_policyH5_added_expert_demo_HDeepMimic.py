import pickle

from DeepMimic_plotter_util import *

gc1 = [6275, 7074]
gc2 = [630, 1384]
gc3 = [8100,8874]
gc4 =[5254, 6275]
gc5 = [7074, 8100]
gc6 =[8874, 9895]

gc7 =[6936, 7544]
gc8 = [7848, 8908]
gc9 = [0, 10000]
gc10 = [0, 10000]

gcs = [gc1, gc3, gc4,gc5,gc6,gc10]

body_part_dict = {
    0: 'pelvis',
    1: 'right_hip',
    2: 'right_knee',
    3: 'right_foot',
    4: 'left_hip',
    5: 'left_knee',
    6: 'left_foot'
}


def print_out_ROM(text, gc_count):
    # Program to show various ways to read and
    # write data in a file.
    file1 = open(result_path + '/compare_distributions/gc_' + str(gc_count)+ "/_rom_gait_cycle_" + str(gc_count) + ".txt", "a")
    file1.write("======================================================= \n")
    file1.write(text + " \n")
    #file1.write('agent \n')
    min_agent_degrees = min(samples_qk)
    max_agent_degrees = max(samples_qk)
    #file1.write('agent min ' + str(min_agent_degrees) + "\n")
    #file1.write('agent max ' + str(max_agent_degrees) + "\n")
    ROM = max_agent_degrees - min_agent_degrees
    file1.write('agent rom ' + str(ROM) + "\n")
    #file1.write('expert \n')
    min_expert_degrees = min(samples_pk)
    max_expert_degrees = max(samples_pk)
    #file1.write('expert min ' + str(min_expert_degrees) + "\n")
    #file1.write('expert max ' + str(max_expert_degrees) + "\n")
    ROM = max_expert_degrees - min_expert_degrees
    file1.write('expert rom ' + str(ROM) + "\n")
    file1.close()  # to change file access modes

def print_out_KS(text,ks ,gc_count):
    # Program to show various ways to read and
    # write data in a file.
    file1 = open(result_path + '/compare_distributions/gc_' + str(gc_count)+ "/_ks_test_gait_cycle_" + str(gc_count) + ".txt", "a")
    file1.write("======================================================= \n")
    file1.write(text + " \n")
    if ks < 0.05:
        file1.write("REJECTED")
    else:
        file1.write("ACCEPTED \n")
    file1.write(str(ks) + "\n")
    file1.close()  # to change file access modes

def generate_all_plots_GC():
    global counter, samples_pk, samples_qk
    for gc_count, gc in enumerate(gcs):
        for i, episode in enumerate(agent_data_episodes):
            episode_path = result_path + '/compare_distributions/gc_' + str(gc_count + 1) + '/'
            if not os.path.exists(episode_path):
                os.makedirs(episode_path)
            agent_expert = AgentExpert(episode, expert_data)
            euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}  # euler_dict = {0: 'z', 1: 'y', 2: 'x'}
            counter = 0  # for moving from 1D to 4D joints
            indexes_expert = [f for f in range(SAMPLE_SIZE)]
            indexes_agent = [f for f in range(SAMPLE_SIZE)]

            align_and_resample_agent_distributions(agent_expert, gc, episode_path, 68)

            expert_hip_ROM_symmetry_frontal, expert_hip_ROM_symmetry_saggital, expert_hip_ROM_symmetry_transversal = \
                calculate_ROM_hip_symmetry(agent_expert.body_parts_expert)

            agent_hip_ROM_symmetry_frontal, agent_hip_ROM_symmetry_saggital, agent_hip_ROM_symmetry_transversal = \
                calculate_ROM_hip_symmetry(agent_expert.body_parts_agent)

            with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/rom_'+str(gc_count)+'.pickle', 'wb') as f:
                pickle.dump([(expert_hip_ROM_symmetry_frontal, agent_hip_ROM_symmetry_frontal),
                             (expert_hip_ROM_symmetry_transversal,agent_hip_ROM_symmetry_transversal),
                             (expert_hip_ROM_symmetry_saggital,agent_hip_ROM_symmetry_saggital)], f)

            expert_pelvis_ROM_frontal, expert_pelvis_ROM_saggital, expert_pelvis_ROM_transversal = \
                calculate_pelvis_ROM(agent_expert.body_parts_expert)

            agent_pelvis_ROM_frontal, agent_pelvis_ROM_saggital, agent_pelvis_ROM_transversal = \
                calculate_pelvis_ROM(agent_expert.body_parts_agent)

            with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/rom_pelvis_' + str(gc_count) + '.pickle',
                      'wb') as f:
                pickle.dump([(expert_pelvis_ROM_frontal, agent_pelvis_ROM_frontal),
                             (expert_pelvis_ROM_transversal, agent_pelvis_ROM_transversal),
                             (expert_pelvis_ROM_saggital, agent_pelvis_ROM_saggital)], f)

            for body_part_euler_rot_agent, body_part_euler_rot_expert in agent_expert:
                for euler_idx in [0, 1, 2]:
                    euler_str = str(euler_dict[euler_idx])
                    if euler_idx != 0 and counter == 2 or euler_idx != 0 and counter == 5:
                        continue
                    elif counter == 2 or counter == 5:
                        euler_str = (euler_dict[2])
                        samples_pk = body_part_euler_rot_expert[:]
                        samples_qk = body_part_euler_rot_agent[:]
                    else:
                        samples_pk = body_part_euler_rot_expert[:, euler_idx]
                        samples_qk = body_part_euler_rot_agent[:, euler_idx]

                    print_out_ROM(
                        " BODY PART " + str(body_part_dict[counter]) + " euler angle : " + euler_str,
                        gc_count + 1)
                    plot_movement(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)
                    plot_pdf(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)
                    plot_cdf(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)

                    # plot BA plot for agent and expert
                    fig = plt.figure()
                    sm.graphics.mean_diff_plot(samples_qk, samples_pk)
                    plt.title(str(body_part_dict[counter]) + ' motion ' + euler_str)
                    plt.tight_layout(pad=2)
                    plt.savefig(
                        episode_path + '_BA_' + body_part_dict[counter] + 'euler ' + euler_str + '.png')
                    plt.close(fig)

                    # computing the perfect sample size for the k-s test, plotting ks test results
                    samples_pk, samples_qk = compute_ks_sample_size(samples_pk, samples_qk, indexes_expert,
                                                                    indexes_agent)
                    res = stats.ks_2samp(samples_pk, samples_qk)
                    plot_ks_results(samples_pk, samples_qk, res, counter, euler_idx, episode_path, body_part_dict)
                    print_out_KS(
                        " BODY PART " + str(body_part_dict[counter]) + " euler angle : " + euler_str, res.pvalue,
                        gc_count + 1)
                    plt.close('all')

                counter += 1

###### Data from THA trained on H retarg
id = '5'
expert_data_path = "C:/Users/kt199/Documents/Results_TEP6/rolled_out_traj_policyH5_GT_THA6/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5"
expert_data, agent_data_episodes = get_agent_and_expert_data(expert_data_path)
expert_data=expert_data[12:78]


###### Data from H5 retarg
other_expert_data_path = "C:/Users/kt199/Documents/Output_(trainedonH5_not_fitted_body)/H5/"
other_expert_data, agent_data_episodes2 = get_agent_and_expert_data(other_expert_data_path)


# Plot ROM for each "episode"
counter = 0
SAMPLE_SIZE = 50

#generate_all_plots_GC()


def plot_boxPlots_for_GCs(agent_data_episodes, expert_data, other_expert_data, gcs, result_path,expert_count):
    for i, episode in enumerate(agent_data_episodes):
        episode_path = result_path + '/compare_distributions/'

        if not os.path.exists(episode_path):
            os.makedirs(episode_path)
        euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}

        for c in range(7):
            samples_gc = []
            for gc_count, gc in enumerate(gcs):
                agent_expert = AgentExpert(episode, expert_data)
                align_and_resample_agent_distributions(agent_expert, gc, episode_path, expert_count)
                agent_expert_other = AgentExpert(episode, other_expert_data)
                align_and_resample_agent_distributions(agent_expert_other, gc, episode_path, 56)
                samples_gc.append(agent_expert.body_parts_agent[c])

            for euler_idx in [0, 1, 2]:
                euler_str = str(euler_dict[euler_idx])
                if c == 2 or c == 5:
                    euler_str = (euler_dict[2])
                    gc_roms=[max(samples_gc[0])-min(samples_gc[0]),
                             max(samples_gc[1])-min(samples_gc[1]),
                             max(samples_gc[2])-min(samples_gc[2]),
                             max(samples_gc[3])-min(samples_gc[3]),
                             max(samples_gc[4])-min(samples_gc[4]),
                             max(agent_expert.body_parts_expert[c]) - min(agent_expert.body_parts_expert[c]),
                             max(agent_expert_other.body_parts_expert[c])-min(agent_expert_other.body_parts_expert[c])]
                    boxes = [samples_gc[0], samples_gc[1], samples_gc[2], samples_gc[3],
                             samples_gc[4], agent_expert.body_parts_expert[c],  agent_expert_other.body_parts_expert[c]]


                else:
                    gc_roms = [max(samples_gc[0][:, euler_idx])-min(samples_gc[0][:, euler_idx]),
                               max(samples_gc[1][:, euler_idx])-min(samples_gc[1][:, euler_idx]),
                               max(samples_gc[2][:, euler_idx])-min(samples_gc[2][:, euler_idx]),
                               max(samples_gc[3][:, euler_idx]) - min(samples_gc[3][:, euler_idx]),
                               max(samples_gc[4][:, euler_idx]) - min(samples_gc[4][:, euler_idx]),
                               max(agent_expert.body_parts_expert[c][:, euler_idx])-min(agent_expert.body_parts_expert[c][:, euler_idx]),
                               max(agent_expert_other.body_parts_expert[c][:, euler_idx])-min(agent_expert_other.body_parts_expert[c][:, euler_idx])]

                    boxes = [samples_gc[0][:, euler_idx], samples_gc[1][:, euler_idx], samples_gc[2][:, euler_idx],
                             samples_gc[3][:, euler_idx],
                             samples_gc[4][:, euler_idx], agent_expert.body_parts_expert[c][:, euler_idx],agent_expert_other.body_parts_expert[c][:, euler_idx]]
                if euler_idx != 0 and c == 2 or euler_idx != 0 and c == 5:
                    continue

                colors = ['cadetblue', 'powderblue',
                          'skyblue', 'lightskyblue',
                          'steelblue', 'teal','teal']
                fig = plt.figure()
                bplot1 = plt.boxplot(
                    boxes,
                    vert=True,  # vertical box alignment
                    patch_artist=True,  # fill with color
                    labels=['GC 1', 'GC 2', 'GC 3', 'GC 4', 'GC 5', 'Expert THA', 'Expert H'])  # will be used to label x-ticks
                plt.tick_params(axis='both', which='major', labelsize=6)
                plt.tick_params(axis='both', which='minor', labelsize=6)
                rom_index=0
                for patch, color in zip(bplot1['boxes'], colors):
                    rom=gc_roms[rom_index]
                    y_coord=bplot1['medians'][rom_index].get_ydata()[0]
                    rom_index=rom_index+1
                    patch.set_facecolor(color)
                    plt.text(rom_index-0.22,y_coord, str(round(rom, 2)), fontsize=8,verticalalignment='bottom')
                tha_expert_median=bplot1['medians'][5].get_ydata()[0]
                tha_expert_rom = gc_roms[5]
                delta_expert_10_percent=tha_expert_rom / 10
                #plt.axhline(y=tha_expert_median+delta_expert_10_percent, linewidth=0.3, color='black')
                #plt.axhline(y=tha_expert_median-delta_expert_10_percent, linewidth=0.3, color='black')

                plt.ylabel('values (degrees)')
                plt.title('Box plots of ' + body_part_dict[c] + ' euler ' + euler_str)
                plt.savefig(
                    result_path + '/box_plot_' + body_part_dict[c] + 'euler ' + euler_str + '_2experts.png')
                plt.close(fig)
                plt.close('all')


plot_boxPlots_for_GCs(agent_data_episodes, expert_data,other_expert_data, gcs, result_path,68)
