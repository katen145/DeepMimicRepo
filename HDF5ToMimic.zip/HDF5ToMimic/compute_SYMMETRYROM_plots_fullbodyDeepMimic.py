from DeepMimic_plotter_util import *
import scipy

body_part_dict = {
    0: 'pelvis',
    1: 'right_hip',
    2: 'right_knee',
    3: 'right_foot',
    4: 'left_hip',
    5: 'left_knee',
    6: 'left_foot'
}

gc1 = [471, 1232]
gc2 = [1232, 1991]
gc7 = [3512, 4271]
gc8 = [1991, 2751]
gc9 = [2751, 3512]
gc10 = [0, 4700]

gcs = [gc1, gc2, gc7, gc8, gc9, gc10]

data_path = "C:/Users/kt199/Documents/Full_body_expert_results/Full_body_expert_results/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_FB"
sample_size = 50


# Plot ROM symmetry for each episode
expert_data, agent_data_episodes = get_agent_and_expert_data(data_path)
expert_data = expert_data[:32, :]

plot_symmetryRom_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=True,full_rom=True)
#plot_RomError_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=True,full_rom=False)
