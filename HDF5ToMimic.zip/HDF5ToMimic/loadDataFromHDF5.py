from utils.loaddatasets.hdf5.loadHDF5 import SettingReadHDF5, LoadHDF5

from utils.loaddatasets.visualize.visutilsQt import drawSkelQtWithLabels

p = SettingReadHDF5("data/")
p.movements = ['_6_min_walking_test']
p.labels = 'initial_contact_right'
p.inputdata = ['s_g', 'mrp_gs']  # animation position and orientation (will be flatted to 1D np.array, per timestep)
p.segmentsToInclude = list(range(7))  # all segments with index 0:6
p.trainDataSubjs = ['P1']
p.testDataSubjs = ['P1']

# Instance of Loader
loader = LoadHDF5(p)

loader.loadForLearning()

labelsTrain = loader.getTrainLabelsDict()
inputsTrain = loader.getTrainInputsDict()

print(p.movements[0])
print(labelsTrain)
print(inputsTrain)
print("Train")
print(labelsTrain.keys())
print(inputsTrain.keys())
print(labelsTrain.values())
print(inputsTrain.values())
print("Data shape of movement: " + 'P1' + p.movements[0])
print(inputsTrain[p.trainDataSubjs[0] + p.movements[0]].shape)



# ## Load data and visualize
# dictLabels, aData, iData, cData = loader.loadForVisualization('P1', '_Test_1_6_min_walking_test', load=['a', 'c'], nTimeLimit=1000)
#
# dict_labels = {}
# dict_labels['Initial Contact (L(red)/R(green))'] = dictLabels['ic']
# dict_labels['Turning Segmentation (L(red)/R(green))'] = dictLabels['seg']
# drawSkelQtWithLabels(aData, cData, "Lower Body", [0, 1, 1, 0.5], dict_labels)


