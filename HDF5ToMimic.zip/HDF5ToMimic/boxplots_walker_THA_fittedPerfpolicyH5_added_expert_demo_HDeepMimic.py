import pickle

from DeepMimic_plotter_util import *

gc1 = [984, 3065]
gc2 = [3065, 5065]
gc3 = [5065,7268]
gc4 = [7268,9348]
gc5 = [9348,11428]

gc6 = [9300, 10200]#approx
gc7 = [0, 10000]#approx
gc8 = [0, 10000]#approx
gc9 = [0, 10000]#approx

gc10 = [0, 17500]

#gcs = [gc1, gc2, gc3, gc4,gc5,gc6,gc7,gc8,gc9,gc10]
gcs = [gc1, gc2, gc3, gc4,gc5,gc10]

body_part_dict = {
    0: 'pelvis',
    1: 'right_hip',
    2: 'right_knee',
    3: 'right_foot',
    4: 'left_hip',
    5: 'left_knee',
    6: 'left_foot'
}


expert_data_path = "C:/Users/kt199/Documents/Results_TEP6/rolled_out_traj_policyH5_GT_THA6_perfect_fit/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA"
expert_data, agent_data_episodes = get_agent_and_expert_data(expert_data_path)
expert_data = expert_data[12:78]


other_expert_data_path = "C:/Users/kt199/Documents/Results_healthy_P5/output_H5_perfect_fit_smaller_feet_looped/"
other_expert_data, agent_data_episodes2 = get_agent_and_expert_data(other_expert_data_path)
other_expert_data=other_expert_data[:54,:]
# Plot ROM for each "episode"
counter = 0
SAMPLE_SIZE = 50




def plot_boxPlots_for_GCs(agent_data_episodes, expert_data, other_expert_data, gcs, result_path,expert_count):
    for i, episode in enumerate(agent_data_episodes):
        episode_path = result_path + '/compare_distributions/'

        if not os.path.exists(episode_path):
            os.makedirs(episode_path)
        euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}

        for c in range(7):
            samples_gc = []
            for gc_count, gc in enumerate(gcs):
                agent_expert = AgentExpert(episode, expert_data)
                align_and_resample_agent_distributions(agent_expert, gc, episode_path, expert_count)

                agent_expert_other = AgentExpert(episode, other_expert_data)
                align_and_resample_agent_distributions(agent_expert_other, gc, episode_path, 56)

                samples_gc.append(agent_expert.body_parts_agent[c])

            for euler_idx in [0, 1, 2]:
                euler_str = str(euler_dict[euler_idx])
                if c == 2 or c == 5:
                    euler_str = (euler_dict[2])
                    gc_roms = [max(samples_gc[0]) - min(samples_gc[0]),
                               max(samples_gc[1]) - min(samples_gc[1]),
                               max(samples_gc[2]) - min(samples_gc[2]),
                               max(samples_gc[3]) - min(samples_gc[3]),
                               max(samples_gc[4]) - min(samples_gc[4]),
                               max(agent_expert.body_parts_expert[c]) - min(agent_expert.body_parts_expert[c]),
                               max(agent_expert_other.body_parts_expert[c]) - min(
                                   agent_expert_other.body_parts_expert[c])]

                    boxes = [samples_gc[0], samples_gc[1], samples_gc[2], samples_gc[3],
                             samples_gc[4], agent_expert.body_parts_expert[c],  agent_expert_other.body_parts_expert[c]]


                else:
                    gc_roms = [max(samples_gc[0][:, euler_idx]) - min(samples_gc[0][:, euler_idx]),
                               max(samples_gc[1][:, euler_idx]) - min(samples_gc[1][:, euler_idx]),
                               max(samples_gc[2][:, euler_idx]) - min(samples_gc[2][:, euler_idx]),
                               max(samples_gc[3][:, euler_idx]) - min(samples_gc[3][:, euler_idx]),
                               max(samples_gc[4][:, euler_idx]) - min(samples_gc[4][:, euler_idx]),
                               max(agent_expert.body_parts_expert[c][:, euler_idx]) - min(
                                   agent_expert.body_parts_expert[c][:, euler_idx]),
                               max(agent_expert_other.body_parts_expert[c][:, euler_idx]) - min(
                                   agent_expert_other.body_parts_expert[c][:, euler_idx])]

                    boxes = [samples_gc[0][:, euler_idx], samples_gc[1][:, euler_idx], samples_gc[2][:, euler_idx],
                             samples_gc[3][:, euler_idx],
                             samples_gc[4][:, euler_idx], agent_expert.body_parts_expert[c][:, euler_idx],agent_expert_other.body_parts_expert[c][:, euler_idx]]
                if euler_idx != 0 and c == 2 or euler_idx != 0 and c == 5:
                    continue

                colors = ['cadetblue', 'powderblue',
                          'skyblue', 'lightskyblue',
                          'steelblue', 'teal', 'teal']
                fig = plt.figure()
                bplot1 = plt.boxplot(
                    boxes,
                    vert=True,  # vertical box alignment
                    patch_artist=True,  # fill with color
                    labels=['GC 1', 'GC 2', 'GC 3', 'GC 4', 'GC 5', 'Expert THA',
                            'Expert H'])  # will be used to label x-ticks
                plt.tick_params(axis='both', which='major', labelsize=6)
                plt.tick_params(axis='both', which='minor', labelsize=6)
                rom_index = 0
                for patch, color in zip(bplot1['boxes'], colors):
                    rom = gc_roms[rom_index]
                    y_coord = bplot1['medians'][rom_index].get_ydata()[0]
                    rom_index = rom_index + 1
                    patch.set_facecolor(color)
                    plt.text(rom_index-0.22,y_coord, str(round(rom, 2)), fontsize=8,verticalalignment='bottom')

                plt.ylabel('values (degrees)')
                plt.title('Box plots of ' + body_part_dict[c] + ' euler ' + euler_str)
                plt.savefig(
                    result_path + '/box_plot_' + body_part_dict[c] + 'euler ' + euler_str + '_2experts.png')
                plt.close(fig)
                plt.close('all')


plot_boxPlots_for_GCs(agent_data_episodes, expert_data,other_expert_data, gcs, result_path,68)
