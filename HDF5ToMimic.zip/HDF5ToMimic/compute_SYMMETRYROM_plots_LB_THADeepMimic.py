import pickle

from DeepMimic_plotter_util import *


gc3 = [2385, 3041]  # +
gc4 = [3976, 4653]  # +
gc5 = [5084, 5827]  # +
gc6 = [5827, 6936]  # +
gc7 = [6936, 7544]  # +

gcs = [gc3, gc4, gc5, gc6, gc7]

id = '5'
expert_data_path = "C:/Users/kt199/Documents/Results_TEP6/first_try_long_segments_looped+nonlooped/output_non_looped_long_TEP6/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA"
expert_data, agent_data_episodes = get_agent_and_expert_data(expert_data_path)
expert_data = expert_data[12:78]

# Plot ROM for each "episode"
counter = 0
SAMPLE_SIZE = 50

plot_symmetryRom_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=False,full_rom=True)
#plot_RomError_BarPlot_for_GCs(agent_data_episodes, expert_data, gcs, result_path,FB=False,full_rom=False)
