import pickle

from DeepMimic_plotter_util import *

gc1 = [1013, 1806]
gc2 = [1806, 2385]
gc3 = [2385, 3041]  # +
gc4 = [3976, 4653]  # +
gc5 = [5084, 5827]  # +
gc6 = [5827, 6936]  # +
gc7 = [6936, 7544]  # +
gc8 = [7848, 8908]
gc9 = [0, 10000]
gc10 = [0, 10000]

# gcs = [gc1, gc2, gc3, gc4,gc5,gc6,gc7,gc8,gc9,gc10]
gcs = [gc3, gc4, gc5, gc6, gc7, gc10]

body_part_dict = {
    0: 'pelvis',
    1: 'right_hip',
    2: 'right_knee',
    3: 'right_foot',
    4: 'left_hip',
    5: 'left_knee',
    6: 'left_foot'
}

id = '5'
expert_data_path = "C:/Users/kt199/Documents/Results_TEP6/first_try_long_segments_looped+nonlooped/output_non_looped_long_TEP6/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA"
expert_data, agent_data_episodes = get_agent_and_expert_data(expert_data_path)
expert_data = expert_data[12:78]
# Plot ROM for each "episode"
counter = 0
SAMPLE_SIZE = 50


def print_out_ROM(text, gc_count):
    # Program to show various ways to read and
    # write data in a file.
    file1 = open(
        result_path + '/compare_distributions/gc_' + str(gc_count) + "/_rom_gait_cycle_" + str(gc_count) + ".txt", "a")
    file1.write("======================================================= \n")
    file1.write(text + " \n")
    # file1.write('agent \n')
    min_agent_degrees = min(samples_qk)
    max_agent_degrees = max(samples_qk)
    # file1.write('agent min ' + str(min_agent_degrees) + "\n")
    # file1.write('agent max ' + str(max_agent_degrees) + "\n")
    ROM = max_agent_degrees - min_agent_degrees
    file1.write('agent rom ' + str(ROM) + "\n")
    # file1.write('expert \n')
    min_expert_degrees = min(samples_pk)
    max_expert_degrees = max(samples_pk)
    # file1.write('expert min ' + str(min_expert_degrees) + "\n")
    # file1.write('expert max ' + str(max_expert_degrees) + "\n")
    ROM = max_expert_degrees - min_expert_degrees
    file1.write('expert rom ' + str(ROM) + "\n")
    file1.close()  # to change file access modes


def print_out_KS(text, ks, gc_count):
    # Program to show various ways to read and
    # write data in a file.
    file1 = open(
        result_path + '/compare_distributions/gc_' + str(gc_count) + "/_ks_test_gait_cycle_" + str(gc_count) + ".txt",
        "a")
    file1.write("======================================================= \n")
    file1.write(text + " \n")
    if ks < 0.05:
        file1.write("REJECTED")
    else:
        file1.write("ACCEPTED \n")
    file1.write('{0:.4f}'.format(ks) + "\n")
    file1.close()  # to change file access modes


def generate_all_plots_GC():
    global counter, samples_pk, samples_qk
    for gc_count, gc in enumerate(gcs):
        for i, episode in enumerate(agent_data_episodes):
            episode_path = result_path + '/compare_distributions/gc_' + str(gc_count + 1) + '/'
            if not os.path.exists(episode_path):
                os.makedirs(episode_path)
            agent_expert = AgentExpert(episode, expert_data)
            euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}  # euler_dict = {0: 'z', 1: 'y', 2: 'x'}
            counter = 0  # for moving from 1D to 4D joints
            indexes_expert = [f for f in range(SAMPLE_SIZE)]
            indexes_agent = [f for f in range(SAMPLE_SIZE)]

            align_and_resample_agent_distributions(agent_expert, gc, episode_path, 68)

            expert_hip_ROM_symmetry_frontal, expert_hip_ROM_symmetry_saggital, expert_hip_ROM_symmetry_transversal = \
                calculate_ROM_hip_symmetry(agent_expert.body_parts_expert)

            agent_hip_ROM_symmetry_frontal, agent_hip_ROM_symmetry_saggital, agent_hip_ROM_symmetry_transversal = \
                calculate_ROM_hip_symmetry(agent_expert.body_parts_agent)

            with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA/rom_'+str(gc_count)+'.pickle', 'wb') as f:
                pickle.dump([(expert_hip_ROM_symmetry_frontal, agent_hip_ROM_symmetry_frontal),
                             (expert_hip_ROM_symmetry_transversal,agent_hip_ROM_symmetry_transversal),
                             (expert_hip_ROM_symmetry_saggital,agent_hip_ROM_symmetry_saggital)], f)


            expert_pelvis_ROM_frontal,  expert_pelvis_ROM_saggital,  expert_pelvis_ROM_transversal = \
                calculate_pelvis_ROM(agent_expert.body_parts_expert)

            agent_pelvis_ROM_frontal, agent_pelvis_ROM_saggital, agent_pelvis_ROM_transversal = \
                calculate_pelvis_ROM(agent_expert.body_parts_agent)

            with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA/rom_pelvis_' + str(gc_count) + '.pickle', 'wb') as f:
                pickle.dump([(expert_pelvis_ROM_frontal, agent_pelvis_ROM_frontal),
                             (expert_pelvis_ROM_transversal, agent_pelvis_ROM_transversal),
                             (expert_pelvis_ROM_saggital, agent_pelvis_ROM_saggital)], f)

            for body_part_euler_rot_agent, body_part_euler_rot_expert in agent_expert:
                for euler_idx in [0, 1, 2]:
                    euler_str = str(euler_dict[euler_idx])
                    if euler_idx != 0 and counter == 2 or euler_idx != 0 and counter == 5:
                        continue
                    elif counter == 2 or counter == 5:
                        euler_str = (euler_dict[2])
                        samples_pk = body_part_euler_rot_expert[:]
                        samples_qk = body_part_euler_rot_agent[:]
                    else:
                        samples_pk = body_part_euler_rot_expert[:, euler_idx]
                        samples_qk = body_part_euler_rot_agent[:, euler_idx]


                    print_out_ROM(
                        " BODY PART " + str(body_part_dict[counter]) + " euler angle : " + euler_str,
                        gc_count + 1)
                    plot_movement(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)
                    plot_pdf(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)
                    plot_cdf(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)

                    # plot BA plot for agent and expert
                    fig = plt.figure()
                    sm.graphics.mean_diff_plot(samples_qk, samples_pk)
                    plt.title(str(body_part_dict[counter]) + ' motion ' + euler_str)
                    plt.tight_layout(pad=2)
                    plt.savefig(
                        episode_path + '_BA_' + body_part_dict[counter] + 'euler ' + euler_str + '.png')
                    plt.close(fig)

                    # computing the perfect sample size for the k-s test, plotting ks test results
                    samples_pk, samples_qk = compute_ks_sample_size(samples_pk, samples_qk, indexes_expert,
                                                                    indexes_agent)
                    res = stats.ks_2samp(samples_pk, samples_qk)
                    plot_ks_results(samples_pk, samples_qk, res, counter, euler_idx, episode_path, body_part_dict)
                    print_out_KS(
                        " BODY PART " + str(body_part_dict[counter]) + " euler angle : " + euler_str, res.pvalue,
                        gc_count + 1)
                    plt.close('all')

                counter += 1



generate_all_plots_GC()
plot_boxPlots_for_GCs(agent_data_episodes, expert_data, gcs, result_path,68)
