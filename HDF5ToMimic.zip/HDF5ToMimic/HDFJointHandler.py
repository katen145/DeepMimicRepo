import json
import numpy as np
import math
from pyquaternion import Quaternion
from typing import List
from tqdm import tqdm


class HDFJointHandler:
    """ Handles conversion of BVH files to DeepMimic format.
    """

    def __init__(self, mocap, rigPath="./Rigs/walkerRig.json", posLocked=False):
        self.mocap = mocap
        self.posLocked = posLocked

        # get json of humanoidRig
        with open(rigPath) as json_data:
            self.humanoidRig = json.load(json_data)

        # Sets up list of bones used by DeepMimic humanoid
        # Order is important

        self.deepMimicHumanoidJoints = ["seconds", "hip", "hip", "right hip", "right knee",
                                        "right ankle",
                                        "left hip", "left knee", "left ankle"]

        self.jointDimensions = [1, 3, 4, 4, 1, 4, 4, 1, 4]

        # Looking directly at the front of the model, X-axis points at you, Y-axis points straight up, Z-axis points left.
        # Image of correct deepMimic humanoid bind pose: https://user-images.githubusercontent.com/43953552/61379957-cb485c80-a8a8-11e9-8b78-24f4bf581900.PNG

        self.rotVecDict = {
            "seconds": [],
            "hip": [0, 0, 0],
            "hip": [0, 0, 0],
            "right hip": [0, 0, 0],
            "right knee": [0, 0, 0],
            "right ankle": [0, 0, 0],
            "left hip": [0, 0, 0],
            "left knee": [0, 0, 0],
            "left ankle": [0, 0, 0]
        }
        self.jointChildDict = {
            # Child joints are necessary to be able to compute the offset quaternions correctly.
            "Hips": "Hips",
            "RightUpLeg": "RightLeg",
            "RightLeg": "RightFoot",
            "RightFoot": "RightToeBase",
            "LeftUpLeg": "LeftLeg",
            "LeftLeg": "LeftFoot",
            "LeftFoot": "LeftToeBase",
        }

        self.positionChannelNames = ["Xposition", "Yposition", "Zposition"]
        self.rotationChannelNames = ["Xrotation", "Yrotation", "Zrotation"]

    def generateKeyFrame(self, frameNumber: int):
        result = []
        # Append Time
        result.append(0.0333320000)

        # Append hip root pos
        if self.posLocked:
            result.extend(
                #[self.mocap['data'][0][0, frameNumber], 0.215+ self.mocap['data'][0][1, frameNumber],
                [self.mocap['data'][0][0, frameNumber], 0.5+ self.mocap['data'][0][1, frameNumber],
                 self.mocap['data'][0][2, frameNumber]]
                # self.getJointTranslation(frameNumber, self.jointData[0])
            )
            # result.extend([1, 1, 1])
        else:
            result.extend(
                self.mocap['data'][0][:, frameNumber]
            )

        # Append hip rotation
        result.extend(
            self.mocap['data'][1][:, frameNumber]
        )

        # Append other rotations
        for i, joint in enumerate(self.mocap['data']):
            if i > 1: result.extend(joint[:, frameNumber])

        return result

    def generateKeyFrames(self):
        keyFrames = []
        for i in tqdm(range(147, 290)):  # perfect 315 samples longer H5
            keyFrames.append(self.generateKeyFrame(i))

        return keyFrames

    def eulerToQuat(self, angles: List[float], channels: List[str]):
        # Convert angles to radians
        Xangle = math.radians(angles[0])
        Yangle = math.radians(angles[1])
        Zangle = math.radians(angles[2])

        # Create the rotation matrix for every euler angle
        # See: https://en.wikipedia.org/wiki/Rotation_matrix#In_three_dimensions
        Xrot = np.array(
            [
                [1, 0, 0],
                [0, math.cos(Xangle), -math.sin(Xangle)],
                [0, math.sin(Xangle), math.cos(Xangle)]
            ]
        )
        Yrot = np.array(
            [
                [math.cos(Yangle), 0, math.sin(Yangle)],
                [0, 1, 0],
                [-math.sin(Yangle), 0, math.cos(Yangle)]
            ]
        )
        Zrot = np.array(
            [
                [math.cos(Zangle), -math.sin(Zangle), 0],
                [math.sin(Zangle), math.cos(Zangle), 0],
                [0, 0, 1]
            ]
        )

        # Connect the rotation channel names to corresponding matrices
        rotationDict = {
            self.rotationChannelNames[0]: Xrot,
            self.rotationChannelNames[1]: Yrot,
            self.rotationChannelNames[2]: Zrot
        }

        # Compute the final rotation matrix in the order as the BVH file describes.
        rotationMatrix = rotationDict[channels[2]].dot(
            rotationDict[channels[1]].dot(
                rotationDict[channels[0]]
            )
        )

        # Return the corresponding quaternion
        return Quaternion(matrix=rotationMatrix)
