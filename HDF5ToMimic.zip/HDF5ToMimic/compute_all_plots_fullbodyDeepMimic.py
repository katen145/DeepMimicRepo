from DeepMimic_plotter_util import *
import scipy

body_part_dict = {
    0: 'pelvis',
    1: 'right_hip',
    2: 'right_knee',
    3: 'right_foot',
    4: 'left_hip',
    5: 'left_knee',
    6: 'left_foot'
}

gc1 = [471, 1232]
gc2 = [1232, 1991]
gc3 = [400, 1200]  # appr
gc4 = [1200, 1900]  # appr
gc5 = [1900, 2700]  # appr
gc6 = [2700, 3500]  # appr
gc7 = [3512, 4271]
gc8 = [1991, 2751]
gc9 = [2751, 3512]
gc10 = [0, 4700]
#gcs = [gc1, gc2, gc3, gc4, gc5, gc6, gc7, gc8, gc9, gc10]

gcs = [gc1, gc2, gc7, gc8, gc9, gc10]

data_path = "C:/Users/kt199/Documents/Full_body_expert_results/Full_body_expert_results/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/DM_FB"
sample_size = 50


def print_out_ROM(text, gc_count):
    file1 = open(
        result_path + "/compare_distributions/gc_" + str(gc_count) + "/_rom_gait_cycle_" + str(gc_count) + ".txt", "a")
    file1.write("======================================================= \n")
    file1.write(text + " \n")
    # file1.write('agent \n')
    min_agent_degrees = min(samples_qk)
    max_agent_degrees = max(samples_qk)
    # file1.write('min '+ str(min_agent_degrees) +"\n")
    # file1.write('max '+ str(max_agent_degrees) +"\n")
    ROM = max_agent_degrees - min_agent_degrees
    file1.write('agent rom ' + str(ROM) + "\n")
    # file1.write('expert \n')
    min_expert_degrees = min(samples_pk)
    max_expert_degrees = max(samples_pk)
    # file1.write('min '+ str(min_expert_degrees) +"\n")
    # file1.write('max '+ str( max_expert_degrees) +"\n")
    ROM = max_expert_degrees - min_expert_degrees
    file1.write('expert rom ' + str(ROM) + "\n")
    file1.close()  # to change file access modes


def print_out_KS(text, ks, gc_count):
    # Program to show various ways to read and
    # write data in a file.
    file1 = open(
        result_path + '/compare_distributions/gc_' + str(gc_count) + "/_ks_test_gait_cycle_" + str(gc_count) + ".txt",
        "a")
    file1.write("======================================================= \n")
    file1.write(text + " \n")
    file1.write(str(ks) + "\n")
    file1.close()  # to change file access modes


def plot_everzyhing_for_all_GCs():
    global counter, samples_pk, samples_qk
    for gc_count, gc in enumerate(gcs):
        for i, episode in enumerate(agent_data_episodes):
            episode_path = result_path + '/compare_distributions/gc_' + str(gc_count + 1) + '/'

            if not os.path.exists(episode_path):
                os.makedirs(episode_path)
            agent_expert = AgentExpertFB(episode, expert_data)
            euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}

            counter = 0
            align_and_resample_agent_distributions(agent_expert, gc, episode_path, 32)

            for body_part_euler_rot_agent, body_part_euler_rot_expert in agent_expert:
                for euler_idx in [0, 1, 2]:
                    euler_str = str(euler_dict[euler_idx])
                    if euler_idx != 0 and counter == 2 or euler_idx != 0 and counter == 5:
                        continue
                    elif counter == 2 or counter == 5:
                        euler_str = str(euler_dict[2])
                        samples_pk = body_part_euler_rot_expert[:]
                        samples_qk = body_part_euler_rot_agent[:]
                    else:
                        samples_pk = body_part_euler_rot_expert[:, euler_idx]
                        samples_qk = body_part_euler_rot_agent[:, euler_idx]

                    indexes_expert = [f for f in range(len(samples_pk))]
                    indexes_agent = [f for f in range(len(samples_pk))]
                    # samples_qk=scipy.signal.resample(samples_qk,len(samples_pk))

                    print_out_ROM(
                        " BODY PART " + str(body_part_dict[counter]) + " euler angle : " + euler_str,
                        gc_count + 1)
                    plot_movement(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)
                    plot_pdf(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)
                    plot_cdf(samples_pk, samples_qk, counter, euler_idx, episode_path, body_part_dict)

                    # plot BA plot for agent and expert
                    fig = plt.figure()
                    sm.graphics.mean_diff_plot(samples_qk, samples_pk)
                    plt.title(str(body_part_dict[counter]) + ' motion ' + euler_str)
                    plt.tight_layout(pad=2)

                    plt.savefig(
                        episode_path + '_BA_' + body_part_dict[counter] + 'euler ' + euler_str + '.png')
                    plt.close(fig)

                    # computing the perfect sample size for the k-s test, plotting ks test results
                    samples_pk, samples_qk = compute_ks_sample_size(samples_pk, samples_qk, indexes_expert,
                                                                    indexes_agent)
                    res = stats.ks_2samp(samples_pk, samples_qk)
                    plot_ks_results(samples_pk, samples_qk, res, counter, euler_idx, episode_path, body_part_dict)
                    print_out_KS(
                        " BODY PART " + str(body_part_dict[counter]) + " euler angle : " + euler_str,
                        res.pvalue, gc_count + 1)
                    plt.close('all')

                counter += 1



# Plot ROM for each episode
expert_data, agent_data_episodes = get_agent_and_expert_data(data_path)
expert_data = expert_data[:32, :]
plot_everzyhing_for_all_GCs()
#plot_boxPlots_FB_for_GCs(agent_data_episodes, expert_data, gcs, result_path)
