import pickle

from DeepMimic_plotter_util import *

body_part_dict = {
    0: 'pelvis',
    1: 'right_hip',
    2: 'right_knee',
    3: 'right_foot',
    4: 'left_hip',
    5: 'left_knee',
    6: 'left_foot'
}


#AGENT 1. Healthy retargeted
gc1 = [893, 1852]
gc3 = [3560,4471]
gc4 = [4471,5431]
gc5 = [5431,6593]
gc8 = [11500, 12400]#approx
gcs1 = [gc1, gc3, gc4,gc5,gc8]
id = '5'
expert_data_path = "C:/Users/kt199/Documents/Output_(trainedonH5_not_fitted_body)/H" + id + "/"
expert_data, agent_data_episodes = get_agent_and_expert_data(expert_data_path)

#AGENT 2. H fitted H

gc1 = [583, 1582]
gc3 = [2664,3723]
gc4 = [3723,4763]
gc5 = [4763,5881]
gc6 = [5881, 6922]#approx
gcs2 = [gc1, gc3, gc4,gc5,gc6]

other_expert_data_path = "C:/Users/kt199/Documents/Results_healthy_P5/output_H5_perfect_fit_smaller_feet_looped/"
result_path = "C:/Users/kt199/Documents/SeptemberResults/2_AGENTS_Hretarg_and_Hfitted/"
other_expert_data, agent_data_episodes2 = get_agent_and_expert_data(other_expert_data_path)
other_expert_data = other_expert_data[:54, :]

counter = 0
SAMPLE_SIZE = 50


def plot_boxPlots_for_GCs(agent_data_episodes,gcs1,agent_data_episodes2,gcs2, expert_data, other_expert_data,result_path,expert_count1,expert_count2):
    for i, episode in enumerate(agent_data_episodes):
        episode_path = result_path + '/compare_distributions/'
        if not os.path.exists(episode_path):
            os.makedirs(episode_path)
        euler_dict = {0: 'frontal', 1: 'transversal', 2: 'saggital'}
        for c in range(7):
            samples_gc = []
            for gc_count in range(len(gcs1)):
                agent_expert = AgentExpert(episode, expert_data)
                align_and_resample_agent_distributions(agent_expert, gcs1[gc_count], episode_path, expert_count1)

                agent_expert_other = AgentExpert(agent_data_episodes2[0], other_expert_data)
                align_and_resample_agent_distributions(agent_expert_other, gcs2[gc_count], episode_path,  expert_count2)

                samples_gc.append((agent_expert.body_parts_agent[c],agent_expert_other.body_parts_agent[c]))

            for euler_idx in [0, 1, 2]:
                euler_str = str(euler_dict[euler_idx])
                if c == 2 or c == 5:
                    euler_str = (euler_dict[2])
                    gc_roms=[max(samples_gc[0][0])-min(samples_gc[0][0]),
                             max(samples_gc[0][1])-min(samples_gc[0][1]),
                             max(samples_gc[1][0])-min(samples_gc[1][0]),
                             max(samples_gc[1][1])-min(samples_gc[1][1]),
                             max(samples_gc[2][0])-min(samples_gc[2][0]),
                             max(samples_gc[2][1])-min(samples_gc[2][1]),
                             max(samples_gc[3][0])-min(samples_gc[3][0]),
                             max(samples_gc[3][1])-min(samples_gc[3][1]),
                             max(samples_gc[4][0])-min(samples_gc[4][0]),
                             max(samples_gc[4][1])-min(samples_gc[4][1]),
                             max(agent_expert.body_parts_expert[c]) - min(agent_expert.body_parts_expert[c])]
                    boxes = [samples_gc[0][0], samples_gc[0][1], samples_gc[1][0], samples_gc[1][1], samples_gc[2][0], samples_gc[2][1], samples_gc[3][0], samples_gc[3][1],
                             samples_gc[4][0], samples_gc[4][1], agent_expert.body_parts_expert[c]]


                else:
                    gc_roms = [max(samples_gc[0][0][:, euler_idx])-min(samples_gc[0][0][:, euler_idx]),
                               max(samples_gc[0][1][:, euler_idx]) - min(samples_gc[0][1][:, euler_idx]),
                               max(samples_gc[1][0][:, euler_idx])-min(samples_gc[1][0][:, euler_idx]),
                               max(samples_gc[1][1][:, euler_idx])-min(samples_gc[1][1][:, euler_idx]),
                               max(samples_gc[2][0][:, euler_idx])-min(samples_gc[2][0][:, euler_idx]),
                               max(samples_gc[2][1][:, euler_idx])-min(samples_gc[2][1][:, euler_idx]),
                               max(samples_gc[3][0][:, euler_idx])-min(samples_gc[3][0][:, euler_idx]),
                               max(samples_gc[3][1][:, euler_idx])-min(samples_gc[3][1][:, euler_idx]),
                               max(samples_gc[4][0][:, euler_idx])-min(samples_gc[4][0][:, euler_idx]),
                               max(samples_gc[4][1][:, euler_idx])-min(samples_gc[4][1][:, euler_idx]),
                               max(agent_expert.body_parts_expert[c][:, euler_idx])-min(agent_expert.body_parts_expert[c][:, euler_idx])]

                    boxes = [samples_gc[0][0][:, euler_idx],samples_gc[0][1][:, euler_idx], samples_gc[1][0][:, euler_idx], samples_gc[1][1][:, euler_idx],
                             samples_gc[2][0][:, euler_idx],samples_gc[2][1][:, euler_idx], samples_gc[3][0][:, euler_idx], samples_gc[3][1][:, euler_idx],
                             samples_gc[4][0][:, euler_idx],samples_gc[4][1][:, euler_idx], agent_expert.body_parts_expert[c][:, euler_idx]]
                if euler_idx != 0 and c == 2 or euler_idx != 0 and c == 5:
                    continue

                colors = ['cadetblue', 'darkorchid','powderblue','darkviolet',
                          'skyblue', 'mediumorchid','lightskyblue','plum',
                          'steelblue','violet', 'teal']
                fig = plt.figure()
                bplot1 = plt.boxplot(
                    boxes,
                    vert=True,  # vertical box alignment
                    patch_artist=True,  # fill with color
                    labels=['R GC 1','F GC 1', 'R GC 2','F GC 2', 'R GC 3','F GC 3', 'R GC 4','F GC 4', 'R GC 5','F GC 5', 'Expert H'])  # will be used to label x-ticks
                rom_index=0
                plt.tick_params(axis='both', which='major', labelsize=6)
                plt.tick_params(axis='both', which='minor', labelsize=4)
                for patch, color in zip(bplot1['boxes'], colors):
                    rom=gc_roms[rom_index]
                    y_coord=bplot1['medians'][rom_index].get_ydata()[0]
                    rom_index=rom_index+1
                    patch.set_facecolor(color)
                    plt.text(rom_index-0.21,y_coord, str(round(rom, 1)), fontsize=6,verticalalignment='bottom' )

                plt.ylabel('values (degrees)')
                plt.title('Box plots of ' + body_part_dict[c] + ' euler ' + euler_str)
                plt.savefig(
                    result_path + '/box_plot_' + body_part_dict[c] + 'euler ' + euler_str + '_2agents.png')
                plt.close(fig)
                plt.close('all')


plot_boxPlots_for_GCs(agent_data_episodes,gcs1, agent_data_episodes2,gcs2, expert_data,other_expert_data, result_path,56,68)
