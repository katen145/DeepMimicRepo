import pickle

from DeepMimic_plotter_util import *
import matplotlib.lines as mlines
import matplotlib.pyplot as plt


def plot_transversal_ROM_pelvis():
    fig = plt.figure()
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA/rom_pelvis_' + str(gc_count) + '.pickle', 'rb') as f:
            _, ea_hip_ROM_symmetry_transversal, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_transversal[1])
            plt.plot(ea_hip_ROM_symmetry_transversal[1], ea_hip_ROM_symmetry_transversal[0], 'b*')
    tr_avg1 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_transversal[0] - 1, ea_hip_ROM_symmetry_transversal[0] + 0.05, '{0:.2f}'.format(tr_avg),
    #         color='blue')
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/rom_pelvis_' + str(gc_count) + '.pickle',
                  'rb') as f:
            _, ea_hip_ROM_symmetry_transversal, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_transversal[1])
            plt.plot(ea_hip_ROM_symmetry_transversal[1], ea_hip_ROM_symmetry_transversal[0], 'rs')
    tr_avg2 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_transversal[0] - 1, ea_hip_ROM_symmetry_transversal[0] + 0.02, '{0:.2f}'.format(tr_avg),
    #         color='red')
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA/rom_pelvis_' + str(gc_count) + '.pickle',
                  'rb') as f:
            _, ea_hip_ROM_symmetry_transversal, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_transversal[1])
            plt.plot(ea_hip_ROM_symmetry_transversal[1], ea_hip_ROM_symmetry_transversal[0], 'g+')
    tr_avg3 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_transversal[0] - 1, ea_hip_ROM_symmetry_transversal[0] - 0.02, '{0:.2f}'.format(tr_avg),
    #         color='green')
    plt.axhline(y=ea_hip_ROM_symmetry_transversal[0], linewidth=0.3, color='black')
    plt.axvline(x=ea_hip_ROM_symmetry_transversal[0], linewidth=0.3, color='black')

    expert = ea_hip_ROM_symmetry_transversal[0]
    black_line = mlines.Line2D([], [], color='black',  linestyle='None',
                               markersize=10, label='Expert ' + '{0:.2f}'.format(expert) )

    blue_star = mlines.Line2D([], [], color='blue', marker='*', linestyle='None',
                              markersize=10, label='DM_LB_policy_THA_GT_THA (avg. '+'{0:.2f}'.format(tr_avg1)+
                                                   '/ex. diff. '+'{0:.2f}'.format(abs(expert-tr_avg1))+')')
    red_square = mlines.Line2D([], [], color='red', marker='s', linestyle='None',
                               markersize=10, label='DM_LB_policy_H_GT_THA (avg. '+'{0:.2f}'.format(tr_avg2)+'/ex. diff. '+
                                                    '{0:.2f}'.format(abs(expert-tr_avg2))+')')
    purple_triangle = mlines.Line2D([], [], color='green', marker='+', linestyle='None',
                                    markersize=10, label='DM_LB_policy_perfect_fit_H_GT_THA (avg. '+'{0:.2f}'.format(tr_avg3)+
                                                         '/ex. diff. '+'{0:.2f}'.format(abs(expert-tr_avg3))+')')

    plt.legend(handles=[black_line, blue_star, red_square, purple_triangle],loc='best')

    plt.ylabel('Expert Pelvis transversal ROM (degrees)')
    plt.xlabel('Agent Pelvis transversal ROM (degrees)')
    plt.title(' Pelvis transversal ROM (degrees) ')
    plt.savefig('C:/Users/kt199/Documents/SeptemberResults/THA_transversal_ROM_pelvis.png')
    plt.close(fig)


def plot_frontal_ROM_pelvis():
    fig = plt.figure()

    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA/rom_pelvis_' + str(gc_count) + '.pickle', 'rb') as f:
            ea_hip_ROM_symmetry_frontal, _,_ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_frontal[1])
            plt.plot(ea_hip_ROM_symmetry_frontal[1], ea_hip_ROM_symmetry_frontal[0], 'b*')
    fr_avg1 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_frontal[0] - 1, ea_hip_ROM_symmetry_frontal[0] + 0.05, '{0:.2f}'.format(fr_avg),
    #         color='blue')

    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/rom_pelvis_' + str(gc_count) + '.pickle',
                  'rb') as f:
            ea_hip_ROM_symmetry_frontal, _,_ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_frontal[1])

            plt.plot(ea_hip_ROM_symmetry_frontal[1], ea_hip_ROM_symmetry_frontal[0], 'rs')
    fr_avg2 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_frontal[0] - 1, ea_hip_ROM_symmetry_frontal[0] + 0.02, '{0:.2f}'.format(fr_avg),
    #         color='red')

    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA/rom_pelvis_' + str(gc_count) + '.pickle',
                  'rb') as f:
            ea_hip_ROM_symmetry_frontal, _, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_frontal[1])
            plt.plot(ea_hip_ROM_symmetry_frontal[1], ea_hip_ROM_symmetry_frontal[0], 'g+')
    fr_avg3 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_frontal[0] - 1, ea_hip_ROM_symmetry_frontal[0] - 0.02, '{0:.2f}'.format(fr_avg),
    #         color='green')
    plt.axhline(y=ea_hip_ROM_symmetry_frontal[0], linewidth=0.3, color='black')
    plt.axvline(x=ea_hip_ROM_symmetry_frontal[0], linewidth=0.3, color='black')
    expert = ea_hip_ROM_symmetry_frontal[0]
    black_line = mlines.Line2D([], [], color='black',  linestyle='None',
                               markersize=10, label='Expert ' + '{0:.2f}'.format(expert) )

    blue_star = mlines.Line2D([], [], color='blue', marker='*', linestyle='None',
                              markersize=10, label='DM_LB_policy_THA_GT_THA (avg. ' + '{0:.2f}'.format(fr_avg1) +
                                                   '/ex. diff. ' + '{0:.2f}'.format(abs(expert - fr_avg1)) + ')')
    red_square = mlines.Line2D([], [], color='red', marker='s', linestyle='None',
                               markersize=10, label='DM_LB_policy_H_GT_THA (avg. ' + '{0:.2f}'.format(fr_avg2) +
                                                    '/ex. diff. ' + '{0:.2f}'.format(abs(expert - fr_avg2)) + ')')
    purple_triangle = mlines.Line2D([], [], color='green', marker='+', linestyle='None',
                                    markersize=10,
                                    label='DM_LB_policy_perfect_fit_H_GT_THA (avg. ' + '{0:.2f}'.format(fr_avg3) +
                                          '/ex. diff. ' + '{0:.2f}'.format(abs(expert - fr_avg3)) + ')')

    plt.legend(handles=[black_line, blue_star, red_square, purple_triangle],loc='best')
    plt.ylabel('Expert Pelvis frontal ROM (degrees)')
    plt.xlabel('Agent Pelvis frontal ROM (degrees)')
    plt.title(' Pelvis frontal ROM (degrees) ')
    plt.savefig('C:/Users/kt199/Documents/SeptemberResults/THA_frontal_ROM_pelvis.png')
    plt.close(fig)


def plot_saggital_ROM_pelvis():
    fig = plt.figure()
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA/rom_pelvis_' + str(gc_count) + '.pickle', 'rb') as f:
            _, _, ea_hip_ROM_symmetry_saggital = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_saggital[1])
            plt.plot(ea_hip_ROM_symmetry_saggital[1], ea_hip_ROM_symmetry_saggital[0], 'b*')
    sag_avg1=np.array(gc_avg_vals).sum()/5
    #plt.text(ea_hip_ROM_symmetry_saggital[0] - 1, ea_hip_ROM_symmetry_saggital[0] + 0.05, '{0:.2f}'.format(sag_avg),color='blue')
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/rom_pelvis_' + str(gc_count) + '.pickle',
                  'rb') as f:
            ea_hip_ROM_symmetry_frontal, ea_hip_ROM_symmetry_transversal, ea_hip_ROM_symmetry_saggital = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_saggital[1])
            plt.plot(ea_hip_ROM_symmetry_saggital[1], ea_hip_ROM_symmetry_saggital[0], 'rs')
    sag_avg2=np.array(gc_avg_vals).sum()/5
    ##plt.text(ea_hip_ROM_symmetry_saggital[0] - 1, ea_hip_ROM_symmetry_saggital[0] + 0.02, '{0:.2f}'.format(sag_avg),color='red')

    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA/rom_pelvis_' + str(gc_count) + '.pickle',
                  'rb') as f:
            _, _, ea_hip_ROM_symmetry_saggital = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_saggital[1])
            plt.plot(ea_hip_ROM_symmetry_saggital[1], ea_hip_ROM_symmetry_saggital[0], 'g+')
    sag_avg3=np.array(gc_avg_vals).sum()/5
    #plt.text(ea_hip_ROM_symmetry_saggital[0] - 1, ea_hip_ROM_symmetry_saggital[0] - 0.01, '{0:.2f}'.format(sag_avg),color='green')

    plt.plot()
    plt.axhline(y=ea_hip_ROM_symmetry_saggital[0], linewidth=0.3, color='black')
    plt.axvline(x=ea_hip_ROM_symmetry_saggital[0], linewidth=0.3, color='black')

    expert = ea_hip_ROM_symmetry_saggital[0]
    black_line = mlines.Line2D([], [], color='black',  linestyle='None',
                               markersize=10, label='Expert ' + '{0:.2f}'.format(expert) )

    blue_star = mlines.Line2D([], [], color='blue', marker='*', linestyle='None',
                              markersize=10, label='DM_LB_policy_THA_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg1) +
                                                   '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg1)) + ')')
    red_square = mlines.Line2D([], [], color='red', marker='s', linestyle='None',
                               markersize=10, label='DM_LB_policy_H_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg2) +
                                                    '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg2)) + ')')
    purple_triangle = mlines.Line2D([], [], color='green', marker='+', linestyle='None',
                                    markersize=10,
                                    label='DM_LB_policy_perfect_fit_H_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg3) +
                                          '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg3)) + ')')

    plt.legend(handles=[black_line, blue_star, red_square, purple_triangle],loc='best')

    plt.ylabel('Expert Pelvis saggital ROM (degrees)')
    plt.xlabel('Agent Pelvis saggital ROM (degrees)')
    plt.title(' Pelvis saggital ROM (degrees) ')
    plt.savefig('C:/Users/kt199/Documents/SeptemberResults/THA_saggital_ROM_pelvis.png')
    plt.close(fig)



def plot_pelvis_ROM():
    plot_saggital_ROM_pelvis()
    plot_frontal_ROM_pelvis()
    plot_transversal_ROM_pelvis()



def plot_transversal_hip_ROM_symmetry():
    fig = plt.figure()
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA/rom_' + str(gc_count) + '.pickle', 'rb') as f:
            _, ea_hip_ROM_symmetry_transversal, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_transversal[1])
            plt.plot(ea_hip_ROM_symmetry_transversal[1], ea_hip_ROM_symmetry_transversal[0], 'b*')
    sag_avg1 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_transversal[0] - 1, ea_hip_ROM_symmetry_transversal[0] + 0.05, '{0:.2f}'.format(sag_avg),
    #         color='blue')

    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/rom_' + str(gc_count) + '.pickle',
                  'rb') as f:
            _, ea_hip_ROM_symmetry_transversal, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_transversal[1])
            plt.plot(ea_hip_ROM_symmetry_transversal[1], ea_hip_ROM_symmetry_transversal[0], 'rs')
    sag_avg2 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_transversal[0] - 1, ea_hip_ROM_symmetry_transversal[0] + 0.01, '{0:.2f}'.format(sag_avg),
    #         color='red')
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA/rom_' + str(gc_count) + '.pickle',
                  'rb') as f:
            _, ea_hip_ROM_symmetry_transversal, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_transversal[1])
            plt.plot(ea_hip_ROM_symmetry_transversal[1], ea_hip_ROM_symmetry_transversal[0], 'g+')
    sag_avg3 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_transversal[0] - 1, ea_hip_ROM_symmetry_transversal[0] - 0.03, '{0:.2f}'.format(sag_avg),
    #         color='green')
    plt.axhline(y=ea_hip_ROM_symmetry_transversal[0], linewidth=0.3, color='black')
    plt.axvline(x=ea_hip_ROM_symmetry_transversal[0], linewidth=0.3, color='black')
    expert = ea_hip_ROM_symmetry_transversal[0]
    black_line = mlines.Line2D([], [], color='black',  linestyle='None',
                               markersize=10, label='Expert ' + '{0:.2f}'.format(expert) )

    blue_star = mlines.Line2D([], [], color='blue', marker='*', linestyle='None',
                              markersize=10, label='DM_LB_policy_THA_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg1) +
                                                   '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg1)) + ')')
    red_square = mlines.Line2D([], [], color='red', marker='s', linestyle='None',
                               markersize=10, label='DM_LB_policy_H_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg2) +
                                                    '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg2)) + ')')
    purple_triangle = mlines.Line2D([], [], color='green', marker='+', linestyle='None',
                                    markersize=10,
                                    label='DM_LB_policy_perfect_fit_H_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg3) +
                                          '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg3)) + ')')

    plt.legend(handles=[black_line, blue_star, red_square, purple_triangle],loc='best')
    plt.ylabel('Expert Hip transversal ROM symmetry(degrees)')
    plt.xlabel('Agent Hip transversal ROM symmetry(degrees)')
    plt.title(' Hip transversal ROM symmetry(degrees) ')
    plt.savefig('C:/Users/kt199/Documents/SeptemberResults/THA_transversal_ROM_symmetry.png')
    plt.close(fig)


def plot_frontal_hip_ROM_symmetry():
    fig = plt.figure()
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA/rom_' + str(gc_count) + '.pickle', 'rb') as f:
            ea_hip_ROM_symmetry_frontal, _, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_frontal[1])
            plt.plot(ea_hip_ROM_symmetry_frontal[1], ea_hip_ROM_symmetry_frontal[0], 'b*')
    sag_avg1 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_frontal[0] - 1, ea_hip_ROM_symmetry_frontal[0] + 0.05, '{0:.2f}'.format(sag_avg),
    #         color='blue')
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/rom_' + str(gc_count) + '.pickle',
                  'rb') as f:
            ea_hip_ROM_symmetry_frontal, _, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_frontal[1])
            plt.plot(ea_hip_ROM_symmetry_frontal[1], ea_hip_ROM_symmetry_frontal[0], 'rs')
    sag_avg2 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_frontal[0] - 1, ea_hip_ROM_symmetry_frontal[0] + 0.01, '{0:.2f}'.format(sag_avg),
     #        color='red')
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA/rom_' + str(gc_count) + '.pickle',
                  'rb') as f:
            ea_hip_ROM_symmetry_frontal, _, _ = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_frontal[1])
            plt.plot(ea_hip_ROM_symmetry_frontal[1], ea_hip_ROM_symmetry_frontal[0], 'g+')
    sag_avg3 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_frontal[0] - 1, ea_hip_ROM_symmetry_frontal[0] - 0.03, '{0:.2f}'.format(sag_avg),
    #         color='green')
    plt.axhline(y=ea_hip_ROM_symmetry_frontal[0], linewidth=0.3, color='black')
    plt.axvline(x=ea_hip_ROM_symmetry_frontal[0], linewidth=0.3, color='black')
    #plt.text(ea_hip_ROM_symmetry_frontal[0] + 0.05, ea_hip_ROM_symmetry_frontal[0] + 0.001, 'expert hip ROM symmetry',
    #         rotation=90)
    expert = ea_hip_ROM_symmetry_frontal[0]
    black_line = mlines.Line2D([], [], color='black',  linestyle='None',
                               markersize=10, label='Expert ' + '{0:.2f}'.format(expert) )

    blue_star = mlines.Line2D([], [], color='blue', marker='*', linestyle='None',
                              markersize=10, label='DM_LB_policy_THA_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg1) +
                                                   '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg1)) + ')')
    red_square = mlines.Line2D([], [], color='red', marker='s', linestyle='None',
                               markersize=10, label='DM_LB_policy_H_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg2) +
                                                    '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg2)) + ')')
    purple_triangle = mlines.Line2D([], [], color='green', marker='+', linestyle='None',
                                    markersize=10,
                                    label='DM_LB_policy_perfect_fit_H_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg3) +
                                          '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg3)) + ')')

    plt.legend(handles=[black_line, blue_star, red_square, purple_triangle],loc='best')
    plt.ylabel('Expert Hip frontal ROM symmetry(degrees)')
    plt.xlabel('Agent Hip frontal ROM symmetry(degrees)')
    plt.title(' Hip frontal ROM symmetry(degrees) ')
    plt.savefig('C:/Users/kt199/Documents/SeptemberResults/THA_frontal_ROM_symmetry.png')
    plt.close(fig)


def plot_saggital_hip_ROM_symmetry():
    fig = plt.figure()
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA/rom_' + str(gc_count) + '.pickle', 'rb') as f:
            _, _, ea_hip_ROM_symmetry_saggital = pickle.load(f)
            plt.plot(ea_hip_ROM_symmetry_saggital[1], ea_hip_ROM_symmetry_saggital[0], 'b*')
            gc_avg_vals.append(ea_hip_ROM_symmetry_saggital[1])
    sag_avg1 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_saggital[0] - 1, ea_hip_ROM_symmetry_saggital[0] + 0.05, '{0:.2f}'.format(sag_avg),
    #         color='blue')
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_THA_policyH5/rom_' + str(gc_count) + '.pickle',
                  'rb') as f:
            _, _, ea_hip_ROM_symmetry_saggital = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_saggital[1])
            plt.plot(ea_hip_ROM_symmetry_saggital[1], ea_hip_ROM_symmetry_saggital[0], 'rs')
    sag_avg2 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_saggital[0] - 1, ea_hip_ROM_symmetry_saggital[0] + 0.01, '{0:.2f}'.format(sag_avg),
    #         color='red')
    gc_avg_vals=[]
    for gc_count in range(5):
        with open('C:/Users/kt199/Documents/SeptemberResults/DM_LB_perfect_fit_THA/rom_' + str(gc_count) + '.pickle',
                  'rb') as f:
            _, _, ea_hip_ROM_symmetry_saggital = pickle.load(f)
            gc_avg_vals.append(ea_hip_ROM_symmetry_saggital[1])
            plt.plot(ea_hip_ROM_symmetry_saggital[1], ea_hip_ROM_symmetry_saggital[0], 'g+')
    sag_avg3 = np.array(gc_avg_vals).sum() / 5
    #plt.text(ea_hip_ROM_symmetry_saggital[0] - 1, ea_hip_ROM_symmetry_saggital[0] - 0.03, '{0:.2f}'.format(sag_avg),
    #         color='green')
    plt.plot()
    plt.axhline(y=ea_hip_ROM_symmetry_saggital[0], linewidth=0.3, color='black')
    plt.axvline(x=ea_hip_ROM_symmetry_saggital[0], linewidth=0.3, color='black')
    expert=ea_hip_ROM_symmetry_saggital[0]
    black_line = mlines.Line2D([], [], color='black',  linestyle='None',
                              markersize=10, label='Expert '+ '{0:.2f}'.format(expert) )

    blue_star = mlines.Line2D([], [], color='blue', marker='*', linestyle='None',
                              markersize=10, label='DM_LB_policy_THA_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg1) +
                                                   '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg1)) + ')')
    red_square = mlines.Line2D([], [], color='red', marker='s', linestyle='None',
                               markersize=10, label='DM_LB_policy_H_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg2) +
                                                    '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg2)) + ')')
    purple_triangle = mlines.Line2D([], [], color='green', marker='+', linestyle='None',
                                    markersize=10,
                                    label='DM_LB_policy_perfect_fit_H_GT_THA (avg. ' + '{0:.2f}'.format(sag_avg3) +
                                          '/ex. diff. ' + '{0:.2f}'.format(abs(expert - sag_avg3)) + ')')
    plt.legend(handles=[black_line, blue_star, red_square, purple_triangle],loc='best')

    plt.ylabel('Expert Hip saggital ROM symmetry(degrees)')
    plt.xlabel('Agent Hip saggital ROM symmetry(degrees)')
    plt.title(' Hip saggital ROM symmetry(degrees) ')
    plt.savefig('C:/Users/kt199/Documents/SeptemberResults/THA_saggital_ROM_symmetry.png')
    plt.close(fig)

def plot_hip_symmetry():
    plot_saggital_hip_ROM_symmetry()
    plot_frontal_hip_ROM_symmetry()
    plot_transversal_hip_ROM_symmetry()


plot_hip_symmetry()
#plot_pelvis_ROM()




