from trafos import euler_from_quaternion, q_conjugate, quaternion_matrix4x4, quaternion_matrix
import numpy as np


def radian_to_degree(euler_angle, revolute=False):
    if revolute:
        return euler_angle * 180 / np.math.pi
    euler_angle[0] = euler_angle[0] * 180 / np.math.pi
    euler_angle[1] = euler_angle[1] * 180 / np.math.pi
    euler_angle[2] = euler_angle[2] * 180 / np.math.pi
    return euler_angle


def rad_to_degree(rad_array):
    rad_arr=[]
    for rad in rad_array:
        rad_arr.append(rad * 180 / np.math.pi)
    return rad_arr

# Lower body for agent and expert
def set_lower_body_data_euler_angles(body_parts):
    pelvis_agent = []
    right_hip_agent = []
    right_knee_agent = []
    right_foot_agent = []
    left_hip_agent = []
    left_knee_agent = []
    left_foot_agent = []

    for i in range(body_parts.shape[0]):
        pelvis_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 3:7]))))
        right_hip_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 7:11]))))
        right_knee_agent.append(radian_to_degree(body_parts[i, 11], True))
        right_foot_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 12:16]))))
        left_hip_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 16:20]))))
        left_knee_agent.append(radian_to_degree(body_parts[i, 20], True))
        left_foot_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 21:]))))

    body_parts = [
        np.array(pelvis_agent),
        np.array(right_hip_agent),
        np.array(right_knee_agent),
        np.array(right_foot_agent),
        np.array(left_hip_agent),
        np.array(left_knee_agent),
        np.array(left_foot_agent)
    ]
    return body_parts


def set_euler_angles_agent_fullbody(body_parts):
    pelvis_agent = []
    right_hip_agent = []
    right_knee_agent = []
    right_foot_agent = []
    left_hip_agent = []
    left_knee_agent = []
    left_foot_agent = []
    for i in range(body_parts.shape[0]):
        # right_hip_agent.append(euler_from_quaternion([body_parts[i, 15],body_parts[i, 16],body_parts[i, 18],body_parts[i, 17]]))
        # right_knee_agent.append(body_parts[i, 19])
        # right_foot_agent.append(euler_from_quaternion([body_parts[i, 20],body_parts[i, 21],body_parts[i, 23],body_parts[i, 22]]))
        # left_hip_agent.append(euler_from_quaternion([body_parts[i, 29],body_parts[i, 30],body_parts[i, 32],body_parts[i, 31]]))
        # left_knee_agent.append(body_parts[i, 33])
        # left_foot_agent.append(euler_from_quaternion([body_parts[i, 34],body_parts[i, 35],body_parts[i, 37],body_parts[i, 36]]))

        # right_hip_agent.append(
        #    euler_from_quaternion([body_parts[i][15], body_parts[i][16], body_parts[i][18], body_parts[i][17]]))
        # right_knee_agent.append(body_parts[i][19])
        # right_foot_agent.append(
        #    euler_from_quaternion([body_parts[i][20], body_parts[i][21], body_parts[i][23], body_parts[i][22]]))
        # left_hip_agent.append(
        #    euler_from_quaternion([body_parts[i][29], body_parts[i][30], body_parts[i][32], body_parts[i][31]]))
        # left_knee_agent.append(body_parts[i][33])
        # left_foot_agent.append(
        #    euler_from_quaternion([body_parts[i][34], body_parts[i][35], body_parts[i][37], body_parts[i][36]]))


        pelvis_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i,11:15]))))
        right_hip_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 15:19]))))
        right_knee_agent.append(radian_to_degree(body_parts[i, 19], True))
        right_foot_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 20:24]))))
        left_hip_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 29:33]))))
        left_knee_agent.append(radian_to_degree(body_parts[i, 33], True))
        left_foot_agent.append(radian_to_degree(np.array(euler_from_quaternion(body_parts[i, 34:38]))))
    body_parts = [
        np.array(pelvis_agent),
        np.array(right_hip_agent),
        np.array(right_knee_agent),
        np.array(right_foot_agent),
        np.array(left_hip_agent),
        np.array(left_knee_agent),
        np.array(left_foot_agent)
    ]
    return body_parts


def set_euler_angles_expert_fullbody(body_parts):
    pelvis_expert = []
    right_hip_expert = []
    right_knee_expert = []
    right_foot_expert = []
    left_hip_expert = []
    left_knee_expert = []
    left_foot_expert = []

    for i in range(body_parts.shape[0]):
        right_hip_expert.append(euler_from_quaternion(body_parts[i, 15:19]))
        right_knee_expert.append(body_parts[i, 19])
        right_foot_expert.append(euler_from_quaternion(body_parts[i, 20:24]))
        left_hip_expert.append(euler_from_quaternion(body_parts[i, 29:33]))
        left_knee_expert.append(body_parts[i, 33])
        left_foot_expert.append(euler_from_quaternion(body_parts[i, 34:38]))

    body_parts = [
        np.array(right_hip_expert),
        np.array(right_knee_expert),
        np.array(right_foot_expert),
        np.array(left_hip_expert),
        np.array(left_knee_expert),
        np.array(left_foot_expert)
    ]
    return body_parts


class AgentExpert:
    def __init__(self, body_parts_agent, body_parts_expert):
        self.body_parts_agent = set_lower_body_data_euler_angles(body_parts_agent)
        self.body_parts_expert = set_lower_body_data_euler_angles(body_parts_expert)

    def __iter__(self):
        for i in range(7):
            yield self.body_parts_agent[i], self.body_parts_expert[i]


class AgentExpertFB:
    def __init__(self, body_parts_agent, body_parts_expert):
        self.body_parts_agent = set_euler_angles_agent_fullbody(body_parts_agent)
        self.body_parts_expert = set_euler_angles_agent_fullbody(body_parts_expert)

    def __iter__(self):
        for i in range(7):
            yield self.body_parts_agent[i], self.body_parts_expert[i]
