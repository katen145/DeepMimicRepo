import numpy as np

from loaddatasets.trafos import quaternion_matrix, MRP_to_quaternion, quaternion_matrix4x4, quaternion_multiply
from loaddatasets.trafos import quaternion_matrix, MRP_to_quaternion, quaternion_matrix4x4, quaternion_multiply
from pyquaternion import Quaternion
from sklearn.decomposition import PCA


class structtype():
    pass

def computeMotionDirection(aData, cData):
    nTime = aData.seg[0].pos_g.shape[1]
    X = np.array([]).reshape(0,3)
    for segIdx in range(len(aData.seg)):
        for t in range(nTime):
            X = np.vstack([X, aData.seg[segIdx].pos_g[:,t]])
    pca = PCA(n_components=1)
    pca.fit(X)
    v = np.zeros(3)
    v[0:2] = pca.components_[0][0:2] / np.linalg.norm(pca.components_[0][0:2])
    return v

def computeMotionDirectionLoc(listpos_g):
    X = np.array([])
    X = np.array([]).reshape(0,3)
    for traj_g in listpos_g:
        for t in range(traj_g.shape[1]):
            X = np.vstack([X, traj_g[:,t]])
    pca = PCA(n_components=1)
    pca.fit(X)
    v = np.zeros(3)
    v[0:2] = pca.components_[0][0:2] / np.linalg.norm(pca.components_[0][0:2])
    return v


def computeMotionDirectionLocFootGuided(listpos_g, idxFoot):
    X = np.array([])

    P1 = listpos_g[idxFoot][:, 0]
    P2 = listpos_g[idxFoot][:, -1]

    dirFoot = (P2 - P1)/np.linalg.norm(P2 - P1)
    dirProj = np.zeros(3)
    dirProj[0:2] = dirFoot[0:2]/np.linalg.norm(dirFoot[0:2])

    return dirProj

def R_GalG(d_G):
    d_G = d_G/np.linalg.norm(d_G)
    z_G = np.array([0.0, 0.0, 1.0])
    R_out = np.zeros([3,3])
    R_out[:, 0] = d_G
    R_out[:, 1] = np.cross(z_G, d_G)
    R_out[:, 2] = z_G
    return np.transpose(R_out)

def relPosToOrigLoc(origSegIdx, aData, pos_g_curr, idx):
    posOrig = np.zeros(3)
    posOrig[0:2] = aData.seg[origSegIdx].pos_g[:, idx][0:2] # proj. onto floor
    return pos_g_curr - posOrig

def computePrimitves(label, aData, origSegIdx, cData):
    idxBeg = 0
    idxEnd = aData.nTime
    nSegs = len(aData.seg)
    primList = []
    minLength = 10
    tRel = 0

    for t in range(idxBeg,idxEnd):
        if (tRel > minLength and t < idxEnd and label[t] == 1):
            seg = [structtype() for i in range(nSegs)]
            locPosList = [np.zeros((3, tRel)) for i in range(nSegs)]
            for segIdx in range(nSegs):
                seg[segIdx].pos_g = np.zeros((3, tRel))
                for tLoc in range(tRel):
                    idx = t - tRel + tLoc
                    locPosList[segIdx][:, tLoc] = aData.seg[segIdx].pos_g[:, idx]
                    seg[segIdx].pos_g[:, tLoc] = relPosToOrigLoc(origSegIdx, aData, aData.seg[segIdx].pos_g[:, idx], t-tRel)


            d_G = computeMotionDirectionLocFootGuided(locPosList, cData.segValueByNames['RightFoot'])
            #d_G = computeMotionDirectionLoc(locPosList)

            for segIdx in range(nSegs):
                seg[segIdx].quat_gs = np.zeros((4, tRel))
                seg[segIdx].T = np.zeros((16, tRel))

                for tLoc in range(tRel):
                    idx = t - tRel + tLoc
                    quat_gs = Quaternion(array=aData.seg[segIdx].quat_gs[:, idx])
                    Rot_GalG = R_GalG(d_G)
                    R_GalS = np.matmul(Rot_GalG, quat_gs.rotation_matrix)
                    quat_GalS = Quaternion(matrix=R_GalS)
                    seg[segIdx].quat_gs[0, tLoc] = quat_GalS.scalar
                    seg[segIdx].quat_gs[1:4, tLoc] = quat_GalS.vector
                    T = quaternion_matrix4x4(seg[segIdx].quat_gs[:, tLoc])
                    seg[segIdx].pos_g[:, tLoc] = np.matmul(Rot_GalG, seg[segIdx].pos_g[:, tLoc])
                    T[0:3, 3] = seg[segIdx].pos_g[:, tLoc]
                    seg[segIdx].T[:, tLoc] = T.reshape(16)

                seg[segIdx].tBegin = t - tRel
                seg[segIdx].tEnd = t
            primList.append(seg)
            tRel = 0

        tRel += 1

    return primList

def computePrimitvesWalkingStraight(label, aData, origSegIdx, cData, dict_labels):
    idxBeg = 0
    idxEnd = aData.nTime
    nSegs = len(aData.seg)
    primList = []
    primListStraight = []
    minLength = 10
    tRel = 0
    tStrGl = 0
    for t in range(idxBeg,idxEnd):
        if (tRel > minLength and t < idxEnd and label[t] == 1):
            seg = [structtype() for i in range(nSegs)]
            locPosList = [np.zeros((3, tRel)) for i in range(nSegs)]
            for segIdx in range(nSegs):
                seg[segIdx].pos_g = np.zeros((3, tRel))
                for tLoc in range(tRel):
                    idx = t - tRel + tLoc
                    locPosList[segIdx][:, tLoc] = aData.seg[segIdx].pos_g[:, idx]
                    #seg[segIdx].pos_g[:, tLoc] = relPosToOrigLoc(origSegIdx, aData, aData.seg[segIdx].pos_g[:, idx], t-tRel)
                    seg[segIdx].pos_g[:, tLoc] = aData.seg[segIdx].pos_g[:,idx]  # relPosToOrigLoc(origSegIdx, aData, aData.seg[segIdx].pos_g[:, idx], t - tRel)

            d_G = computeMotionDirectionLocFootGuided(locPosList, cData.segValueByNames['RightFoot'])
            #d_G = computeMotionDirectionLoc(locPosList)

            for segIdx in range(nSegs):
                seg[segIdx].quat_gs = np.zeros((4, tRel))
                seg[segIdx].T = np.zeros((16, tRel))

                for tLoc in range(tRel):
                    idx = t - tRel + tLoc
                    quat_gs = Quaternion(array=aData.seg[segIdx].quat_gs[:, idx])
                    Rot_GalG = R_GalG(d_G)
                    R_GalS = np.matmul(Rot_GalG, quat_gs.rotation_matrix)
                    quat_GalS = Quaternion(matrix=R_GalS)
                    seg[segIdx].quat_gs[0, tLoc] = quat_GalS.scalar
                    seg[segIdx].quat_gs[1:4, tLoc] = quat_GalS.vector
                    T = quaternion_matrix4x4(seg[segIdx].quat_gs[:, tLoc])
                    seg[segIdx].pos_g[:, tLoc] = np.matmul(Rot_GalG, seg[segIdx].pos_g[:, tLoc])
                    T[0:3, 3] = seg[segIdx].pos_g[:, tLoc]
                    seg[segIdx].T[:, tLoc] = T.reshape(16)
                seg[segIdx].tBegin = t - tRel
                seg[segIdx].tEnd = t

            # check if walking straight
            if (sum(dict_labels[1,t-tRel:t]) == 0):
                primList.append(seg)
            if (sum(dict_labels[1,t-tRel:t]) > 0 and len(primList) > 0):
                segStraight = [structtype() for i in range(nSegs)]
                tStraight = 0
                for primSeg in primList:
                    tStraight += len(primSeg[0].quat_gs[0,:])

                for segIdx in range(len(primSeg)):
                    segStraight[segIdx].quat_gs = np.zeros((4, tStraight))
                    segStraight[segIdx].pos_g = np.zeros((3, tStraight))
                    segStraight[segIdx].T = np.zeros((16, tStraight))

                tStr = 0
                for primSeg in primList:
                    for segIdx in range(len(primSeg)):

                        tDiff = primSeg[segIdx].tEnd - primSeg[segIdx].tBegin
                        for tLoc in range(tDiff):
                            # for t, tLoc in zip(range(primSeg[segIdx].tBegin, primSeg[segIdx].tEnd), range(primSeg[segIdx].tEnd - primSeg[segIdx].tBegin)):
                            segStraight[segIdx].quat_gs[:, tStr + tLoc] = primSeg[segIdx].quat_gs[:, tLoc]
                            segStraight[segIdx].pos_g[:, tStr + tLoc] = primSeg[segIdx].pos_g[:, tLoc]
                            segStraight[segIdx].T[:, tStr + tLoc] = primSeg[segIdx].T[:, tLoc]
                    tStr+=tDiff
                tStrGl += tStr
                for segIdx in range(len(segStraight)):
                    segStraight[segIdx].tBegin = tStrGl - tStr
                    segStraight[segIdx].tEnd = tStrGl
                primListStraight.append(segStraight)
                primList = []

            tRel = 0

        tRel += 1

    return primListStraight

def sequentializePrimitives(segList, aData):
    aDataNew =  aData
    nTimeNew = segList[-1][0].tEnd
    aDataNew.nTime = nTimeNew

    for segIdx in range(len(aData.seg)):
        aDataNew.seg[segIdx].pos_g = np.zeros((3, nTimeNew))
        aDataNew.seg[segIdx].quat_gs = np.zeros((4, nTimeNew))
        aDataNew.seg[segIdx].T = np.zeros((16, nTimeNew))

    t = 0
    for primSeg in segList:
        for segIdx in range(len(primSeg)):
            tDiff = primSeg[segIdx].tEnd - primSeg[segIdx].tBegin
            for tLoc in range(tDiff):
            #for t, tLoc in zip(range(primSeg[segIdx].tBegin, primSeg[segIdx].tEnd), range(primSeg[segIdx].tEnd - primSeg[segIdx].tBegin)):
                aDataNew.seg[segIdx].quat_gs[:,t+tLoc] = primSeg[segIdx].quat_gs[:,tLoc]
                aDataNew.seg[segIdx].pos_g[:,t+tLoc] = primSeg[segIdx].pos_g[:,tLoc]
                aDataNew.seg[segIdx].T[:,t+tLoc] = primSeg[segIdx].T[:,tLoc]
        t+=tDiff

    aDataNew.nTime = t
    return aDataNew