class structtype():
    pass

stateLength = 14
