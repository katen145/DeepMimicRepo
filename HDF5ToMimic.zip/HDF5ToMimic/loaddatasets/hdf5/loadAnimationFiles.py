import numpy as np
from loaddatasets.hdf5.loadutils import structtype
from loaddatasets.hdf5.loadutils import stateLength
from loaddatasets.trafos import quaternion_matrix4x4, MRP_to_quaternion,  quaternion_matrix ,quaternion_multiply


def loadAnimationFile(animtationFile, sampleLimit):
    aData = structtype()  # [structtype() for i in range(nTime)]
    loadAnimationFileRef(aData, animtationFile, sampleLimit)
    return aData

def loadAnimationFileRef(aData, animtationFile, sampleLimit):
    aFile = open(animtationFile, "r")
    aDataAll = []
    for line in aFile:
        rLineFloat = [float(i) for i in line.split()]
        aDataAll.append(rLineFloat)

    # create struct for animation data
    nSegs = int(len(aDataAll[0]) / stateLength)
    if (sampleLimit == -1):
        nTime = len(aDataAll)
    else:
        nTime = min(sampleLimit, len(aDataAll))
    seg = [structtype() for i in range(nSegs)]

    for sIdx in range(0, nSegs):
        seg[sIdx].pos_g = np.zeros((3, nTime))
        seg[sIdx].quat_gs = np.zeros((4, nTime))
        seg[sIdx].T = np.zeros((16, nTime))
        # seg[sIdx].T = np.zeros((4,4, nTime))
        T = np.zeros((4, 4))
        for t in range(nTime):
            seg[sIdx].pos_g[:, t] = aDataAll[t][sIdx * stateLength:sIdx * stateLength + 3]
            seg[sIdx].quat_gs[:, t] = aDataAll[t][sIdx * stateLength + 3:sIdx * stateLength + 7]
            T = quaternion_matrix4x4(seg[sIdx].quat_gs[:, t])
            T[0:3, 3] = seg[sIdx].pos_g[:, t]
            seg[sIdx].T[:, t] = T.reshape(16)
    aData.seg = seg
    aData.nTime = nTime
    aData.nSegs = nSegs


def loadAnimationFromDict(dict, nSegs, nTime):
    aData = structtype()
    seg = [structtype() for i in range(nSegs)]
    for segIdx in range(0, nSegs):
        seg[segIdx].pos_g = np.zeros((3, nTime))
        seg[segIdx].quat_gs = np.zeros((4, nTime))
        seg[segIdx].T = np.zeros((16, nTime))
        #seg[segIdx].mrp = np.zeros((3, nTime))
        for t in range(nTime):
            quat = MRP_to_quaternion(dict["mrp_sg"][t][3 * segIdx:3 * segIdx + 3])
            seg[segIdx].quat_gs[:, t] = quat/np.linalg.norm(quat)
            seg[segIdx].pos_g[:, t] = dict["s_g"][t][3*segIdx:3*segIdx+3]
            T = quaternion_matrix4x4(seg[segIdx].quat_gs[:, t])
            T[0:3, 3] = seg[segIdx].pos_g[:, t]
            seg[segIdx].T[:, t] = T.reshape(16)
            #seg[segIdx].mrp[:, t] =  dict["mrp_sg"][t][3 * segIdx:3 * segIdx + 3]
    aData.seg = seg
    aData.nTime = nTime
    aData.nSegs = nSegs
    return aData

def loadAnimationAndIMUTrajFromDict(dict, nSegs, nTime, cData):
    aData = structtype()
    seg = [structtype() for i in range(nSegs)]
    for segIdx in range(0, nSegs):
        seg[segIdx].pos_g = np.zeros((3, nTime))
        seg[segIdx].quat_gs = np.zeros((4, nTime))
        seg[segIdx].T = np.zeros((16, nTime))
        seg[segIdx].TIMU = np.zeros((16, nTime))
        for t in range(nTime):
            quat = MRP_to_quaternion(dict["mrp_gs"][t][3 * segIdx:3 * segIdx + 3])
            seg[segIdx].quat_gs[:, t] = quat/np.linalg.norm(quat)
            seg[segIdx].pos_g[:, t] = dict["s_g"][t][3*segIdx:3*segIdx+3]
            T = quaternion_matrix4x4(seg[segIdx].quat_gs[:, t])
            T[0:3, 3] = seg[segIdx].pos_g[:, t]
            seg[segIdx].T[:, t] = T.reshape(16)
            q_SI = cData.segCalib[segIdx].quat_si
            #quat_GI =np.matmul(seg[segIdx].quat_gs[:, t], q_SI)
            quat_GI =quaternion_multiply(seg[segIdx].quat_gs[:, t], q_SI)
            TIMU = quaternion_matrix4x4(quat_GI)
            TIMU[0:3, 3] = seg[segIdx].pos_g[:, t] + np.matmul(quaternion_matrix(seg[segIdx].quat_gs[:, t]), cData.segCalib[segIdx].pos_s)
            seg[segIdx].TIMU[:,t] = TIMU.reshape(16)
            #seg[segIdx].mrp[:, t] = dict["mrp_sg"][t][3 * segIdx:3 * segIdx + 3]
    aData.seg = seg
    aData.nTime = nTime
    aData.nSegs = nSegs
    return aData