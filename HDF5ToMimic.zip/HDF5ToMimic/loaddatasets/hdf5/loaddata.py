import numpy as np
from utils.loaddatasets.hdf5.loadAnimationFiles import loadAnimationFile, loadAnimationFileRef
from utils.loaddatasets.hdf5.loadCalibrationFiles import loadCalibFile, loadCalibFileRef
from utils.loaddatasets.hdf5.loadutils import structtype
from utils.loaddatasets.hdf5.loadIMUData import loadIMUData, loadIMUDataRef
from utils.loaddatasets.trafos import quaternion_matrix, quationion_to_MRP, MRP_to_quaternion

from utils.loaddatasets.hdf5.createlabels import computeIC, compute_euler_angles, compute_segmentation, loadFoodpoints_g, \
    computeStrideLength, idxSegmentation, compute_segmentation_and_labelIdx

import os


def loadData(pathLearningData, scenarioTitle, id, sampleLimit=-1, dataLoad = ['a', 'c', 'i']):
    person = 'P{}'.format(id)
    personPath = pathLearningData + person + '/'
    scenario = person + scenarioTitle
    animtationFile = personPath+'a'+scenario+'.txt'
    calibFile = personPath+'c'+scenario+'.txt'
    imuFile = personPath+'i'+scenario+'.txt'

    aData = []
    cData = []
    iData = []

    fileStatus = True

    if ('a' in dataLoad):
        # Load Animation files
        aData, fileStatus = loadAnimationFile(animtationFile, sampleLimit)
        #print(fileStatus)
        if (not fileStatus):
            return aData, cData, iData, fileStatus
    if ('c' in dataLoad):
        # Load Calibration data
        cData, fileStatus = loadCalibFile(calibFile, aData.nSegs)
        if (not fileStatus):
            return aData, cData, iData, fileStatus
    if ('i' in dataLoad):
        # Load IMU Data
        iData, fileStatus = loadIMUData(imuFile, aData.nSegs, cData.segValueByNames, sampleLimit)
        if (not fileStatus):
            return aData, cData, iData, fileStatus

    return aData, cData, iData, fileStatus


def storeFeaturesStrideLen(stridelength, maxStrideLen, iData, idxIMU, side):
    labels = []
    features = np.array([]).reshape(0,6*maxStrideLen)
    for s in stridelength[side]:
        # use maxStrideLength with zero padding at the end or truncation at the end
        features3dacc = np.zeros((3, maxStrideLen))
        features3dgyr = np.zeros((3, maxStrideLen))
        if (s[1] - s[0] > maxStrideLen):
            features3dacc[:,0:maxStrideLen] = iData[idxIMU[side]].acc[:,s[0]:s[0] + maxStrideLen]
            features3dgyr[:,0:maxStrideLen] = iData[idxIMU[side]].gyr[:,s[0]:s[0] + maxStrideLen]
        else:
            features3dacc[:,0:s[1] - s[0]] = iData[idxIMU[side]].acc[:,s[0]:s[1]]
            features3dgyr[:,0:s[1] - s[0]] = iData[idxIMU[side]].gyr[:,s[0]:s[1]]
        add = np.append(features3dacc.reshape(3*maxStrideLen), features3dgyr.reshape(3*maxStrideLen))
        features = np.vstack([features, add])
        labels = np.append(labels,s[2])
    return features, labels

def storeNormFeaturesStrideLen(stridelength, maxStrideLen, N, iData, idxIMU, side):
    labels = []
    #N = 1
    features = np.array([]).reshape(0,N*maxStrideLen)
    for s in stridelength[side]:

        # use maxStrideLength with zero padding at the end or truncation at the end
        #features3dacc = np.zeros((N, maxStrideLen))
        features3dgyr = np.zeros((N, maxStrideLen))

        if (s[1] - s[0] > maxStrideLen):
            for i in range(maxStrideLen):
                #features3dacc[:,i] = np.linalg.norm(iData[idxIMU[side]].acc[:,s[0]:s[0] + i])
                features3dgyr[:,i] = np.linalg.norm(iData[idxIMU[side]].gyr[:,s[0]:s[0] + i])
        else:
            for i in range(s[1] - s[0]):
                #features3dacc[:,i] = np.linalg.norm(iData[idxIMU[side]].acc[:,s[0]:s[0] + i])
                features3dgyr[:,i] = np.linalg.norm(iData[idxIMU[side]].gyr[:,s[0]:s[0] + i])
        add = features3dgyr.reshape(N * maxStrideLen)

        features = np.vstack([features, add])
        labels = np.append(labels,s[2])
    return features, labels

def storeMeanNormFeaturesStrideLen(stridelength, maxStrideLen, N, iData, idxIMU, side):
    labels = []
    features = np.array([]).reshape(0,1*N)
    for s in stridelength[side]:
        features3dgyr = np.zeros((N))

        if (s[1] - s[0] > maxStrideLen):
            features3dgyr[0] = np.mean(np.linalg.norm(iData[idxIMU[side]].gyr[:,s[0]:s[0] + maxStrideLen]))
        else:
            features3dgyr[0] = np.mean(np.linalg.norm(iData[idxIMU[side]].gyr[:,s[0]:s[1]]))
        add = features3dgyr # np.append(features3dacc, features3dgyr)

        features = np.vstack([features, add])
        labels = np.append(labels,s[2])
    return features, labels


def storeAppend(X, Y, side, features, labels):
    X[side]= np.vstack([X[side], features])
    Y[side] = np.append(Y[side],labels)
    return X, Y


def loadLabeledDataStrideLength(pathLearningData, scenarioTitle, idRange, sampleLimit=-1, maxStrideLen=256):
    X_all = [structtype() for i in range(2)]
    X_straight = [structtype() for i in range(2)]
    X_other = [structtype() for i in range(2)]
    Y_all = [structtype() for i in range(2)]
    Y_straight = [structtype() for i in range(2)]
    Y_other = [structtype() for i in range(2)]
    labelIdx = [structtype() for i in range(2)]
    N=3
    S=2
    for l in range(2):
        X_all[l] = np.array([]).reshape(0,S*N*maxStrideLen)
        X_straight[l] = np.array([]).reshape(0,S*N*maxStrideLen)
        X_other[l] = np.array([]).reshape(0,S*N*maxStrideLen)
        Y_all[l] = []
        Y_straight[l] = []
        Y_other[l] = []
        labelIdx[l] = []

    for id in idRange:
        print('Load id:'+ str(id))
        aData, cData, iData = loadData(pathLearningData, scenarioTitle, id, sampleLimit)
        segEndPt_g = loadFoodpoints_g(aData, cData)
        # obtain initial contact for left and right foot
        ic = computeIC(segEndPt_g, cData, iData, aData.nTime, 0.5, 5.0, True)
        # obtain turning segmentation
        pelvis_euler_angles, pelvis_euler_angles_diff = compute_euler_angles(aData, cData, iData, aData.nTime)
        # segment phases as belonging to straight gait and turing
        seg, idxContact = compute_segmentation(pelvis_euler_angles_diff, ic, aData.nTime, 10)

        stridelength, stridelength_straight, stridelength_other, labelIdxTmp = \
            computeStrideLength(segEndPt_g, ic, seg, aData.nTime, cData)

        idxIMU = []
        idxIMU.append(cData.segValueByNames['LeftFoot'])
        idxIMU.append(cData.segValueByNames['RightFoot'])

        for side in range(2): # left and right side!
            labelIdx[side] = np.append(labelIdx[side], labelIdxTmp[side])

            #features, labels = storeFeaturesStrideLenWindow(stridelength, maxStrideLen, iData, idxIMU, side)
            features, labels = storeFeaturesStrideLen(stridelength, maxStrideLen, iData, idxIMU, side)
            #features, labels = storeNormFeaturesStrideLen(stridelength, maxStrideLen, N, iData, idxIMU, side)
            #features, labels = storeMeanNormFeaturesStrideLen(stridelength, maxStrideLen, N, iData, idxIMU, side)
            storeAppend(X_all, Y_all, side, features, labels)

            features, labels = storeFeaturesStrideLen(stridelength_straight, maxStrideLen, iData, idxIMU, side)
            #features, labels = storeNormFeaturesStrideLen(stridelength_straight, maxStrideLen, N, iData, idxIMU, side)
            #features, labels = storeMeanNormFeaturesStrideLen(stridelength_straight, maxStrideLen, N, iData, idxIMU, side)
            storeAppend(X_straight, Y_straight, side, features, labels)

            features, labels = storeFeaturesStrideLen(stridelength_other, maxStrideLen, iData, idxIMU, side)
            #features, labels = storeNormFeaturesStrideLen(stridelength_other, maxStrideLen, N, iData, idxIMU, side)
            #features, labels = storeMeanNormFeaturesStrideLen(stridelength_other, maxStrideLen, N, iData, idxIMU, side)
            storeAppend(X_other, Y_other, side, features, labels)

    print('Finished Loading!')

    return X_all, Y_all, X_straight, Y_straight, labelIdx, maxStrideLen

def storeFeaturesIC(features, ic_idx, winLength, iData, idxIMU, side):
    print(ic_idx)
    for s in ic_idx:
        if (s < winLength):
            print('PROBLEM IN FEATURE SELECTION -> This should not happen!')
            continue
        # use maxStrideLength with zero padding at the end or truncation at the end
        features3dacc = np.zeros((3, winLength))
        features3dgyr = np.zeros((3, winLength))
        features3dacc[:, 0:winLength] = iData[idxIMU[side]].acc[:, s-winLength:s]
        features3dgyr[:, 0:winLength] = iData[idxIMU[side]].gyr[:, s-winLength:s]
        add = np.append(features3dacc.transpose().reshape(3 * winLength), features3dgyr.transpose().reshape(3 * winLength))
        #print len(add)
        features[side] = np.vstack([features[side], add])
        #print len(features[side])
    return features

def storeFeaturesWindow(features, winLength, iData, idxIMU, side, nTime):
    #accTest = np.array([[1,2],[2,4],[3,6]])
    #gyrTest = np.array([[7,14],[8,16],[9,18]])

    for s in range(nTime):
        #print s
        # use maxStrideLength with zero padding at the end or truncation at the end
        if (s < winLength-1):
        #if (s < winLength):
            features3dacc = np.zeros((3, winLength))
            features3dgyr = np.zeros((3, winLength))
        else:
            features3dacc = np.zeros((3, winLength))
            features3dgyr = np.zeros((3, winLength))
            features3dacc[:, 0:winLength] = iData[idxIMU[side]].acc[:, s-winLength+1:s+1]
            features3dgyr[:, 0:winLength] = iData[idxIMU[side]].gyr[:, s-winLength+1:s+1]
            #features3dacc[:, 0:winLength] = iData[idxIMU[side]].acc[:, s-winLength:s]
            #features3dgyr[:, 0:winLength] = iData[idxIMU[side]].gyr[:, s-winLength:s]
        add = np.append(features3dacc.reshape(3 * winLength), features3dgyr.reshape(3 * winLength))
        features[side] = np.vstack([features[side], add])
        #print features[side]
    return features[side]

def storeFeaturesWindowNorm(S,N,features, winLength, iData, idxIMU, side, nTime):
    for s in range(nTime):
        # use maxStrideLength with zero padding at the end or truncation at the end
        if (s < winLength):
            features3dacc = np.zeros((N, winLength))
            features3dgyr = np.zeros((N, winLength))
        else:
            features3dacc = np.zeros((N, winLength))
            features3dgyr = np.zeros((N, winLength))
            for i in range(winLength):
                features3dgyr[:, i] = np.linalg.norm(iData[idxIMU[side]].gyr[:, s - i:s])
                features3dacc[:, i] = np.linalg.norm(iData[idxIMU[side]].acc[:, s - i:s])

        add = np.append(features3dacc.reshape(N * winLength), features3dgyr.reshape(N * winLength))
        #add = features3dacc.reshape(N*winLength)
        features[side] = np.vstack([features[side], add])
        print(features[side])
    return features[side]



def icSegmentations(idxContact, winLength, turnSeg, side, nTime):
    ic_all_idx = []
    ic_other_idx = []
    ic_straight_idx = []
    for icseg in idxContact[side]:
        if (icseg[0] < winLength):
            continue
        ic_all_idx.append(icseg[0])
        if (icseg[1]+1 < nTime-1):
            if (turnSeg[side,icseg[0]-1] == 1 or turnSeg[side,icseg[1]+1] == 1):
                ic_other_idx.append(icseg[0])
            else:
                ic_straight_idx.append(icseg[0])
        else:
            if (turnSeg[side, icseg[0] - 1] == 1):
                ic_other_idx.append(icseg[0])
            else:
                ic_straight_idx.append(icseg[0])
    return ic_all_idx, ic_straight_idx, ic_other_idx

def selectCorrICs(idxContact, turnSeg, nTime, side, winLength):
    ic_all, ic_straight, ic_other = icSegmentations(idxContact, winLength, turnSeg, side, nTime)

    Y_allTmp = np.zeros(nTime)
    Y_straightTmp = np.zeros(nTime)
    Y_otherTmp = np.zeros(nTime)

    for ic in ic_all:
        Y_allTmp[ic] = 1
    for ic in ic_straight:
        Y_straightTmp[ic] = 1
    for ic in ic_other:
        Y_otherTmp[ic] = 1

    return Y_allTmp, Y_straightTmp, Y_otherTmp, ic_all, ic_straight, ic_other

def loadLabeledDataIC(pathLearningData, scenarioTitle, idRange, sampleLimit=-1, maxICWindow=10, dFactor=1, transformDataToSegSys=False, listIMUs = ['LeftFoot', 'RightFoot']):
    X_all_ic = [structtype() for i in range(2)]
    X_straight_ic = [structtype() for i in range(2)]
    X_other_ic = [structtype() for i in range(2)]
    Y_all_ic = [structtype() for i in range(2)]
    Y_straight_ic = [structtype() for i in range(2)]
    Y_other_ic = [structtype() for i in range(2)]

    X_all = [structtype() for i in range(2)]
    X_selected = [structtype() for i in range(2)]
    Y_all = [structtype() for i in range(2)]
    Y_selected = [structtype() for i in range(2)]
    Y_straight = [structtype() for i in range(2)]
    Y_other = [structtype() for i in range(2)]
    ic_all_idx = [structtype() for i in range(2)]
    ic_straight_idx = [structtype() for i in range(2)]
    ic_other_idx = [structtype() for i in range(2)]
    N=3
    S=2
    for l in range(2):
        X_all_ic[l] = np.array([]).reshape(0,N*S*maxICWindow)
        X_straight_ic[l] = np.array([]).reshape(0,N*S*maxICWindow)
        X_other_ic[l] = np.array([]).reshape(0,N*S*maxICWindow)
        X_all[l] = np.array([]).reshape(0,N*S*maxICWindow)
        X_selected[l] = np.array([]).reshape(0,N*S*maxICWindow)
        Y_all[l] = []
        Y_selected[l] = []
        Y_straight[l] = []
        Y_other[l] = []

    for id in idRange:
        print('Load id:'+ str(id))
        aData, cData, iData = loadData(pathLearningData, scenarioTitle, id, sampleLimit)
        idxIMU = []
        idxIMU.append(cData.segValueByNames[listIMUs[0]])
        idxIMU.append(cData.segValueByNames[listIMUs[1]])

        if (transformDataToSegSys):
            for idx in idxIMU:
                RotI2S = quaternion_matrix(cData.segCalib[idx].quat_si)
                iData[idx].acc[:,:] = np.matmul(RotI2S, iData[idx].acc[:,:])
                iData[idx].gyr[:, :] = np.matmul(RotI2S, iData[idx].gyr[:, :])
                iData[idx].mag[:, :] = np.matmul(RotI2S, iData[idx].mag[:, :])

        segEndPt_g = loadFoodpoints_g(aData, cData)
        # obtain initial contact for left and right foot
        ic = computeIC(segEndPt_g, cData, iData, aData.nTime, 0.5, 5.0, True)
        # obtain turning segmentation
        pelvis_euler_angles, pelvis_euler_angles_diff = compute_euler_angles(aData, cData, iData, aData.nTime)
        # segment phases as belonging to straight gait and turing
        turnSeg, idxContact = compute_segmentation(pelvis_euler_angles_diff, ic, aData.nTime)



        for side in range(2): # left and right side!
            Y_allTmp, Y_straightTmp, Y_otherTmp, ic_all_idxTmp,\
            ic_straight_idxTmp, ic_other_idxTmp = selectCorrICs(idxContact, turnSeg, aData.nTime, side, maxICWindow)
            Y_all[side] = np.append(Y_all[side], Y_allTmp)
            Y_straight[side] = np.append(Y_straight[side], Y_straightTmp)
            Y_other[side] = np.append(Y_other[side], Y_otherTmp)
            #X_all[side] = storeFeaturesWindowNorm(S,N,X_all, maxICWindow, iData, idxIMU, side, aData.nTime)
            X_all[side] = storeFeaturesWindow(X_all, maxICWindow, iData, idxIMU, side, aData.nTime)

            all_idx = range(maxICWindow-1, aData.nTime)
            no_contactIdx = np.setdiff1d(all_idx, ic_all_idxTmp)
            sparse = []
            if (dFactor > 0):
                for i in no_contactIdx:
                    if (i % dFactor == 0):
                        sparse = np.append(sparse,i)
                sparse = np.append(sparse, ic_all_idxTmp)
            else:
                sparse = ic_all_idxTmp

            for i in sparse:
                i = int(i)
                Y_selected[side] = np.append(Y_selected[side], Y_all[side][i])
                X_selected[side] = np.vstack([X_selected[side], X_all[side][i]])

    print('Finished Loading!')

    return X_all, Y_all, X_selected, Y_selected, Y_straight, Y_other, ic_all_idx, ic_straight_idx, ic_other_idx
