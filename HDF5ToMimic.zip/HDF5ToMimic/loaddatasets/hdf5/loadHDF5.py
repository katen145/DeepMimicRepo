import h5py
import numpy as np
import os
import pandas as pd
from loaddatasets.hdf5.loadAnimationFiles import loadAnimationFromDict, loadAnimationAndIMUTrajFromDict
from loaddatasets.hdf5.loadIMUData import loadIMUDataFromDict
from loaddatasets.hdf5.loadCalibrationFiles import loadCalibFromDict

class SettingReadHDF5():
    def __init__(self, pathLearningData,i):
        self.labels = 'initial_contact_right'
        self.task = 'cl' # 'reg'
        self.onehotencoding = False
        self.inputdata = ['s_g', 'mrp_gs']      # animation position and orientation (will be flatted to 1D np.array, per timestep)
        self.segmentsToInclude = list(range(7)) # all segments with index 0:6
        #self.IMUsToInclude = []
        self.trainDataSubjs = ['P'+i]
        self.trainSampleLimit = 1.e+15  # per person
        self.testDataSubjs = ['P'+i]
        self.testSampleLimit = 1.e+15   # per person
        self.movements = ['_Test_1_6_min_walking_test']
        self.pathLearningData = pathLearningData
        self.featureNormsOnly = False
        #self.IMUTraj = False
        #self.IMUTrafoAtIdx = -1
        self.winSize = 1
# class SettingReadHDF5BatchOutput(SettingReadHDF5):
#     def __init__(self, pathLearningData):
#         SettingReadHDF5.__init__(pathLearningData)
#
#         # learning specific parameters
#         self.maxBatchSize = 10
#         self.winSize = 10  # trancated backprob
#         self.winNonOverlap = 1 # 1 = online, > 1 is batchwise processing, = self.winSize is disjunct batchwise

class LoadHDF5():
    def __init__(self, p):
        if (not os.path.exists(p.pathLearningData)):
            raise Exception("Path does not exist: " + p.pathLearningData)
        self.p = p

        # Train
        self.dictTrainInputs = {}
        self.dictTrainLabels = {}

        # Test
        self.dictTestInputs = {}
        self.dictTestLabels = {}

        self.LabelDepth = 2
        self.LabelDepthSet = False

    def loadForLearning(self):
        for move in self.p.movements:
            print("Load movement: " + move)
            for p in self.p.trainDataSubjs:
                self.loadData(self.dictTrainLabels, self.dictTrainInputs, p, move)
            for p in self.p.testDataSubjs:
                self.loadData(self.dictTestLabels, self.dictTestInputs, p, move)

    def loadForVisualization(self, subj, movement, nTimeLimit=1.e+15, load = ['a', 'c']):
        print('Loading data for visualization...')
        listsk = ['listSegNames', 'nSegs', 'nIMUs', 'mrp_si', 'i_s', 'pSeg_s']
        nTime = nTimeLimit
        dictSkel = self.loadHDF5ToDict(subj, movement, listsk, nTime, 'skel')
        cData = []
        aData = []
        iData = []

        if ('c' in load):
            cData = loadCalibFromDict(dictSkel)

        listdata = []
        if ('a' in load):
            listdata = listdata + ['mrp_gs', 's_g']

        if ('i' in load):
            listdata = listdata + ['acc_i', 'gyr_i', 'mag_i', 'time']

        dictData = self.loadHDF5ToDict(subj, movement, listdata, int(nTimeLimit), 'data')
        nTime = dictData['nTime']
        if ('c' in load and 'a' in load):
            aData = loadAnimationAndIMUTrajFromDict(dictData, dictSkel['nSegs'], nTime, cData)
        else:
            aData = loadAnimationFromDict(dictData, dictSkel['nSegs'], nTime)

        if ('i' in load):
            iData = loadIMUDataFromDict(dictData, dictData['nTime'], dictSkel['nIMUs'], dictSkel['listSegNames'])

        list = ['initial_contact_right', 'initial_contact_left', 'turn_segments_right', 'turn_segments_left']
        dictLabels = self.loadHDF5ToDict(subj, movement, list, nTime, 'labels')

        return dictLabels, aData, iData, cData

    def loadSkelData(self, f, input, dict):
        inputBase = "/skeleton/"
        inputStr = inputBase + input[0]
        dict[input[0]] = np.asarray(f[inputStr])
        dict[input[1]] = f[inputBase].attrs[input[1]]
        dict[input[2]] = f[inputBase].attrs[input[2]]

        for d in range(dict[input[1]]):
            for lword in input[3:]:
                inputStr = "/skeleton/segment_" + str(d) + "/" + lword
                dictStr = lword + "_seg_" + str(d)
                dict[dictStr] = np.asarray(f[inputStr])
        return dict

    def loadHDF5ToDict(self, p, move, input, nTimeLimit, whatToLoad):
        dict = {}
        fstrBase = self.p.pathLearningData #+ p + "/"
        fstr = fstrBase + p + move + ".h5"
        try:
            f = h5py.File(fstr, 'r')
        except:
            raise Exception("Could not open file: " + fstr)

        nTime = min(f["/data/"].attrs["nTime"], nTimeLimit)
        if (whatToLoad == 'data'):
            for data, d in zip(input, range(len(input))):
                inputStr = "data/" + data
                if (data == 'time'):
                    dict[data] = np.asarray(f[inputStr])[:nTime]
                else:
                    dict[data] = np.asarray(f[inputStr])[:nTime, :]
            dict["nSegs"] = f["data"].attrs["nSegs"]
            dict["nTime"] = nTime

        if (whatToLoad == 'labels'):
            dictTmp = {}
            for label, d in zip(input, range(len(input))):
                inputStr = "/labels/" + label
                dictTmp[label] = np.asarray(f[inputStr])[:nTime]
            ic = np.zeros((2,nTime))
            ic[0,:] = dictTmp['initial_contact_left']
            ic[1,:] = dictTmp['initial_contact_right']
            seg = np.zeros((2,nTime))
            seg[0, :] = dictTmp['turn_segments_left']
            seg[1, :] = dictTmp['turn_segments_right']
            dict['ic'] = ic
            dict['seg'] = seg
            dict["nTime"] = nTime

        if (whatToLoad == 'skel'):
            dict = self.loadSkelData(f, input, dict)
        f.close()
        return dict

    def getTrainInputsDict(self):
        return self.dictTrainInputs

    def getTestInputsDict(self):
        return self.dictTestInputs

    def getTrainLabelsDict(self):
        return self.dictTrainLabels

    def getTestLabelsDict(self):
        return self.dictTestLabels

    def getSkelDict(self, p, move):
        fstrBase = self.p.pathLearningData + p + "/"
        fstr = fstrBase + p + move + ".h5"
        dict = {}
        try:
            f = h5py.File(fstr, 'r')
        except:
            raise Exception("Could not open file: " + fstr)

        listsk = ['listSegNames', 'nSegs', 'nIMUs', 'mrp_si', 'i_s', 'pSeg_s']
        dict = self.loadSkelData(f, listsk, dict)

        return dict

    def slidingWindowTrafo(self, inputData, winSize, nTime, featureWidthSingleTime):
        rows = nTime-(winSize-1)
        inputDataWindowed = np.zeros((rows, winSize*featureWidthSingleTime))

        for i in range(rows):
            for tw in range(winSize):
                inputDataWindowed[i, tw*featureWidthSingleTime:(tw+1)*featureWidthSingleTime] = inputData[i+winSize-tw-1,:]

        return inputDataWindowed

    def getDictLabel(self, labelName, p, move):
        dictLabels = {}
        dstIdentifier = p + move  # string to identify input and labels

        fstrBase = self.p.pathLearningData + p + "/"
        fstr = fstrBase + p + move + ".h5"
        try:
            f = h5py.File(fstr, 'r')
        except:
            raise Exception("Could not open file: " + fstr)

        labelStr = "/labels/" + labelName
        nTime = min(f["data/"].attrs["nTime"], self.p.trainSampleLimit)

        if (self.p.task == 'cl'):
            if (not self.LabelDepthSet):
                self.LabelDepth = f[labelStr].attrs["depth"]
            labelTmp = np.asarray(f[labelStr]).astype(int)[:nTime]
            dictLabels[dstIdentifier] = self.getLabels(labelTmp)
        else: # regression case
            labelTmp = np.asarray(f[labelStr]).astype(float)[:nTime]
            dictLabels[dstIdentifier] = labelTmp

        return dictLabels

    def loadData(self, dictLabels, dictInput, p, move):
        dstIdentifier = p + move  # string to identify input and labels

        fstrBase = self.p.pathLearningData + p + "/"
        fstr = fstrBase + p + move + ".h5"
        try:
            f = h5py.File(fstr, 'r')
        except:
            raise Exception("Could not open file: " + fstr)

        labelStr = "/labels/" + self.p.labels
        nTime = min(f["data/"].attrs["nTime"], self.p.trainSampleLimit)
        if (self.p.task == 'cl'):
            if (not self.LabelDepthSet):
                self.LabelDepth = f[labelStr].attrs["depth"]
            labelTmp = np.asarray(f[labelStr]).astype(int)[:nTime]
            dictLabels[dstIdentifier] = self.getLabels(labelTmp)
        else: # regression case
            labelTmp = np.asarray(f[labelStr]).astype(float)[:nTime]
            dictLabels[dstIdentifier] = labelTmp

        if (self.p.winSize > 1):
            dictLabels[dstIdentifier] = dictLabels[dstIdentifier][self.p.winSize-1:]

        nSegsInclude = len(self.p.segmentsToInclude)
        if (self.p.featureNormsOnly):
            nDataSingleSeg = 1 * len(self.p.inputdata)
        else:
            nDataSingleSeg = 3 * len(self.p.inputdata)

        featureWidthSingleTime = nSegsInclude*nDataSingleSeg

        inputData = np.zeros((nTime, featureWidthSingleTime))
        for data, d in zip(self.p.inputdata, range(len(self.p.inputdata))):
            inputStr = "data/" + data
            for segIdx, s in zip(self.p.segmentsToInclude, range(len(self.p.segmentsToInclude))):
                if (self.p.featureNormsOnly):
                    tmpArray = np.asarray(f[inputStr])[:nTime, 3 * segIdx:3 * segIdx + 3]
                    for t in range(nTime):
                        inputData[t, s * nDataSingleSeg + 1 * d:s * nDataSingleSeg + 1 * (d + 1)] = np.linalg.norm(tmpArray[t,:])
                else:
                    inputData[:nTime, s*nDataSingleSeg + 3*d:s*nDataSingleSeg + 3*(d+1)] = np.asarray(f[inputStr])[:nTime, 3*segIdx:3*segIdx+3]


        if (self.p.winSize > 1):
            #inputDataFull = inputData
            dictInput[dstIdentifier] = self.slidingWindowTrafo(inputData, self.p.winSize, nTime, featureWidthSingleTime)
        else:
            dictInput[dstIdentifier] = inputData

        f.close()

    def getLabels(self, labelInt):
        if (self.p.onehotencoding):
            return self.one_hot_encoding(labelInt)
        else:
            return labelInt

    def one_hot_encoding(self, labelSeq): # assumes 1D label-list of positive integers (incremental order, i.e. 0,1,2,3)!!!
        if (self.LabelDepthSet):
            one_hot_array = np.zeros((labelSeq.size, self.LabelDepth))
        else:
            one_hot_array = np.zeros((labelSeq.size, int(labelSeq.max())+1))
        one_hot_array[np.arange(labelSeq.size), labelSeq] = 1
        return one_hot_array

    #  one-hot encoding using pandas
    # def one_hot_encoding(self, labelSeq):
    #     ser = pd.Series(labelSeq)
    #     return (pd.get_dummies(ser)).values

# class LoadHDF5BatchOutput():
#     def __init__(self, p):
#         self.dictTrainInputsRNN = {}
#         self.dictTrainLabelsRNN = {}
#
#     def getTrainInputRNN(self, nWin):
#         return self.convertDictData(nWin, self.dictTrainInputs, 'inputdata')
#
#     def getTrainLabelsRNN(self, nWin):
#         return self.convertDictData(nWin, self.dictTrainLabels, 'labels')
#
#     def getTestInputRNN(self, nWin):
#         return self.convertDictData(nWin, self.dictTestInputs, 'inputdata')
#
#     def getTestLabelsRNN(self, nWin):
#         return self.convertDictData(nWin, self.dictTestLabels, 'labels')
#
#     def getTrainInputSeq(self, nWin):
#         self.convertDictData(nWin, self.dictTrainInputs, 'inputdata')
#         return self.dictTrainInputsRNN['inputdata']
#
#     def getTrainLabelsSeq(self, nWin):
#         self.convertDictData(nWin, self.dictTrainInputs, 'labels')
#         return self.dictTrainInputsRNN['labels']
#
# #    def getNextBatch(self):
#
#     def convertDictData(self, nWin, dict, dataStr):
#         # assume dicts for training and testing are available!
#         samplesBeginSeq = []
#         samplesEndSeq = []
#         count = 0
#         flag = 0
#         for moveSeq in dict.keys():
#             samplesBeginSeq.append(count)
#             # input data of dimension: [nSamples, nWin, nFeatures]
#             #print(moveSeq)
#             #print(dict[moveSeq])
#             #print(dict[moveSeq].shape[0])
#             #print(dict[moveSeq].shape[1])
#
#             dataTmp = np.zeros((dict[moveSeq].shape[0] - nWin + 1, nWin, dict[moveSeq].shape[1]))
#             for i in range(len(dict[moveSeq]) - nWin + 1): # consider window-overlap of "dataWindow - 1" (online)
#                 # sample
#                 dataTmp[i,:, :] = dict[moveSeq][i:i+nWin,:]
#
#             if flag ==0:
#                 data = dataTmp
#                 flag = 1
#             else:
#                 data.concatenate((data, dataTmp))
#
#             count = count + dict[moveSeq].shape[0] - nWin + 1
#             samplesEndSeq.append(count-1)
#
#         self.dictTrainInputsRNN[dataStr] = data
#         self.dictTrainInputsRNN['samplesBeginSeq'] = np.array(samplesBeginSeq)
#         self.dictTrainInputsRNN['samplesEndSeq'] = np.array(samplesEndSeq)
#
#         return self.dictTrainInputsRNN
