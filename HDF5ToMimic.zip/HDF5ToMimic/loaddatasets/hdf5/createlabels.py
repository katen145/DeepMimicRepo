import numpy as np
from scipy import signal
from utils.loaddatasets.trafos import euler_from_quaternion
from numpy import linalg as la
from utils.loaddatasets.hdf5.loadutils import structtype
from utils.pyquaternion import Quaternion

def diff(f, dt):
    df = np.zeros((3,len(f[0,:])))
    for t in range(len(f[0,:])):
        if (t == 0):
            df[:,t]=np.multiply(1.0/dt,(f[:,t+1]-f[:,t]))
        elif (t > 0 and t < len(f)-1):
            df[:,t] = np.multiply(0.5 / dt, (f[:, t + 1] - f[:, t-1]))
        else:
            df[:,t] = np.multiply(1.0 / dt, (f[:, t] - f[:, t-1]))
    return df

def computeIC(aData, cData, iData, nTime, thr_vel, thr_acc, filter=False):
    idxLF = cData.segValueByNames['LeftFoot']
    idxRF = cData.segValueByNames['RightFoot']
    #heelIdx = 7
    leftHeel_posT= aData.seg[idxLF].pos_g[:,:] #segEndPt_g[idxLF][3*heelIdx:3*heelIdx+3,:]
    rightHeel_posT = aData.seg[idxRF].pos_g[:,:] #segEndPt_g[idxRF][3*heelIdx:3*heelIdx+3,:]

    dt =iData[0].t[1]-iData[0].t[0]
    leftHeel_velT = diff(leftHeel_posT, dt)
    rightHeel_velT = diff(rightHeel_posT, dt)
    leftHeel_accT = diff(leftHeel_velT, dt)
    rightHeel_accT = diff(rightHeel_velT, dt)
    b, a = signal.butter(8,0.125)
    leftHeel_pos = leftHeel_posT
    rightHeel_pos = rightHeel_posT
    leftHeel_vel = leftHeel_velT
    rightHeel_vel = rightHeel_velT
    leftHeel_acc = leftHeel_accT
    rightHeel_acc = rightHeel_accT

    if (filter):
        for i in range(3):
            leftHeel_pos[i,:] = signal.filtfilt(b, a, leftHeel_posT[i,:])
            rightHeel_pos[i, :] = signal.filtfilt(b, a, rightHeel_posT[i,:])
            leftHeel_vel[i, :] = signal.filtfilt(b, a, leftHeel_velT[i,:])
            rightHeel_vel[i, :] = signal.filtfilt(b, a, rightHeel_velT[i, :])
            leftHeel_acc[i,:] = signal.filtfilt(b, a, leftHeel_accT[i, :])
            rightHeel_acc[i, :] = signal.filtfilt(b, a, rightHeel_accT[i, :])

    # go through arrays and select time-steps, where thresholds apply!
    ic_left = np.zeros(nTime)
    ic_right = np.zeros(nTime)
    for t in range(1,nTime):
        if (leftHeel_pos[2,t]-leftHeel_pos[2,t-1] < 0.0 and la.norm(leftHeel_vel[:,t]) < thr_vel and la.norm(leftHeel_acc[:,t]) > thr_acc):
            ic_left[t] = 1
        if (rightHeel_pos[2,t]-rightHeel_pos[2,t-1] < 0.0 and la.norm(rightHeel_vel[:,t]) < thr_vel and la.norm(rightHeel_acc[:,t]) > thr_acc):
            ic_right[t] = 1

    ic = np.zeros((2,nTime))
    ic[0,:] = ic_left
    ic[1,:] = ic_right

    return ic #, leftHeel_pos, rightHeel_pos, leftHeel_vel, rightHeel_vel, leftHeel_acc, rightHeel_acc

def compute_euler_angles(aData, cData, iData, nTime):
    euler_angles = np.zeros((3,nTime))
    euler_angles_diff = np.zeros((3,nTime))
    for t in range(nTime):
        euler_angles[:,t] = euler_from_quaternion(aData.seg[cData.segValueByNames['Pelvis']].quat_sg[:,t])
        euler_angles[:,t] = np.multiply(180/np.pi, euler_angles[:,t])

    dt = iData[cData.segValueByNames['Pelvis']].t[1] - iData[cData.segValueByNames['Pelvis']].t[0]
    euler_angles_diff = diff(euler_angles,dt)

    return euler_angles, euler_angles_diff

def idxSegmentation(ic,nTime):
#     idxContact = [structtype() for i in range(2)]
#     idxContact[0] = []
#     idxContact[1] = []
    idxContactList = np.array([], dtype=int).reshape(0,2)
    idxContact = np.zeros(2, dtype=int)

    idxlast = 0
    #for i in range(2):
    for t in range(nTime):
        if (ic[t] - ic[t-1] == 1):
            idxContact = np.array([idxlast,t], dtype=int)
            #idxContact[i].append([idxlast[i],t])
            idxContactList = np.vstack([idxContactList, idxContact])
            idxlast=t

    if (len(idxContact) > 0 and idxContact[1]< nTime-1):
        #idxContact[i].append([idxlast[i],nTime-1])
        idxContact = np.array([idxlast,nTime-1], dtype=int)
        idxContactList = np.vstack([idxContactList, idxContact])

    return idxContactList

def computeSeg(segments, seg, angles_diff, thrAngle, sIdx):
    sum_rot = sum(angles_diff[2, seg[0]:seg[1]])
    if (seg[1] - seg[0] > 0):
        sum_rot = sum_rot / (float(seg[1] - seg[0]))
    if (abs(sum_rot) > thrAngle):
        segments[sIdx, seg[0]:seg[1]] = np.ones(seg[1] - seg[0])

def compute_segmentation(angles_diff, ic, nTime, thrAngle=45):
    segments = np.zeros((2, nTime))
    idxContactS1 = idxSegmentation(ic[0], nTime)
    idxContactS2 = idxSegmentation(ic[1], nTime)

    sIdx = 0
    for seg in idxContactS1:
        computeSeg(segments, seg, angles_diff, thrAngle, sIdx)

    sIdx +=1

    for seg in idxContactS2:
        computeSeg(segments, seg, angles_diff, thrAngle, sIdx)

    return segments, idxContactS1, idxContactS2

def compute_segmentation_and_labelIdx(angles_diff, ic, nTime, thrAngle=45):
    segments = np.zeros((2, nTime))
    idxContact = idxSegmentation(ic, nTime)
    labelIdx = np.zeros(len(idxContact[:]))
    sIdx = 0
    for side in idxContact[:]:
        for seg in side:
            sum_rot = sum(angles_diff[2,seg[0]:seg[1]])
            if (seg[1]-seg[0] > 0):
                sum_rot = sum_rot/(float(seg[1]-seg[0]))
            if (abs(sum_rot) > thrAngle):
                segments[sIdx, seg[0]:seg[1]] = np.ones(seg[1] - seg[0])
                labelIdx[sIdx] = 1
        sIdx +=1

    return segments, idxContact, labelIdx


def loadFoodpoints_g(aData, cData):
    segEndPt_g = [structtype() for i in range(aData.nSegs)]
    for segIdx in range(aData.nSegs):
        nPoints = len(cData.segCalib[segIdx].points)
        segEndPt_g[segIdx] = np.zeros((3 * nPoints, aData.nTime))
        for t in range(aData.nTime):
            qseg_g = Quaternion(aData.seg[segIdx].quat_sg[:,t])
            idx = 0
            for p in cData.segCalib[segIdx].points:
                segEndPt_g[segIdx][3 * idx:3 * idx+3,t] = aData.seg[segIdx].pos_g[:,t] + qseg_g.rotate(p)
                idx +=1
    return segEndPt_g

def computeStrideLength(segEndPt_g, ic, segLabels, nTime, cData):
    strideLength = [structtype() for i in range(2)]
    strideLength_straight = [structtype() for i in range(2)]
    strideLength_other = [structtype() for i in range(2)]
    labelIdx = [structtype() for i in range(2)]

    for l in range(2):
        strideLength[l] = []
        strideLength_straight[l] = []
        strideLength_other[l] = []
        labelIdx[l] = []

    idxSeg =[0,0]
    idxSeg[0] = cData.segValueByNames['LeftFoot']
    idxSeg[1] = cData.segValueByNames['RightFoot']
    heelIdx = 7
    Heel_pos = [structtype() for i in range(2)]
    Heel_pos[0] = segEndPt_g[idxSeg[0]][3*heelIdx:3*heelIdx+3,:]
    Heel_pos[1] = segEndPt_g[idxSeg[1]][3*heelIdx:3*heelIdx+3,:]

    idxContact = idxSegmentation(ic, nTime)
    sIdx = 0
    for side in idxContact:
        for seg in side:
            if (seg[0] == 0):
                continue
            stridelength = np.linalg.norm(Heel_pos[sIdx][:,seg[1]] - Heel_pos[sIdx][:,seg[0]])
            strideLength[sIdx].append([seg[0], seg[1], stridelength])
            midPoint = int(0.5*(seg[0] + seg[1]))
            if (segLabels[sIdx,midPoint] > 0):
                strideLength_other[sIdx].append([seg[0], seg[1], stridelength])
                labelIdx[sIdx].append(1)
            else:
                strideLength_straight[sIdx].append([seg[0], seg[1], stridelength])
                labelIdx[sIdx].append(0)
        sIdx +=1

    return strideLength, strideLength_straight, strideLength_other, labelIdx


def labelStraight(YA_, labelIdx, side):
    YA_straight = []
    T_straight = []
    for i in range(0, len(labelIdx[side])):
        if (labelIdx[side][i] == 0):
            YA_straight.append(YA_[i])
            T_straight.append(i + 1)
    return YA_straight, T_straight