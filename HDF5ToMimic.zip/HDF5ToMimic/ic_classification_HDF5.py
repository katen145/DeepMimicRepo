import tensorflow as tf
import copy

################################# Main ############################################

from utils.loaddatasets.hdf5.loadHDF5 import SettingReadHDF5, LoadHDF5

# Settings for loader
p = SettingReadHDF5("data/")
p.labels = 'initial_contact_right'
p.inputdata = ['s_g', 'mrp_sg']
p.trainDataSubjs = ['P1']
p.testDataSubjs = ['P1']
p.movements = ['_6_min_walking_test']
p.winSize = 10
#p.winSize = 1

p.trainSampleLimit = 1000
p.testSampleLimit = 1000

# Load HDF5
loader = LoadHDF5(p)
loader.loadForLearning()

# dict of labels and training data
Ytrain_onehot = loader.getTrainLabelsDict()[p.trainDataSubjs[0] + p.movements[0]]
Xtrain_onehot = loader.getTrainInputsDict()[p.trainDataSubjs[0] + p.movements[0]]

Ytest_onehot = loader.getTestLabelsDict()[p.testDataSubjs[0] + p.movements[0]]
Xtest_onehot = loader.getTestInputsDict()[p.testDataSubjs[0] + p.movements[0]]

print(Ytrain_onehot.shape)
print(Xtrain_onehot.shape)


pInt = copy.deepcopy(p)
pInt.onehotencoding = False

loaderInt = LoadHDF5(pInt)
loaderInt.loadForLearning()

# dict of labels and training data
Ytrain = loaderInt.getTrainLabelsDict()[p.trainDataSubjs[0] + p.movements[0]]
Xtrain = loaderInt.getTrainInputsDict()[p.trainDataSubjs[0] + p.movements[0]]

Ytest = loaderInt.getTestLabelsDict()[p.testDataSubjs[0] + p.movements[0]]
Xtest = loaderInt.getTestInputsDict()[p.testDataSubjs[0] + p.movements[0]]

print(Ytrain.shape)
print(Xtrain.shape)

# Keras version
model = tf.keras.models.Sequential([
  tf.keras.layers.Dense(Xtrain.shape[1], activation=tf.nn.relu),
  tf.keras.layers.Dense(50, activation=tf.nn.relu),
  tf.keras.layers.Dense(50, activation=tf.nn.relu),
  tf.keras.layers.Dropout(0.2),
  tf.keras.layers.Dense(2, activation=tf.nn.softmax)
])
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

model.fit(Xtrain, Ytrain, epochs=1000)
model.evaluate(Xtest, Ytest)

